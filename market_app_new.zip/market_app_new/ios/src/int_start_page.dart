import 'package:flutter/material.dart';

class InitStartPage extends StatelessWidget {
  const InitStartPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(
        child: Text(
          style: TextStyle(color: Colors.white)
        ,)
        
        )
        )
  }
}
