import 'package:flutter/material.dart';
import 'package:karrot_app_clone/widgets/app_font.dart';

// 동네 생활 탭 화면
class TownPage extends StatelessWidget {
  const TownPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const AppFontDark(
          '동네 생활',
          fontWeight: FontWeight.bold,
          fontSize: 20,
        ),
      ),
      body: const Center(child: AppFontDark('동네 생활 페이지 내용', fontSize: 18)),
    );
  }
}
