import 'package:flutter/material.dart';
import 'package:karrot_app_clone/widgets/app_font.dart';

// 채팅 페이지
class ChatPage extends StatelessWidget {
  const ChatPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const AppFontDark('채팅', fontWeight: FontWeight.bold),
        actions: const [
          IconButton(
            icon: Icon(Icons.settings_outlined, color: Colors.white),
            onPressed: null,
          ),
        ],
      ),

      // 임시 콘텐츠
      body: Center(child: AppFontDark('채팅 목록이 표시될 공간입니다.', color: Colors.grey)),
    );
  }
}
