import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart'; // shared_preferences 패키지 필요

import 'widgets/app_font.dart';
import 'widgets/btn.dart';

class AppFlowWrapper extends StatefulWidget {
  const AppFlowWrapper({super.key});

  @override
  State<AppFlowWrapper> createState() => _AppFlowWrapperState();
}

class _AppFlowWrapperState extends State<AppFlowWrapper> {
  bool _isLoading = true;

  bool _isInitStarted = false;

  @override
  void initState() {
    super.initState();
    _checkInitStatus();
  }

  void _checkInitStatus() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();

    _isInitStarted = prefs.getBool('isInitStarted') ?? false;

    // 상태 업데이트 후 로딩 완료
    setState(() {
      _isLoading = false;
    });
  }

  // 초기화가 완료되었을 때 호출되는 콜백 함수
  void _handleInitStart() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();

    // 상태를 true로 저장하여 다음부터 InitStartPage를 건너뛰도록 합니다.
    await prefs.setBool('isInitStarted', true);

    // MainScreen으로 이동합니다.
    Get.offNamed('/main');
  }

  // 로딩 중일 때 표시할 스플래시 페이지
  Widget get _splashPage => const Center(
    child: AppFontDark('로딩 중...', fontSize: 24, fontWeight: FontWeight.bold),
  );

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return _splashPage; // 로딩 중에는 스플래시 페이지를 표시합니다.
    }

    if (_isInitStarted) {
      // 초기화가 완료되었다면 바로 MainScreen으로 이동합니다.
      // 실제 앱에서는 여기서 Get.offAllNamed('/main')을 사용하여 리다이렉트합니다.
      WidgetsBinding.instance.addPostFrameCallback((_) {
        Get.offAllNamed('/main');
      });
      // 리다이렉션 직전까지 스플래시 화면을 보여줍니다.
      return _splashPage;
    } else {
      // 초기화가 필요하다면 InitStartPage를 표시하고 콜백을 넘겨줍니다.
      return InitStartPage(onStart: _handleInitStart);
    }
  }
}

// ----------------------------------------------------
// 2. 초기 시작 페이지 (onStart 콜백 사용)
// ----------------------------------------------------
class InitStartPage extends StatelessWidget {
  // 버튼 클릭 시 호출될 함수를 외부에서 받습니다.
  final VoidCallback onStart;

  const InitStartPage({super.key, required this.onStart});

  @override
  Widget build(BuildContext context) {
    // 노치 디자인을 고려한 하단 패딩 값 계산
    final double bottomPadding = MediaQuery.of(context).padding.bottom;

    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // 1. 로고 이미지 영역
            SizedBox(
              width: 99,
              height: 116,
              child: Image.asset(
                'assets/images/logo_simbol.png',
                errorBuilder: (context, error, stackTrace) {
                  return Container(
                    color: Colors.grey[800],
                    child: const Center(
                      child: Text(
                        '로고 자리',
                        style: TextStyle(color: Colors.white70),
                      ),
                    ),
                  );
                },
              ),
            ),

            const SizedBox(height: 40),

            // 2. 제목 텍스트 (AppFontDark 사용)
            const AppFontDark(
              '당신 근처의 밤톨마켓',
              fontWeight: FontWeight.bold,
              fontSize: 20,
            ),

            const SizedBox(height: 15),

            // 3. 설명 텍스트 (AppFontDark 사용)
            const AppFontDark(
              '중고 거래부터 동네 정보까지, \n지금 내 동네를 선택하고 시작해보세요!',
              textAlign: TextAlign.center,
              fontSize: 18,
              color: Color.fromRGBO(
                255,
                255,
                255,
                0.6,
              ), // Colors.white.withOpacity(0.6)
            ),

            // 사진에서 본 하단 버튼 및 패딩 로직
            const SizedBox(height: 50),

            // 4. 시작 버튼 (Btn 위젯 사용)
            Padding(
              // 노치 디자인 영역만큼의 하단 패딩을 추가합니다.
              padding: EdgeInsets.only(
                left: 20,
                right: 20,
                bottom: 20 + bottomPadding,
              ),
              child: Btn(
                onTap: onStart, // 외부에서 받은 콜백 함수 연결
                // child: const AppFontDark(...)
                child: const AppFontDark(
                  '내 동네 설정하고 시작하기',
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
