import 'package:flutter/material.dart';

// 앱 전체 테마 설정
class AppTheme {
  static const Color primaryKarrotColor = Color(0xFFFF7E36);
  static const Color darkBackgroundColor = Color(0xFF1C1C1E);
  static const Color darkForegroundColor = Colors.white;

  static final ThemeData darkTheme = ThemeData(
    brightness: Brightness.dark,
    scaffoldBackgroundColor: darkBackgroundColor,
    primaryColor: primaryKarrotColor,
    useMaterial3: true,

    appBarTheme: const AppBarTheme(
      backgroundColor: darkBackgroundColor,
      elevation: 0,
      iconTheme: IconThemeData(color: darkForegroundColor),
      titleTextStyle: TextStyle(
        color: darkForegroundColor,
        fontSize: 18,
        fontWeight: FontWeight.bold,
      ),
    ),

    bottomNavigationBarTheme: const BottomNavigationBarThemeData(
      backgroundColor: darkBackgroundColor,
      selectedItemColor: primaryKarrotColor,
      unselectedItemColor: Colors.grey,
      type: BottomNavigationBarType.fixed,
    ),

    floatingActionButtonTheme: const FloatingActionButtonThemeData(
      backgroundColor: primaryKarrotColor,
      foregroundColor: Colors.white,
    ),
  );
}
