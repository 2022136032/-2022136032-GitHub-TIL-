// 앱 전체에서 사용되는 상수 값을 모아놓은 파일
abstract class AppConstants {
  // 1. 상품 관련 상수
  static const List<String> productCategories = [
    '디지털기기',
    '생활가전',
    '가구/인테리어',
    '생활/주방',
    '유아동',
    '의류',
    '뷰티/미용',
    '스포츠/레저',
    '취미/게임',
    '도서/티켓/음반',
    '반려동물용품',
    '기타 중고물품',
    '삽니다',
  ];

  static const List<String> productStatus = ['판매중', '예약중', '판매완료'];

  // 2. 단위 및 포맷 관련
  static const String currencyUnit = '원';
  static const String temperatureUnit = '°C';

  // 3. UI/텍스트 관련
  static const String appName = 'Karrot Clone';
  static const String defaultTown = '당근동';
  static const String defaultProfileImage =
      'https://placehold.co/150x150/ffa500/ffffff?text=U';
}
