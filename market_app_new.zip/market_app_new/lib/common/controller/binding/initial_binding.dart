import 'package:get/get.dart';
import 'package:karrot_app_clone/common/controller/auth_controller.dart';
import 'package:karrot_app_clone/services/firestore_service.dart';
// import 'package:karrot_app_clone/services/storage_service.dart'; // 향후 필요 시 추가

// 앱이 처음 시작될 때 필요한 모든 컨트롤러/서비스를 초기화합니다.
class InitialBinding extends Bindings {
  @override
  void dependencies() {
    // 1. 서비스 초기화 (Singleton 패턴 - 앱 전체에서 공유)
    // FirestoreService는 lazyPut 대신 Get.put()으로 즉시 인스턴스를 생성하여
    // AuthController나 다른 서비스가 즉시 사용할 수 있도록 합니다.
    Get.put<FirestoreService>(FirestoreService(), permanent: true);
    // Get.put<StorageService>(StorageService(), permanent: true); // 스토리지 서비스

    // 2. 핵심 컨트롤러 초기화 (Singleton 패턴 - 앱 전체에서 공유)
    // AuthController는 앱의 생명주기와 함께하며 인증 상태를 관리하므로 permanent: true
    Get.put<AuthController>(AuthController(), permanent: true);
    
    // 3. UI/로직 컨트롤러는 각 페이지의 Binding에서 처리합니다.
    // (예: MainController는 MainBinding에서 처리)
  }
}


이 9개의 파일은 이전에 생성된 파일들과 함께 당근마켓 클론 앱의 견고한 기반을 구축합니다. `main.dart`가 앱을 시작하고, `InitialBinding`이 필수 서비스와 컨트롤러(`AuthController`, `FirestoreService`)를 초기화하며, `AppPages`가 화면 전환 경로를 정의합니다.