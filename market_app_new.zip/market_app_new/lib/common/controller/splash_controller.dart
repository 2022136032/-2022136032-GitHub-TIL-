import 'package:get/get.dart';
import 'package:karrot_app_clone/common/controller/auth_controller.dart';
import 'package:karrot_app_clone/routes/app_routes.dart';

// SplashPage의 로직을 담당하는 컨트롤러
class SplashController extends GetxController {
  final AuthController _authController = Get.find<AuthController>();

  @override
  void onInit() {
    super.onInit();
    // 1. Splash 화면에서 인증 상태 변화를 지속적으로 관찰합니다.
    // _authController.isAuthenticated는 null(로딩) -> true(로그인) 또는 false(로그아웃)로 바뀝니다.
    ever(_authController.isAuthenticated, _handleAuthChange);
  }

  // 인증 상태 변화 시 라우팅을 처리하는 함수
  void _handleAuthChange(bool? isAuthenticated) async {
    // 2초의 딜레이를 주어 스플래시 화면을 충분히 보여줍니다.
    await Future.delayed(const Duration(seconds: 2));

    if (isAuthenticated == null) {
      // 아직 로딩 중이면 아무것도 하지 않습니다. (계속 대기)
      print("⏳ SplashController: 인증 상태 로딩 중...");
      return;
    }

    // `offAll`을 사용하여 이전의 모든 라우트를 제거하고 새 화면으로 이동합니다.
    if (isAuthenticated) {
      // 2. 로그인 상태: 메인 화면으로 이동
      Get.offAllNamed(AppRoutes.MAIN);
      print("✅ SplashController: 인증 완료 -> 메인 화면 이동");
    } else {
      // 3. 로그아웃 상태: 인증(로그인/회원가입) 화면으로 이동
      Get.offAllNamed(AppRoutes.AUTH);
      print("❌ SplashController: 비인증 상태 -> 인증 화면 이동");
    }
  }

  @override
  void onClose() {
    // SplashController는 라우팅 완료 후 제거됩니다.
    print("🗑️ SplashController: 종료");
    super.onClose();
  }
}
