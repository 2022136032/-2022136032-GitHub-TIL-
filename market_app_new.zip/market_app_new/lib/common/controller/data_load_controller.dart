import 'package:get/get.dart';

// 앱 초기 실행 시 필요한 데이터 로딩 상태를 관리하는 컨트롤러
class DataLoadController extends GetxController {
  // 데이터 로딩 중인지 여부 (RxBool을 사용하여 GetX 반응형 상태로 관리)
  final RxBool isLoading = true.obs;

  @override
  void onInit() {
    super.onInit();
    // 초기화 시 데이터 로드 시작
    _loadInitialData();
  }

  // 초기 데이터를 비동기로 로드하는 함수
  Future<void> _loadInitialData() async {
    print("⏳ DataLoadController: 초기 데이터 로딩 시작...");
    isLoading(true);

    // 1. 필요한 설정 정보 로드 (예: 지역 목록, 카테고리 등)
    await Future.delayed(const Duration(milliseconds: 500));

    // 2. 인증 상태를 확인하는 과정과 병행될 수 있습니다. (SplashController에서 최종 확인)

    // 로딩 완료
    isLoading(false);
    print("✅ DataLoadController: 초기 데이터 로딩 완료.");
  }

  // 외부에서 강제로 로딩 상태를 설정할 때 사용 가능
  void setLoading(bool value) {
    isLoading(value);
  }
}
