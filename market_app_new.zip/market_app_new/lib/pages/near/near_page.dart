import 'package:flutter/material.dart';
import 'package:karrot_app_clone/widgets/app_font.dart';

// 내 근처 페이지
class NearPage extends StatelessWidget {
  const NearPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const AppFontDark('내 근처', fontWeight: FontWeight.bold),
        actions: const [
          IconButton(
            icon: Icon(Icons.search, color: Colors.white),
            onPressed: null,
          ),
          IconButton(
            icon: Icon(Icons.notifications_none, color: Colors.white),
            onPressed: null,
          ),
        ],
      ),

      // 임시 콘텐츠
      body: Center(
        child: AppFontDark('내 근처 가게 및 서비스 목록이 표시될 공간입니다.', color: Colors.grey),
      ),
    );
  }
}
