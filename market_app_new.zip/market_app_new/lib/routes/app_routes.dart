// 앱 내에서 사용되는 모든 화면의 경로(Route Name)를 상수로 정의합니다.
abstract class AppRoutes {
  static const String SPLASH = '/splash'; // 🥕 앱 초기 로딩 화면
  static const String AUTH = '/auth'; // 🔒 로그인/회원가입 화면
  static const String MAIN = '/main'; // 🏠 메인 (탭 컨테이너) 화면
  static const WRITE_POST = '/write'; // 글쓰기
  static const String PRODUCT_DETAIL = '/product_detail'; // 상품 상세 정보
  static const String PRODUCT_WRITE = '/product_write'; // 상품 등록/수정
  static const String CHAT_ROOM = '/chat_room'; // 채팅방
  static const String PROFILE_EDIT = '/profile_edit'; // 프로필 수정
}
