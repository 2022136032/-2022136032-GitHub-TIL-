import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:get/get.dart';
import 'package:karrot_app_clone/models/product_model.dart';
import 'package:karrot_app_clone/models/user_model.dart';

// Firestore 데이터베이스와의 통신을 담당하는 서비스 클래스
// 모든 데이터베이스 상호작용은 이 클래스를 통해 이루어져야 합니다.
class FirestoreService extends GetxService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  // Firebase Auth에서 현재 로그인된 사용자 ID를 가져옵니다.
  // 익명 로그인의 경우에도 UID를 반환합니다.
  String get userId {
    // AuthController에서 userId를 관리하지만, Service 계층에서도 직접 가져와 사용합니다.
    return _auth.currentUser?.uid ?? 'anonymous_user';
  }

  // 앱 ID (Canvas 환경에서 제공되는 전역 변수 사용)
  String get appId {
    // 실제 환경에서는 __app_id 대신 환경 설정 변수를 사용해야 합니다.
    const String __app_id = 'karrot-clone-app-id';
    return __app_id;
  }
  
  // ----------------------------------------------------
  // 1. 사용자(User) 관련 컬렉션 경로
  // ----------------------------------------------------
  
  // 사용자 문서 경로 (private data)
  DocumentReference _userDoc(String uid) {
    // 경로: /artifacts/{appId}/users/{userId}/user_data/profile
    return _db
        .collection('artifacts').doc(appId)
        .collection('users').doc(uid)
        .collection('user_data').doc('profile');
  }

  // ----------------------------------------------------
  // 2. 상품(Product) 관련 컬렉션 경로
  // ----------------------------------------------------

  // 상품 컬렉션 경로 (public data)
  CollectionReference<Map<String, dynamic>> _productsCollection() {
    // 경로: /artifacts/{appId}/public/data/products
    return _db
        .collection('artifacts').doc(appId)
        .collection('public').doc('data')
        .collection('products');
  }


  // ----------------------------------------------------
  // 3. 사용자 데이터 CRUD
  // ----------------------------------------------------

  // 새로운 사용자 데이터를 Firestore에 추가 (회원가입 시)
  Future<void> addUser(UserModel user) async {
    try {
      await _userDoc(user.uid).set(user.toMap());
      print("✅ Firestore: 사용자 데이터 추가 성공 (UID: ${user.uid})");
    } catch (e) {
      print("❌ Firestore: 사용자 데이터 추가 오류: $e");
    }
  }
  
  // 사용자 정보 가져오기
  Future<UserModel?> getUser(String uid) async {
    try {
      final snapshot = await _userDoc(uid).get();
      if (snapshot.exists) {
        return UserModel.fromSnapshot(snapshot);
      }
      return null;
    } catch (e) {
      print("❌ Firestore: 사용자 데이터 가져오기 오류: $e");
      return null;
    }
  }


  // ----------------------------------------------------
  // 4. 상품 데이터 CRUD
  // ----------------------------------------------------

  // 상품 목록 실시간 감지 (onSnapshot)
  // GetX Controller에서 이 함수를 호출하여 Stream을 구독하고 UI를 업데이트합니다.
  Stream<List<ProductModel>> streamProducts() {
    // **중요**: orderBy() 사용 시 인덱스 오류가 발생할 수 있으므로, 
    // 여기서는 간단히 모든 문서를 가져온 후 클라이언트(Controller)에서 정렬합니다.
    return _productsCollection()
        .snapshots()
        .map((snapshot) => snapshot.docs.map((doc) => ProductModel.fromSnapshot(doc)).toList());
  }

  // 새로운 상품 게시글 추가
  Future<String?> addProduct(ProductModel product) async {
    try {
      final docRef = await _productsCollection().add(product.toMap());
      print("✅ Firestore: 상품 게시글 추가 성공 (Doc ID: ${docRef.id})");
      // 생성된 Document ID를 ProductModel에 업데이트합니다. (선택적)
      await docRef.update({'id': docRef.id}); 
      return docRef.id;
    } catch (e) {
      print("❌ Firestore: 상품 게시글 추가 오류: $e");
      Get.snackbar('오류', '상품 게시글 저장 중 오류가 발생했습니다: $e', snackPosition: SnackPosition.BOTTOM);
      return null;
    }
  }

  // 상품 상세 정보 가져오기
  Future<ProductModel?> getProduct(String docId) async {
    try {
      final doc = await _productsCollection().doc(docId).get();
      if (doc.exists) {
        return ProductModel.fromSnapshot(doc);
      }
      return null;
    } catch (e) {
      print("❌ Firestore: 상품 상세 정보 가져오기 오류: $e");
      return null;
    }
  }

  // 상품 상태 업데이트 (예: 판매 완료, 예약 중)
  Future<void> updateProductStatus(String docId, String status) async {
    try {
      await _productsCollection().doc(docId).update({'status': status});
      print("✅ Firestore: 상품 상태 업데이트 성공 (Doc ID: $docId, Status: $status)");
    } catch (e) {
      print("❌ Firestore: 상품 상태 업데이트 오류: $e");
      Get.snackbar('오류', '상품 상태 업데이트 중 오류가 발생했습니다: $e', snackPosition: SnackPosition.BOTTOM);
    }
  }

  // 상품 게시글 삭제
  Future<void> deleteProduct(String docId) async {
    try {
      await _productsCollection().doc(docId).delete();
      print("✅ Firestore: 상품 게시글 삭제 성공 (Doc ID: $docId)");
    } catch (e) {
      print("❌ Firestore: 상품 게시글 삭제 오류: $e");
      Get.snackbar('오류', '상품 게시글 삭제 중 오류가 발생했습니다: $e', snackPosition: SnackPosition.BOTTOM);
    }
  }
}


이제 모든 핵심 위젯, 컨트롤러, 메인 화면, 스플래시 화면, 그리고 Firestore 서비스 레이어가 완성되었습니다. 이 파일들을 통합하여 프로젝트를 구성하면 Flutter 당근마켓 클론 앱이 성공적으로 실행될 것입니다.