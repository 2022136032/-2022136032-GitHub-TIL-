import 'package:flutter/material.dart';
import 'package:karrot_app_clone/app_theme.dart';

// 다크 모드/라이트 모드를 자동으로 지원하는 범용 텍스트 위젯
// 기본적으로 어두운 배경(다크 모드)에 맞춰 흰색 텍스트를 사용합니다.
class AppFont extends StatelessWidget {
  final String text;
  final double fontSize;
  final FontWeight fontWeight;
  final Color color;
  final TextAlign textAlign;
  final bool isBold;
  final int? maxLines;
  final TextOverflow? overflow;

  const AppFont(
    this.text, {
    super.key,
    this.fontSize = 14.0,
    this.fontWeight = FontWeight.normal,
    this.color = Colors.white, // 기본 색상: 흰색 (다크 모드 기준)
    this.textAlign = TextAlign.start,
    this.isBold = false,
    this.maxLines,
    this.overflow,
  });

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      textAlign: textAlign,
      maxLines: maxLines,
      overflow: overflow,
      style: TextStyle(
        fontSize: fontSize,
        fontWeight: isBold ? FontWeight.bold : fontWeight,
        color: color,
        height: 1.4, // 가독성을 위한 줄 간격
      ),
    );
  }
}

// 다크 모드 환경에서 전경색이 아닌 기본 배경색에 쓰일 어두운 텍스트를 위한 위젯
// (예: 흰색 배경에 검은색 텍스트)
class AppFontDark extends StatelessWidget {
  final String text;
  final double fontSize;
  final FontWeight fontWeight;
  final Color color;
  final TextAlign textAlign;
  final bool isBold;
  final int? maxLines;
  final TextOverflow? overflow;

  const AppFontDark(
    this.text, {
    super.key,
    this.fontSize = 14.0,
    this.fontWeight = FontWeight.normal,
    this.color =
        AppTheme.darkForegroundColor, // 기본 색상: 흰색 (다크 모드에서 배경색이 어두우므로 전경색은 밝게)
    this.textAlign = TextAlign.start,
    this.isBold = false,
    this.maxLines,
    this.overflow,
  });

  @override
  Widget build(BuildContext context) {
    // 실제 다크 모드에서는 `AppTheme.darkForegroundColor` (흰색)을 사용해야 합니다.
    // 하지만 이 위젯은 라이트 모드에서 사용될 수 있으므로, 다크 모드 테마를 기본으로 하되
    // `AppFontDark`의 의도상 `AppTheme.darkForegroundColor`를 기본 전경색으로 사용합니다.

    return Text(
      text,
      textAlign: textAlign,
      maxLines: maxLines,
      overflow: overflow,
      style: TextStyle(
        fontSize: fontSize,
        fontWeight: isBold ? FontWeight.bold : fontWeight,
        color: color,
        height: 1.4,
      ),
    );
  }
}
