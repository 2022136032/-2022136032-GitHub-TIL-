import 'package:get/get.dart';
import 'employee.model.dart';
import 'employee_list.controller.dart'; // 목록 컨트롤러와의 통신을 위해 임포트

// 직원 추가 또는 편집 폼의 상태와 입력을 관리하는 GetX 컨트롤러입니다.
class EmployeeFormController extends GetxController {
  // 현재 편집 중인 직원 객체. 새 직원의 경우 null
  final Employee? initialEmployee;

  // 폼 필드 상태를 위한 반응형 변수
  final RxString name = ''.obs;
  final RxString position = ''.obs;
  final RxString department = ''.obs;
  final RxInt salary = 0.obs;
  final RxBool isFormValid = false.obs;
  final RxBool isSubmitting = false.obs;

  // 유효성 검사 메시지
  final RxString nameError = ''.obs;
  final RxString salaryError = ''.obs;

  // 생성자: 편집 모드 시 초기 직원 데이터를 로드합니다.
  EmployeeFormController({this.initialEmployee});

  @override
  void onInit() {
    super.onInit();
    // 편집 모드인 경우, 기존 데이터를 폼에 로드합니다.
    if (initialEmployee != null) {
      name.value = initialEmployee!.name;
      position.value = initialEmployee!.position;
      department.value = initialEmployee!.department;
      salary.value = initialEmployee!.salary;
    }
    // 폼 유효성 검사 리스너 설정
    ever(name, (_) => _validateForm());
    ever(position, (_) => _validateForm());
    ever(department, (_) => _validateForm());
    ever(salary, (_) => _validateForm());
    _validateForm(); // 초기 유효성 검사
  }

  // 폼 필드 유효성 검사 로직
  void _validateForm() {
    // 이름 유효성 검사
    if (name.value.trim().isEmpty) {
      nameError.value = '이름은 필수 항목입니다.';
    } else if (name.value.length > 50) {
      nameError.value = '이름은 50자 이하여야 합니다.';
    } else {
      nameError.value = '';
    }

    // 연봉 유효성 검사
    if (salary.value < 0) {
      salaryError.value = '연봉은 0 이상이어야 합니다.';
    } else if (salary.value == 0) {
      salaryError.value = '연봉을 입력해 주세요.';
    } else {
      salaryError.value = '';
    }

    // 전체 폼 유효성 검사 결과 업데이트
    isFormValid.value =
        nameError.value.isEmpty &&
        salaryError.value.isEmpty &&
        name.value.isNotEmpty &&
        position.value.isNotEmpty &&
        department.value.isNotEmpty &&
        salary.value > 0;
  }

  // 폼 제출 로직 (추가 또는 편집)
  Future<void> submitForm() async {
    _validateForm();
    if (!isFormValid.value || isSubmitting.value) return;

    isSubmitting.value = true;
    final EmployeeListController listController =
        Get.find<EmployeeListController>();

    try {
      if (initialEmployee == null) {
        // 새 직원 추가 모드
        final newEmployee = Employee(
          id: '', // Firestore에서 ID가 생성될 예정이므로 임시로 빈 값
          name: name.value,
          position: position.value,
          department: department.value,
          salary: salary.value,
        );
        await listController.addEmployee(newEmployee);
      } else {
        // 기존 직원 편집 모드
        final updatedEmployee = Employee(
          id: initialEmployee!.id, // 기존 ID 유지
          name: name.value,
          position: position.value,
          department: department.value,
          salary: salary.value,
        );
        await listController.updateEmployee(updatedEmployee);
      }

      // 성공적으로 완료되면 이전 화면으로 돌아갑니다.
      Get.back();
    } catch (e) {
      // 에러 처리는 ListController에서 이미 처리하지만, 폼에서도 에러를 표시할 수 있습니다.
      Get.snackbar(
        '제출 오류',
        '데이터 처리 중 예상치 못한 오류가 발생했습니다.',
        snackPosition: SnackPosition.BOTTOM,
      );
      print('Form submission error: $e');
    } finally {
      isSubmitting.value = false;
    }
  }

  // 폼 입력 처리 메서드
  void setName(String value) => name.value = value;
  void setPosition(String value) => position.value = value;
  void setDepartment(String value) => department.value = value;
  void setSalary(String value) {
    final int? sal = int.tryParse(value);
    salary.value = sal ?? 0;
  }
}
