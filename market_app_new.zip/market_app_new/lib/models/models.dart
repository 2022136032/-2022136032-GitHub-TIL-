// lib/models.dart
// 온라인 상점의 데이터 모델 (Product, Customer, Order) 정의.
class Product {
  final int id;
  final String name;
  final double price;
  int stockQuantity;

  Product({
    required this.id,
    required this.name,
    required this.price,
    this.stockQuantity = 0,
  });

  // 상품 정보를 문자열로 반환합니다.
  @override
  String toString() {
    return '$name (${price.toStringAsFixed(0)}원)';
  }
}

class Customer {
  final String customerId;
  final String name;
  String? address;

  Customer({required this.customerId, required this.name, this.address});
}

class Order {
  final String orderId;
  final DateTime orderDate;
  final Product product;
  final Customer customer;
  final int quantity;

  Order({
    required this.orderId,
    required this.orderDate,
    required this.product,
    required this.customer,
    required this.quantity,
  });

  double get totalAmount => product.price * quantity;
}
