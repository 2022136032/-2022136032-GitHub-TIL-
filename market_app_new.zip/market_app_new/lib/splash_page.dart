import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:karrot_app_clone/app_theme.dart';
import 'package:karrot_app_clone/common/controller/splash_controller.dart';
import 'package:karrot_app_clone/widgets/app_font.dart';

// 앱 시작 시 가장 먼저 보여지는 스플래시 화면.
// SplashController를 통해 인증 상태를 확인하고 적절한 화면으로 라우팅합니다.
class SplashPage extends GetView<SplashController> {
  const SplashPage({super.key});

  @override
  Widget build(BuildContext context) {
    // 컨트롤러를 미리 바인딩했으므로, 여기서 아무것도 할 필요 없이
    // 컨트롤러가 로직을 수행하도록 둡니다. (GetView<SplashController>를 상속했으므로)

    return Scaffold(
      backgroundColor: AppTheme.primaryKarrotColor, // 당근마켓 주황색 배경
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // 당근마켓을 상징하는 아이콘 (예시)
            const Icon(
              Icons.shopping_bag_outlined,
              size: 100,
              color: Colors.white,
            ),
            const SizedBox(height: 20),
            // 앱 이름
            AppFont(
              'Karrot Clone',
              fontSize: 30,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
            const SizedBox(height: 50),
            // 로딩 인디케이터
            const CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
            ),
          ],
        ),
      ),
    );
  }
}
