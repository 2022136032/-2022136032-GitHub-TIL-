import 'package:flutter/material.dart';
import 'app_font.dart'; // 이전 단계에서 만든 AppFont 위젯 임포트

// 사용자 정의 버튼 위젯
// Elevated Button 대신 GestureDetector와 Container를 사용하여
// 커스터마이징이 용이한 버튼을 구현합니다.
class Btn extends StatelessWidget {
  // 버튼이 눌렸을 때 실행될 콜백 함수
  final VoidCallback? onTap;
  // 버튼 내부에 들어갈 위젯 (대부분 텍스트 또는 아이콘이 될 것입니다)
  final Widget child;

  // 버튼의 배경색 (당근마켓 주황색을 기본으로 설정)
  final Color color;
  // 버튼의 가로 너비
  final double width;

  const Btn({
    super.key,
    required this.child,
    required this.onTap,
    this.color = const Color(0xFFFF7E36), // 기본 색상: 주황색
    this.width = double.infinity, // 기본 너비: 부모 위젯의 최대 너비
  });

  @override
  Widget build(BuildContext context) {
    // GestureDetector: 탭 이벤트를 감지합니다.
    return GestureDetector(
      onTap: onTap,
      child: ClipRRect(
        // 모서리를 둥글게 처리합니다.
        borderRadius: BorderRadius.circular(7),
        child: Container(
          // 버튼의 배경색을 설정합니다.
          color: color,
          // 버튼 내부의 패딩을 설정합니다. (수직 15.0)
          padding: const EdgeInsets.symmetric(vertical: 15),
          // 버튼의 너비를 설정합니다.
          width: width,
          // 텍스트 정렬을 중앙으로 설정합니다.
          alignment: Alignment.center,

          // 버튼 내부에 들어갈 콘텐츠
          child: child,
        ),
      ),
    );
  }
}

// InitStartPage의 '시작하기' 버튼에 특화된 버전 (AppFont 사용)
class StartBtn extends StatelessWidget {
  final VoidCallback? onTap;

  const StartBtn({super.key, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Btn(
      onTap: onTap,
      // InitStartPage의 텍스트와 스타일을 AppFontDark를 사용하여 구현
      child: const AppFontDark(
        '내 동네 설정하고 시작하기',
        fontSize: 18,
        fontWeight: FontWeight.bold,
        color: Colors.white, // 흰색 텍스트
      ),
      width: double.infinity,
      color: const Color(0xFFFF7E36), // 주황색 배경
    );
  }
}
import 'package:flutter/material.dart';

// 앱 전체에서 사용되는 커스텀 버튼 위젯
class Btn extends StatelessWidget {
  final Widget child; // 버튼 안에 들어갈 위젯 (텍스트, 아이콘 등)
  final VoidCallback? onTap; // 탭 이벤트 핸들러
  final double? width;
  final double? height;
  final EdgeInsetsGeometry padding;
  final Color? backgroundColor;
  final double borderRadius;
  final BorderSide? borderSide;

  const Btn({
    super.key,
    required this.child,
    required this.onTap,
    this.width,
    this.height = 50.0, // 기본 높이 설정
    this.padding = const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
    this.backgroundColor,
    this.borderRadius = 8.0,
    this.borderSide,
  });

  @override
  Widget build(BuildContext context) {
    // 배경색이 지정되지 않은 경우, 테마의 primaryColor를 사용합니다.
    final Color defaultColor = Theme.of(context).primaryColor;
    
    // 버튼이 비활성화되었는지 확인
    final bool isDisabled = onTap == null;

    return Material(
      color: isDisabled 
          ? Colors.grey.shade700 // 비활성화 시 어두운 회색
          : backgroundColor ?? defaultColor, // 활성화 시 지정 색상 또는 기본 색상
      borderRadius: BorderRadius.circular(borderRadius),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(borderRadius),
        child: Container(
          width: width,
          height: height,
          padding: padding,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(borderRadius),
            border: borderSide != null ? Border.fromBorderSide(borderSide!) : null,
          ),
          alignment: Alignment.center,
          child: child,
        ),
      ),
    );
  }
}import 'package:flutter/material.dart';
import 'package:karrot_app_clone/app_theme.dart';
import 'app_font.dart'; // AppFontDark 위젯을 사용하기 위해 임포트

// 앱 전체에서 사용될 표준 버튼 위젯
class Btn extends StatelessWidget {
  final VoidCallback onTap;
  final Widget child;
  final Color backgroundColor;
  final double height;
  final double borderRadius;
  final bool enabled;

  const Btn({
    super.key,
    required this.onTap,
    required this.child,
    this.backgroundColor = AppTheme.primaryKarrotColor, // 기본색: 당근 주황색
    this.height = 50.0,
    this.borderRadius = 10.0,
    this.enabled = true,
  });

  @override
  Widget build(BuildContext context) {
    final effectiveBackgroundColor = enabled
        ? backgroundColor
        : backgroundColor.withOpacity(0.5); // 비활성화 시 투명도 조절

    return Opacity(
      opacity: enabled ? 1.0 : 0.6,
      child: GestureDetector(
        onTap: enabled ? onTap : null, // 비활성화 시 onTap 무효화
        child: Container(
          height: height,
          decoration: BoxDecoration(
            color: effectiveBackgroundColor,
            borderRadius: BorderRadius.circular(borderRadius),
            // 그림자 효과 추가
            boxShadow: [
              BoxShadow(
                color: effectiveBackgroundColor.withOpacity(0.3),
                spreadRadius: 2,
                blurRadius: 5,
                offset: const Offset(0, 3), // y축으로 살짝
              ),
            ],
          ),
          alignment: Alignment.center,
          child: child, // 버튼 내부에 표시될 위젯 (주로 AppFontDark 사용)
        ),
      ),
    );
  }
}

// 텍스트만 있는 버튼 (보조 버튼 용도)
class TextBtn extends StatelessWidget {
  final VoidCallback onTap;
  final String text;
  final Color color;
  final bool isBold;
  final double fontSize;

  const TextBtn({
    super.key,
    required this.onTap,
    required this.text,
    this.color = AppTheme.primaryKarrotColor,
    this.isBold = false,
    this.fontSize = 14.0,
  });

  @override
  Widget build(BuildContext context) {
    return TextButton(
      onPressed: onTap,
      child: AppFontDark(
        text,
        color: color,
        isBold: isBold,
        fontSize: fontSize,
      ),
    );
  }
}