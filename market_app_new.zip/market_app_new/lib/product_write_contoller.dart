<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>상품 등록 페이지</title>
    <!-- Tailwind CSS 로드 -->
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        /* 커스텀 스타일 */
        body { font-family: 'Inter', sans-serif; background-color: #f3f4f6; }
        .card {
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -4px rgba(0, 0, 0, 0.1);
        }
        .input-field {
            @apply w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition duration-150 ease-in-out;
        }
        .label-style {
            @apply block text-sm font-medium text-gray-700 mb-1;
        }
    </style>
</head>
<body class="p-4 sm:p-8 flex justify-center items-start min-h-screen">

    <div class="w-full max-w-2xl bg-white card rounded-xl p-6 sm:p-10 mt-10">
        <h1 class="text-3xl font-bold text-gray-900 mb-6 text-center">새 상품 등록</h1>
        
        <!-- 상태 메시지 영역 -->
        <div id="status-message" class="mb-4 p-3 text-center rounded-lg text-sm transition-all duration-300 hidden" role="alert">
            <!-- 상태 메시지가 여기에 표시됩니다. -->
        </div>

        <form id="product-form" class="space-y-6">
            <!-- 상품명 -->
            <div>
                <label for="product-name" class="label-style">상품명</label>
                <input type="text" id="product-name" name="name" required placeholder="상품 이름을 입력하세요" class="input-field">
            </div>

            <!-- 가격 -->
            <div>
                <label for="product-price" class="label-style">가격 (₩)</label>
                <input type="number" id="product-price" name="price" required min="100" placeholder="가격을 입력하세요 (예: 15000)" class="input-field">
            </div>

            <!-- 카테고리 -->
            <div>
                <label for="product-category" class="label-style">카테고리</label>
                <select id="product-category" name="category" required class="input-field bg-white appearance-none">
                    <option value="" disabled selected>카테고리를 선택하세요</option>
                    <option value="clothing">의류</option>
                    <option value="electronics">전자제품</option>
                    <option value="books">도서</option>
                    <option value="food">식품</option>
                </select>
            </div>

            <!-- 상세 설명 -->
            <div>
                <label for="product-description" class="label-style">상세 설명</label>
                <textarea id="product-description" name="description" rows="5" required placeholder="상품의 자세한 설명을 입력하세요" class="input-field resize-none"></textarea>
            </div>

            <!-- 이미지 첨부 (프론트엔드 목업) -->
            <div class="border-t pt-6">
                <label class="label-style">상품 이미지</label>
                <div class="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-lg">
                    <div class="space-y-1 text-center">
                        <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v8" />
                        </svg>
                        <div class="flex text-sm text-gray-600">
                            <label for="file-upload" class="relative cursor-pointer bg-white rounded-md font-medium text-indigo-600 hover:text-indigo-500 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-indigo-500">
                                <span>파일 업로드 (목업)</span>
                                <input id="file-upload" name="file-upload" type="file" class="sr-only" disabled>
                            </label>
                            <p class="pl-1">또는 드래그 앤 드롭</p>
                        </div>
                        <p class="text-xs text-gray-500">PNG, JPG, GIF 등 (최대 10MB)</p>
                    </div>
                </div>
            </div>

            <!-- 제출 버튼 -->
            <div class="pt-4">
                <button type="submit" id="submit-button" class="w-full flex justify-center py-3 px-4 border border-transparent rounded-lg shadow-lg text-lg font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition duration-150 ease-in-out disabled:opacity-50">
                    상품 등록하기
                </button>
            </div>
        </form>
    </div>

    <script type="module">
        // ====================================================================
        // Firebase 초기 설정 및 인증
        // ====================================================================
        import { initializeApp } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-app.js";
        import { getAuth, signInAnonymously, signInWithCustomToken, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-auth.js";
        import { getFirestore, collection, addDoc, doc, setDoc, setLogLevel } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-firestore.js";

        // Firestore 디버그 로깅 활성화
        setLogLevel('Debug');

        // 환경 변수 로드 (Canvas에서 제공)
        const appId = typeof __app_id !== 'undefined' ? __app_id : 'default-app-id';
        const firebaseConfig = JSON.parse(typeof __firebase_config !== 'undefined' ? __firebase_config : '{}');
        const initialAuthToken = typeof __initial_auth_token !== 'undefined' ? __initial_auth_token : null;

        if (Object.keys(firebaseConfig).length === 0) {
            console.error("Firebase Configuration is missing or empty.");
        }
        
        const app = initializeApp(firebaseConfig);
        const db = getFirestore(app);
        const auth = getAuth(app);
        let currentUserId = null;

        // 상태 메시지 표시 유틸리티
        function displayStatus(message, type = 'success') {
            const statusElement = document.getElementById('status-message');
            if (!statusElement) return;

            statusElement.textContent = message;
            statusElement.classList.remove('hidden', 'bg-green-100', 'text-green-800', 'bg-red-100', 'text-red-800');
            
            if (type === 'success') {
                statusElement.classList.add('bg-green-100', 'text-green-800');
            } else if (type === 'error') {
                statusElement.classList.add('bg-red-100', 'text-red-800');
            }
            statusElement.classList.remove('hidden');
        }

        // 인증 및 사용자 ID 설정
        onAuthStateChanged(auth, async (user) => {
            if (user) {
                currentUserId = user.uid;
                console.log("Authenticated User ID:", currentUserId);
            } else {
                try {
                    // __initial_auth_token이 없으면 익명 로그인 시도
                    if (initialAuthToken) {
                        await signInWithCustomToken(auth, initialAuthToken);
                    } else {
                        await signInAnonymously(auth);
                    }
                    // onAuthStateChanged가 다시 호출되어 user가 설정될 것입니다.
                } catch (error) {
                    console.error("Authentication failed:", error);
                    displayStatus(`인증 오류: ${error.message}`, 'error');
                }
            }
        });
// product_write_controller.dart

import 'package:flutter/material.dart'; // 상태 관리를 위해 필요할 수 있습니다.
import 'product.dart'; // 상품 모델
import 'product_repository.dart'; // Firestore 연동 Repository (가정)

/// 상품 등록 페이지의 비즈니스 로직을 처리하는 컨트롤러입니다.
/// (예: Provider, GetX, Riverpod 등의 상태 관리 패턴에서 사용될 수 있음)
class ProductWriteController with ChangeNotifier {
  final ProductRepository _repository;

  ProductWriteController(this._repository);

  // 현재 로딩 상태
  bool _isLoading = false;
  bool get isLoading => _isLoading;

  // 에러 메시지
  String? _errorMessage;
  String? get errorMessage => _errorMessage;

  // 성공 메시지
  String? _successMessage;
  String? get successMessage => _successMessage;

  /// 상품 등록 로직
  Future<void> saveProduct({
    required String name,
    required int price,
    required String category,
    required String description,
    required String currentUserId,
  }) async {
    _setLoading(true);
    _clearMessages();

    // 입력 유효성 검사
    if (name.isEmpty || price <= 0 || category.isEmpty || description.isEmpty) {
      _errorMessage = '모든 필수 항목을 입력하고 가격을 확인해주세요.';
      _setLoading(false);
      return;
    }

    try {
      final newProduct = Product(
        name: name,
        price: price,
        category: category,
        description: description,
        createdAt: DateTime.now().toIso8601String(),
        userId: currentUserId, // 실제 앱에서는 인증 시스템에서 가져옵니다.
      );

      // Repository를 통해 Firestore에 상품 데이터 저장
      final productId = await _repository.addProduct(newProduct);

      _successMessage = '상품 등록에 성공했습니다! (ID: $productId)';
      
      // 등록 후 폼 초기화를 위한 로직 (예: 부모 위젯에 알림)
      // 이 예시에서는 성공 메시지를 보여주는 것으로 대체합니다.

    } catch (e) {
      _errorMessage = '상품 등록 중 오류가 발생했습니다: $e';
      print('Error saving product: $e');
    } finally {
      _setLoading(false);
    }
  }

  /// 로딩 상태를 설정하고 리스너에게 알립니다.
  void _setLoading(bool value) {
    _isLoading = value;
    notifyListeners();
  }

  /// 상태 메시지를 초기화합니다.
  void _clearMessages() {
    _errorMessage = null;
    _successMessage = null;
  }
}

// =========================================================================
// ProductRepository (의존성 주입을 위한 목업/가정)
// 실제 Firestore 코드는 여기에 포함되어야 합니다.
// =========================================================================

/// Firestore 작업을 처리하는 Repository 클래스입니다.
class ProductRepository {
  // 실제 Flutter 프로젝트에서는 Firestore 인스턴스를 받게 됩니다.
  // final FirebaseFirestore _firestore; 
  // ProductRepository(this._firestore);

  /// 임시로 Repository 구현을 가정합니다.
  Future<String> addProduct(Product product) async {
    // 실제 Firestore 저장 로직:
    // await _firestore.collection('products').add(product.toJson());
    
    // 현재는 목업 ID를 반환합니다.
    await Future.delayed(const Duration(seconds: 1)); 
    return 'prod_${DateTime.now().millisecondsSinceEpoch}';
  }
}