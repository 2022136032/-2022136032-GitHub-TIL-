// common_layout.dart

import 'package:flutter/material.dart';

/// 앱 전체에서 공통적으로 사용되는 기본 화면 레이아웃 위젯입니다.
/// 상단바와 배경색, 기본 패딩 등을 정의합니다.
class CommonLayout extends StatelessWidget {
  /// 화면 중앙에 표시될 위젯
  final Widget child;

  /// 앱바 제목 (선택 사항)
  final String? title;

  /// FloatingActionButton (선택 사항)
  final Widget? floatingActionButton;

  const CommonLayout({
    super.key,
    required this.child,
    this.title,
    this.floatingActionButton,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // 1. App Bar
      appBar: AppBar(
        title: Text(
          title ?? '기본 앱 제목',
          style: const TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        backgroundColor: Colors.indigo,
        elevation: 0,
        centerTitle: true,
      ),

      // 2. Body (화면 내용)
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16.0),
          child: Center(
            // 화면 중앙에 자식 위젯을 배치
            child: ConstrainedBox(
              constraints: const BoxConstraints(
                maxWidth: 600, // 웹/태블릿 환경에서 최대 너비 제한
              ),
              child: child,
            ),
          ),
        ),
      ),

      // 3. Floating Action Button
      floatingActionButton: floatingActionButton,
    );
  }
}
