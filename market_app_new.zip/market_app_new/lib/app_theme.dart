import 'package:flutter/material.dart';

// 당근마켓의 컬러 팔레트 및 앱 전체 테마 정의
class AppTheme {
  // 🥕 당근마켓 핵심 색상
  static const Color primaryKarrotColor = Color(0xFFFF7E36); // 당근 주황색
  static const Color accentKarrotColor = Color(0xFFE89812); // 강조 주황색

  // 🌑 다크 모드 (당근마켓은 어두운 톤을 사용)
  static const Color darkBackgroundColor = Color(
    0xFF1C1C1E,
  ); // 어두운 배경색 (거의 검은색)
  static const Color darkCardColor = Color(0xFF2C2C2E); // 카드/컨테이너 배경색
  static const Color darkForegroundColor = Colors.white; // 기본 전경색 (텍스트, 아이콘)
  static const Color darkDividerColor = Color(0xFF3A3A3C); // 구분선 색상

  // 💡 라이트 모드 (참고용)
  static const Color lightBackgroundColor = Color(0xFFFFFFFF);
  static const Color lightForegroundColor = Color(0xFF333333);

  // 다크 모드 테마 정의
  static final ThemeData darkTheme = ThemeData(
    brightness: Brightness.dark,
    primaryColor: primaryKarrotColor,
    scaffoldBackgroundColor: darkBackgroundColor, // 배경색
    cardColor: darkCardColor, // 카드색
    dividerColor: darkDividerColor, // 구분선
    // 폰트 및 텍스트 스타일
    fontFamily: 'NotoSansKR', // 프로젝트에 Noto Sans KR 폰트를 사용한다고 가정
    textTheme: const TextTheme(
      bodyLarge: TextStyle(color: darkForegroundColor),
      bodyMedium: TextStyle(color: darkForegroundColor),
      titleLarge: TextStyle(color: darkForegroundColor),
      titleMedium: TextStyle(color: darkForegroundColor),
      titleSmall: TextStyle(color: darkForegroundColor),
    ),

    // AppBar 테마
    appBarTheme: const AppBarTheme(
      backgroundColor: darkBackgroundColor,
      elevation: 0, // 그림자 제거
      titleTextStyle: TextStyle(
        color: darkForegroundColor,
        fontSize: 18,
        fontWeight: FontWeight.bold,
      ),
      iconTheme: IconThemeData(color: darkForegroundColor),
    ),

    // BottomNavigationBar 테마
    bottomNavigationBarTheme: const BottomNavigationBarThemeData(
      backgroundColor: darkBackgroundColor,
      selectedItemColor: primaryKarrotColor,
      unselectedItemColor: Color(0xFF8E8E93), // 회색
      type: BottomNavigationBarType.fixed,
      elevation: 0,
    ),

    // ElevatedButton 테마 (버튼)
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: primaryKarrotColor,
        foregroundColor: Colors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10.0),
        ),
        elevation: 0,
        textStyle: const TextStyle(fontWeight: FontWeight.bold),
      ),
    ),
  );
}
