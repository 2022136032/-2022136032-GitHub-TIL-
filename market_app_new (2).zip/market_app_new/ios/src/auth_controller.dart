import 'package:get/get.dart';
import 'package:firebase_auth/firebase_auth.dart';

// Firebase 인증 상태 및 사용자 데이터를 관리하는 컨트롤러
class AuthController extends GetxController {
  // 현재 사용자 정보를 관찰 가능한 Rx 타입으로 선언 (로그인 상태)
  Rx<User?> user = Rx<User?>(null);

  // 인증 로딩 상태 (Firebase 초기화 대기)
  RxBool isAuthLoading = true.obs;

  @override
  void onInit() {
    super.onInit();

    // Firebase 인증 상태 변경 리스너 등록
    FirebaseAuth.instance.authStateChanges().listen((User? firebaseUser) {
      user.value = firebaseUser; // 사용자 상태 업데이트
      isAuthLoading(false); // 로딩 완료
      print("✅ Firebase Auth State Changed: ${firebaseUser?.uid}");
    });

    // 초기 인증 상태 확인을 위해 리스너가 충분히 작동할 시간을 주는 역할
    Future.delayed(const Duration(seconds: 1), () {
      if (isAuthLoading.value) {
        isAuthLoading(false);
        print("⏳ Auth Loading Time Out. Proceeding...");
      }
    });
  }

  // 익명 로그인 시도 함수 (MainScreen 진입 전 필요)
  Future<void> signInAnonymously() async {
    if (user.value == null) {
      try {
        await FirebaseAuth.instance.signInAnonymously();
        print("👤 익명 로그인 성공!");
      } on FirebaseAuthException catch (e) {
        print("❌ 익명 로그인 실패: ${e.code}");
        // 실패 시 적절한 에러 처리 로직 추가
      }
    }
  }
}
