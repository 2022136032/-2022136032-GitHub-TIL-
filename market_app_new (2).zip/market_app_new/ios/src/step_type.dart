enum StepType {
  // 초기 상태 (위젯이 처음 생성되었을 때)
  init(''),
  // 데이터 로드 단계
  dataload('데이터 로드'),
  // 인증 체크 단계
  authCheck('인증 체크'),
  // 앱이 성공적으로 시작되었음을 의미 (MainScreen으로 이동)
  startApp('앱 시작');

  // 각 단계에 대응하는 설명 텍스트
  const StepType(this.name);
  final String name;
}
