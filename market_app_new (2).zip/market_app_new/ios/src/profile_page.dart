import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:karrot_app_clone/common/controller/auth_controller.dart';
import 'package:karrot_app_clone/widgets/app_font.dart';

// 나의 당근 탭 화면 (프로필)
class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  // 임시 로그아웃 기능
  void _logout() async {
    try {
      await FirebaseAuth.instance.signOut();
      Get.find<AuthController>().user.value = null;
      Get.offAllNamed('/'); // 스플래시 화면으로 이동하여 재인증 유도 (옵션)
      Get.snackbar('알림', '로그아웃 되었습니다.');
    } catch (e) {
      Get.snackbar('오류', '로그아웃 실패: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    final authController = Get.find<AuthController>();

    return Scaffold(
      appBar: AppBar(
        title: const AppFontDark(
          '나의 당근',
          fontWeight: FontWeight.bold,
          fontSize: 20,
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Obx(() {
              final user = authController.user.value;
              return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  AppFontDark(
                    '안녕하세요, 당근 사용자님!',
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                  ),
                  const SizedBox(height: 10),
                  // 사용자 UID 표시 (인증 상태 확인용)
                  AppFontDark(
                    'UID: ${user?.uid ?? '비인증 사용자'}',
                    color: Colors.grey,
                    fontSize: 14,
                  ),
                ],
              );
            }),

            const SizedBox(height: 30),

            // 임시 메뉴 목록
            const AppFontDark('판매 내역', fontSize: 16),
            const Divider(color: Colors.white10, height: 20),
            const AppFontDark('구매 내역', fontSize: 16),
            const Divider(color: Colors.white10, height: 20),
            const AppFontDark('관심 목록', fontSize: 16),
            const Divider(color: Colors.white10, height: 20),

            const SizedBox(height: 50),

            // 로그아웃 버튼 (커스텀 버튼 위젯 사용)
            GestureDetector(
              onTap: _logout,
              child: const AppFontDark(
                '로그아웃',
                fontSize: 16,
                color: Colors.redAccent,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
