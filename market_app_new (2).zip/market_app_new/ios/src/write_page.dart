import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:karrot_app_clone/common/controller/write_controller.dart';
import 'package:karrot_app_clone/widgets/app_font.dart';

// 판매 글 작성 페이지
class WritePage extends GetView<WriteController> {
  const WritePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // AppBar: 작성 완료 버튼
      appBar: AppBar(
        title: const AppFontDark(
          '중고거래 글쓰기',
          fontWeight: FontWeight.bold,
          fontSize: 18,
        ),
        leading: IconButton(
          icon: const Icon(Icons.close, color: Colors.white),
          onPressed: () => Get.back(),
        ),
        actions: [
          // Obx: isReadyToSubmit 상태에 따라 버튼 활성화/비활성화
          Obx(
            () => TextButton(
              onPressed: controller.isReadyToSubmit.value
                  ? controller.submitPost
                  : null,
              child: AppFontDark(
                '완료',
                color: controller.isReadyToSubmit.value
                    ? const Color(0xFFFF7E36)
                    : Colors.grey,
                fontWeight: FontWeight.bold,
                fontSize: 18,
              ),
            ),
          ),
        ],
      ),

      // SingleChildScrollView: 키보드가 올라올 때 오버플로우 방지
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // 1. 이미지 추가 버튼
              _buildImageAddSection(),
              const Divider(color: Colors.white10),

              // 2. 제목 입력 필드
              _buildTitleInput(),
              const Divider(color: Colors.white10),

              // 3. 카테고리 선택
              _buildSelectableRow(
                icon: Icons.list,
                label: '카테고리 선택',
                onTap: controller.selectCategory,
                // Obx를 이용해 선택된 카테고리 표시
                content: Obx(
                  () => AppFontDark(
                    controller.category.value ?? '필수',
                    color: controller.category.value == null
                        ? Colors.grey
                        : Colors.white,
                  ),
                ),
              ),
              const Divider(color: Colors.white10),

              // 4. 가격 입력 필드
              _buildPriceInput(),
              const Divider(color: Colors.white10),

              // 5. 거래 희망 지역 선택
              _buildSelectableRow(
                icon: Icons.location_on_outlined,
                label: '거래 희망 지역',
                onTap: controller.selectRegion,
                content: Obx(
                  () =>
                      AppFontDark(controller.region.value, color: Colors.white),
                ),
              ),
              const Divider(color: Colors.white10),

              // 6. 상품 설명 입력 필드
              _buildDescriptionInput(),
              const SizedBox(height: 50),
            ],
          ),
        ),
      ),
    );
  }

  // 위젯: 이미지 추가 섹션
  Widget _buildImageAddSection() {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10),
      height: 120,
      child: Row(
        children: [
          // 이미지 추가 버튼
          Container(
            width: 80,
            height: 80,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: Colors.grey.shade700),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(
                  Icons.camera_alt_outlined,
                  color: Colors.grey,
                  size: 28,
                ),
                const SizedBox(height: 5),
                // Obx: 현재 이미지 수 표시
                Obx(
                  () => AppFontDark(
                    '${controller.imageCount.value}/10',
                    color: Colors.grey,
                    fontSize: 13,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 15),
          // 여기에 선택된 이미지가 표시될 ListView가 들어갈 수 있습니다.
        ],
      ),
    );
  }

  // 위젯: 제목 입력 필드
  Widget _buildTitleInput() {
    return TextField(
      controller: controller.titleController,
      maxLength: 40, // 제목 최대 길이 제한
      style: const TextStyle(color: Colors.white, fontSize: 18),
      decoration: const InputDecoration(
        hintText: '제목',
        hintStyle: TextStyle(color: Colors.grey, fontSize: 18),
        border: InputBorder.none,
        counterText: "", // maxLength 카운터 제거
      ),
    );
  }

  // 위젯: 가격 입력 필드
  Widget _buildPriceInput() {
    return Row(
      children: [
        const Icon(Icons.attach_money, color: Colors.white),
        const SizedBox(width: 10),
        Expanded(
          child: TextField(
            controller: controller.priceController,
            keyboardType: TextInputType.number, // 숫자 키보드
            style: const TextStyle(color: Colors.white, fontSize: 18),
            decoration: const InputDecoration(
              hintText: '가격 (선택사항)',
              hintStyle: TextStyle(color: Colors.grey, fontSize: 18),
              border: InputBorder.none,
            ),
          ),
        ),
      ],
    );
  }

  // 위젯: 상품 설명 입력 필드
  Widget _buildDescriptionInput() {
    return TextField(
      controller: controller.descriptionController,
      maxLines: 15, // 여러 줄 입력 가능
      minLines: 5,
      style: const TextStyle(color: Colors.white, fontSize: 16),
      decoration: const InputDecoration(
        hintText: '게시글 내용을 작성해주세요. (판매 금지 품목은 게시가 제한될 수 있어요.)',
        hintStyle: TextStyle(color: Colors.grey, fontSize: 16),
        border: InputBorder.none,
      ),
    );
  }

  // 위젯: 선택 가능한 행 (카테고리/지역)
  Widget _buildSelectableRow({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    required Widget content,
  }) {
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 15.0),
        child: Row(
          children: [
            Icon(icon, color: Colors.white),
            const SizedBox(width: 15),
            Expanded(child: AppFontDark(label, fontSize: 16)),
            content, // 선택된 값 또는 힌트 표시
            const Icon(Icons.chevron_right, color: Colors.grey),
          ],
        ),
      ),
    );
  }
}
