import 'package:flutter/widgets.dart';
import 'package:get/get.dart';

// 판매 글 작성 페이지의 상태 및 로직을 관리하는 컨트롤러
class WriteController extends GetxController {
  // 1. 입력 필드 컨트롤러
  final TextEditingController titleController = TextEditingController();
  final TextEditingController descriptionController = TextEditingController();
  final TextEditingController priceController = TextEditingController();

  // 2. 상태 관리 Rx 변수
  RxInt imageCount = 0.obs; // 현재 선택된 이미지 개수
  RxnString category = RxnString(null); // 선택된 카테고리 (RxnString: nullable Rx)
  RxString region = '역삼동'.obs; // 거래 희망 지역 (초기값 설정)

  // 3. 완료 버튼 활성화 상태
  // 제목, 내용, 카테고리가 모두 입력되었을 때만 true를 반환
  RxBool get isReadyToSubmit =>
      (titleController.text.isNotEmpty &&
              descriptionController.text.isNotEmpty &&
              category.value != null)
          .obs;

  @override
  void onInit() {
    super.onInit();
    // 텍스트 필드 변경 감지 리스너 등록
    titleController.addListener(_updateReadyState);
    descriptionController.addListener(_updateReadyState);

    // 카테고리 선택 변경도 리스너에 포함되므로, 카테고리 Rx 변수에 리스너를 추가합니다.
    ever(category, (_) => _updateReadyState());
  }

  @override
  void onClose() {
    // 컨트롤러가 메모리에서 제거될 때 리스너 해제 및 컨트롤러 dispose
    titleController.dispose();
    descriptionController.dispose();
    priceController.dispose();
    super.onClose();
  }

  // 완료 버튼 상태 업데이트를 위한 더미 함수
  void _updateReadyState() {
    // GetX의 Obx가 isReadyToSubmit getter의 의존성을 자동으로 감지하므로
    // 이 함수는 단순히 상태 변화를 트리거하는 역할을 합니다.
    // 하지만, RxBool get isReadyToSubmit은 computed 속성이므로
    // 실제로는 GetBuilder나 Obx에서 직접 사용하면 됩니다.
    // 여기서는 명시적인 Rx 변수가 아니므로, titleController 등의 변경을 감지하기 위한 리스너로 사용됩니다.
    // GetX의 Rx 객체를 사용하면 훨씬 간결합니다.
    // 예시를 위해 RxBool getter를 사용하여 Obx에서 재계산되도록 합니다.
    // (실제로는 .obs가 붙지 않은 getter는 Obx가 자동으로 감지하지 못합니다.)
    // 코드가 실행되도록 RxBool get isReadyToSubmit 에서 .obs를 추가했습니다.
  }

  // 카테고리 선택 다이얼로그
  void selectCategory() async {
    final List<String> categories = [
      '디지털기기',
      '생활가전',
      '여성의류',
      '남성패션',
      '취미',
      '도서',
      '기타',
    ];
    final selected = await Get.dialog<String>(
      SimpleDialog(
        title: const Text(
          '카테고리 선택',
          style: TextStyle(color: Color(0xFF212123)),
        ),
        backgroundColor: Colors.white,
        children: categories
            .map(
              (cat) => SimpleDialogOption(
                onPressed: () => Get.back(result: cat),
                child: Text(
                  cat,
                  style: const TextStyle(color: Color(0xFF212123)),
                ),
              ),
            )
            .toList(),
      ),
    );
    if (selected != null) {
      category.value = selected;
    }
  }

  // 지역 선택 다이얼로그 (임시)
  void selectRegion() async {
    final List<String> regions = ['역삼동', '선릉역', '강남역'];
    final selected = await Get.dialog<String>(
      SimpleDialog(
        title: const Text(
          '거래 지역 선택',
          style: TextStyle(color: Color(0xFF212123)),
        ),
        backgroundColor: Colors.white,
        children: regions
            .map(
              (r) => SimpleDialogOption(
                onPressed: () => Get.back(result: r),
                child: Text(
                  r,
                  style: const TextStyle(color: Color(0xFF212123)),
                ),
              ),
            )
            .toList(),
      ),
    );
    if (selected != null) {
      region.value = selected;
    }
  }

  // 판매 글 등록 처리
  void submitPost() {
    if (isReadyToSubmit.value) {
      // 1. 데이터 수집
      final postData = {
        'title': titleController.text,
        'description': descriptionController.text,
        'price': priceController.text.isNotEmpty
            ? int.tryParse(priceController.text)
            : 0,
        'category': category.value,
        'region': region.value,
        'images': imageCount.value, // 실제로는 이미지 URL 목록이 들어가야 합니다.
        // 'userId': Get.find<AuthController>().user.value?.uid,
        'createdAt': DateTime.now().toIso8601String(),
      };

      // 2. Firebase/Firestore 저장 로직 실행 (더미)
      print("✅ 판매 글 등록 요청:");
      print(postData);

      // 3. 페이지 닫기
      Get.back();
      Get.snackbar(
        '알림',
        '글이 성공적으로 등록되었습니다.',
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: const Color(0xFFFF7E36),
        colorText: Colors.white,
      );
    } else {
      Get.snackbar(
        '경고',
        '제목, 내용, 카테고리는 필수 입력 사항입니다.',
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.redAccent,
        colorText: Colors.white,
      );
    }
  }
}
