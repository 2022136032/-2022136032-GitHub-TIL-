import 'package:get/get.dart';

// 앱 시작 시 필요한 데이터를 로드하는 로직을 관리하는 컨트롤러
class DataLoadController extends GetxController {
  // 데이터 로드 완료 상태 (RxBool)
  RxBool isDataLoad = false.obs;

  // 데이터 로드 함수 (실제 로직 대신 2초 지연 시뮬레이션)
  void loadData() async {
    // 임의로 2초 동안 대기
    await Future.delayed(const Duration(milliseconds: 2000));

    // 로드 완료 상태를 true로 변경
    isDataLoad(true);
  }
}
