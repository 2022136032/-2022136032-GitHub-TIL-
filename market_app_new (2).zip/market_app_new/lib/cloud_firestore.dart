import 'package:get/get.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'employee.model.dart';
// Firestore 환경 변수 사용을 위한 설정 (사용자 환경에서 제공되어야 함)
// const String __app_id = 'your_app_id';
// const String __firebase_config = '{"apiKey": "...", "projectId": "..."}';

// Firebase 및 Firestore 초기화 및 사용을 위한 전역 변수 설정 (Flutter 환경을 가정)
// 실제 앱에서는 main.dart에서 Firebase.initializeApp()을 통해 초기화해야 합니다.
final FirebaseFirestore _db = FirebaseFirestore.instance;

// 직원 목록을 관리하고 Firestore와 상호작용하는 GetX 컨트롤러입니다.
class EmployeeListController extends GetxController {
  // 현재 로드된 직원 목록을 저장하는 반응형 리스트
  final RxList<Employee> employees = <Employee>[].obs;
  // 데이터 로딩 상태
  final RxBool isLoading = true.obs;
  // 에러 메시지
  final RxString errorMessage = ''.obs;

  // Firestore 컬렉션 참조 (보안 규칙에 따라 경로 설정)
  // 'default-app-id'는 임시 값이며, 실제 앱 ID로 대체되어야 합니다.
  String get _appId => typeof __app_id !== 'undefined' ? __app_id : 'default-app-id';
  // 사용자의 UID 또는 임시 ID를 가져옵니다.
  // 실제 Flutter/Firebase 환경에서는 onAuthStateChanged를 통해 얻은 userId를 사용해야 합니다.
  final String _mockUserId = 'mock-user-123'; 
  
  // Firestore 경로: /artifacts/{appId}/users/{userId}/employees
  late final CollectionReference _employeeCollection;

  @override
  void onInit() {
    super.onInit();
    // Firestore 컬렉션 참조 초기화
    _employeeCollection = _db
        .collection('artifacts')
        .doc(_appId)
        .collection('users')
        .doc(_mockUserId) // 실제 앱에서는 인증된 userId를 사용해야 합니다.
        .collection('employees');
        
    // 실시간 데이터 리스너 설정
    fetchEmployeesRealtime();
  }

  // Firestore에서 직원 목록을 실시간으로 가져옵니다. (onSnapshot 사용)
  void fetchEmployeesRealtime() {
    isLoading.value = true;
    errorMessage.value = '';

    // onSnapshot을 사용하여 실시간으로 데이터를 동기화합니다.
    _employeeCollection
        .snapshots()
        .listen((snapshot) {
      final List<Employee> newEmployees = snapshot.docs.map((doc) {
        // Firestore 문서 ID를 Employee 모델의 id로 사용
        return Employee.fromMap(doc.data() as Map<String, dynamic>, doc.id);
      }).toList();
      
      // 메모리에서 연봉(salary) 기준으로 내림차순 정렬
      newEmployees.sort((a, b) => b.salary.compareTo(a.salary));

      // RxList 업데이트
      employees.assignAll(newEmployees);
      isLoading.value = false;
      print("Firestore 직원 목록 업데이트됨. 총 ${employees.length}명.");

    }, onError: (error) {
      errorMessage.value = '데이터를 불러오는 중 에러가 발생했습니다: $error';
      isLoading.value = false;
      print('Firestore Error: $error');
    });
  }

  // 새로운 직원을 Firestore에 추가합니다.
  Future<void> addEmployee(Employee newEmployee) async {
    try {
      await _employeeCollection.add(newEmployee.toMap());
      Get.snackbar('성공', '${newEmployee.name} 직원이 성공적으로 추가되었습니다.', 
          snackPosition: SnackPosition.BOTTOM);
    } catch (e) {
      errorMessage.value = '직원 추가에 실패했습니다: $e';
      Get.snackbar('오류', '직원 추가에 실패했습니다.', 
          snackPosition: SnackPosition.BOTTOM, colorText: Colors.red);
      print('Error adding employee: $e');
    }
  }

  // 기존 직원의 정보를 업데이트합니다.
  Future<void> updateEmployee(Employee updatedEmployee) async {
    try {
      // document ID를 사용하여 업데이트
      await _employeeCollection.doc(updatedEmployee.id).update(updatedEmployee.toMap());
      Get.snackbar('성공', '${updatedEmployee.name} 직원의 정보가 업데이트되었습니다.', 
          snackPosition: SnackPosition.BOTTOM);
    } catch (e) {
      errorMessage.value = '직원 정보 업데이트에 실패했습니다: $e';
      Get.snackbar('오류', '업데이트에 실패했습니다.', 
          snackPosition: SnackPosition.BOTTOM, colorText: Colors.red);
      print('Error updating employee: $e');
    }
  }

  // 직원을 Firestore에서 삭제합니다.
  Future<void> deleteEmployee(String employeeId) async {
    try {
      await _employeeCollection.doc(employeeId).delete();
      Get.snackbar('성공', '직원이 삭제되었습니다.', 
          snackPosition: SnackPosition.BOTTOM);
    } catch (e) {
      errorMessage.value = '직원 삭제에 실패했습니다: $e';
      Get.snackbar('오류', '삭제에 실패했습니다.', 
          snackPosition: SnackPosition.BOTTOM, colorText: Colors.red);
      print('Error deleting employee: $e');
    }
  }
}