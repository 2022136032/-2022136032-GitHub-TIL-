import 'package:get/get.dart';
import 'package:karrot_app_clone/common/controller/auth_controller.dart';
import 'package:karrot_app_clone/services/firestore_service.dart';

// 앱이 시작될 때 단 한 번만 실행되어 전역적으로 사용될 Service와 Controller를 생성
class AppBinding extends Bindings {
  @override
  void dependencies() {
    // Services: 앱 전역에서 접근 가능해야 하므로 Get.put으로 영구적으로 생성
    // Firestore 서비스
    Get.put<FirestoreService>(FirestoreService(), permanent: true);

    // Controllers: 앱 전역 상태를 관리하는 인증 컨트롤러
    // AuthController는 앱 실행 내내 유지되어야 하므로 permanent: true로 생성
    Get.put<AuthController>(AuthController(), permanent: true);

    // 기타 전역 서비스 및 컨트롤러를 여기에 추가합니다.
  }
}
