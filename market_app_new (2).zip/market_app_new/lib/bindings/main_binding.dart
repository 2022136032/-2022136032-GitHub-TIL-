import 'package:get/get.dart';
import 'package:karrot_app_clone/common/controller/main_controller.dart';
import 'package:karrot_app_clone/pages/townlife/town_life_controller.dart';

// MainScreen에서 사용되는 컨트롤러들을 바인딩
class MainBinding extends Bindings {
  @override
  void dependencies() {
    // 탭 전환을 관리하는 MainController
    Get.lazyPut<MainController>(() => MainController());

    // 동네생활 페이지 관련 컨트롤러
    Get.lazyPut<TownLifeController>(() => TownLifeController());

    // Home Controller 등 다른 탭 컨트롤러들도 여기에 추가됩니다.
    // Get.lazyPut<HomeController>(() => HomeController());
  }
}
