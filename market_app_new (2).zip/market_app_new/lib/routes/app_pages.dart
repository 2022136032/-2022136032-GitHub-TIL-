import 'package:get/get.dart';
import 'package:karrot_app_clone/main_screen.dart';
import 'package:karrot_app_clone/pages/home/home_page.dart'; // 더미 페이지 대신 실제 페이지 사용 가능
import 'package:karrot_app_clone/routes/app_routes.dart';

class AppPages {
  static final pages = [
    GetPage(name: AppRoutes.MAIN, page: () => const MainScreen()),
    // 추가 페이지 정의 가능
  ];
}

// 앱의 모든 경로(Route)와 해당 화면(Page)을 매핑하고 바인딩을 연결합니다.
class AppPages {
  // 기본 전환 효과: Platform.isIOS ? Transition.cupertino : Transition.rightToLeft
  static final List<GetPage> pages = [
    // 1. Splash
    GetPage(
      name: AppRoutes.SPLASH,
      page: () => const SplashPage(),
      binding: SplashBinding(),
    ),

    // 2. Main (탭 컨테이너)
    GetPage(
      name: AppRoutes.MAIN,
      page: () => const MainScreen(),
      binding:
          MainBinding(), // MainController, HomeContoller 등 모든 탭 관련 컨트롤러 바인딩
    ),

    // 3. Auth (로그인/회원가입)
    GetPage(
      name: AppRoutes.AUTH,
      page: () => const AuthPage(),
      binding: AuthBinding(),
    ),

    // 4. Product Detail
    GetPage(
      name: AppRoutes.PRODUCT_DETAIL,
      page: () => const ProductDetailPage(),
      binding: MainBinding(), // 필요한 경우 별도 바인딩 정의
    ),

    // 5. Product Write
    GetPage(
      name: AppRoutes.PRODUCT_WRITE,
      page: () => const ProductWritePage(),
      binding: MainBinding(), // 필요한 경우 별도 바인딩 정의
    ),

    // 여기에 추가적인 라우트 정의를 추가합니다. (예: 채팅방, 프로필 수정 등)
  ];
}

// --- 페이지 바인딩/더미 위젯 (라우팅이 동작하도록 임시 정의) ---

// 더미 페이지들
class AuthPage extends StatelessWidget {
  const AuthPage({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('인증')),
      body: const Center(child: Text('로그인 / 회원가입 화면')),
    );
  }
}

class ProductDetailPage extends StatelessWidget {
  const ProductDetailPage({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('상품 상세')),
      body: const Center(child: Text('상품 상세 페이지')),
    );
  }
}

class ProductWritePage extends StatelessWidget {
  const ProductWritePage({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('상품 등록')),
      body: const Center(child: Text('상품 등록 페이지')),
    );
  }
}

// 더미 바인딩
class SplashBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => SplashController());
  }
}

class MainBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => MainController());
  }
}

class AuthBinding extends Bindings {
  @override
  void dependencies() {
    // Auth 페이지에서 필요한 컨트롤러 바인딩
  }
}
