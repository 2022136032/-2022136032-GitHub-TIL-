import 'package:get/get.dart';

// 동네생활 페이지의 상태 및 로직을 관리하는 컨트롤러
class TownLifeController extends GetxController {
  // 동네생활 게시글 목록 상태 (실제로는 ProductModel이나 별도의 TownPostModel 목록이 될 수 있음)
  RxList<String> posts = <String>[].obs;
  RxBool isLoading = false.obs;

  @override
  void onInit() {
    super.onInit();
    fetchTownLifePosts();
  }

  // 동네생활 게시글 데이터를 가져오는 함수 (더미 로직)
  Future<void> fetchTownLifePosts() async {
    isLoading(true);
    print("⏳ 동네생활 게시글 로딩 시작...");

    // 데이터 로딩 시뮬레이션
    await Future.delayed(const Duration(seconds: 1));

    // 더미 데이터 업데이트
    posts.assignAll([
      '우리 동네 붕어빵 맛집 추천해주세요!',
      '혹시 고장난 자전거 수리점 아시는 분?',
      '오늘 저녁은 뭘 먹을까요? 투표!',
      '길냥이가 다쳤어요 ㅠㅠ 도움 요청!',
    ]);

    isLoading(false);
    print("✅ 동네생활 게시글 로딩 완료: ${posts.length}개");
  }

  // 게시글 작성 페이지로 이동
  void navigateToWritePost() {
    // 실제로는 별도의 동네생활 글쓰기 페이지로 이동
    Get.toNamed('/town-life-write');
  }
}
