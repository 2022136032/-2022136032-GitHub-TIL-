import 'package:flutter/material.dart';

// 원형 프로필 이미지 위젯
class CircleImage extends StatelessWidget {
  final String imageUrl;
  final double size; // 지름 크기
  final BoxFit fit;

  const CircleImage({
    super.key,
    required this.imageUrl,
    this.size = 60.0,
    this.fit = BoxFit.cover,
  });

  @override
  Widget build(BuildContext context) {
    // 이미지가 로드될 때까지 표시되는 기본 아이콘
    const placeholder = Icon(Icons.person, color: Colors.white, size: 30);

    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: Colors.grey.shade700, // 로딩 중 배경색
      ),
      child: ClipOval(
        child: Image.network(
          imageUrl,
          width: size,
          height: size,
          fit: fit,
          loadingBuilder: (context, child, loadingProgress) {
            if (loadingProgress == null) return child;
            return Center(
              child: CircularProgressIndicator(
                value: loadingProgress.expectedTotalBytes != null
                    ? loadingProgress.cumulativeBytesLoaded /
                          loadingProgress.expectedTotalBytes!
                    : null,
                strokeWidth: 2,
                valueColor: const AlwaysStoppedAnimation<Color>(Colors.white),
              ),
            );
          },
          errorBuilder: (context, error, stackTrace) {
            // 이미지 로드 실패 시 대체 아이콘 표시
            print("❌ CircleImage: 이미지 로드 오류: $error");
            return const Center(child: placeholder);
          },
        ),
      ),
    );
  }
}
