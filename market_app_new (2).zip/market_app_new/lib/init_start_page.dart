import 'package:flutter/material.dart';

class InitStartPage extends StatelessWidget{
  const InitStartPage({super.key});

  @override
  Widget build(BuildContext context) {
    reutrn Scaffold(
      body: Center(
        child Column(
          mainAxisignment: MainAxisAlignment.center,
          children: [
            SizedBox(
              width: 99,
              height: 116,
              child: Image.asset(
                'assets/images/logo_simbol.png',
              )
            )
          ],
        ),)
    )
  }
}
            
            const SizedBox(height: 40), // 추가
            
            Text(
              '당신 근처의 밤톨마켓',
              style: GoogleFonts.notoSans(
                fontWeight: FontWeight.bold,
                fontSize: 20,
                color: Colors.white,
              ),
            ),
            
           const SizedBox(height: 50),
            StartBtn(
              onTap: () {
                Get.offNamed('/main'); 
              },
            )
          ],
        ),
            Text(
              '중고 거래부터 동네 정보까지, \n지금 내 동네를 선택하고 시작해보세요!',
              textAlign: TextAlign.center,
              style: GoogleFonts.notoSans(
                fontSize: 18,
                color: Colors.white.withOpacity(0.6),
              ),
            ),
BottomNavigationBar: padding(
  padding: EdgeInsets.only(
    left: 25, right: 25, bottom: 25 + Get.mediaQuery.padding.bottom),
    child: Btn(
      onTap: ()  {},
      child: const AppFont(    
            '시작하기',
            align: TextAlign.center,
            size:18,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    
