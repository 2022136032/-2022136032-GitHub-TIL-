// heic_conversion_app.dart

import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';

// -----------------------------------------------------------------------------
// [1] 데이터 모델 및 서비스
// -----------------------------------------------------------------------------

/// 간단한 UUID 생성을 위한 Random 인스턴스입니다.
final Random _random = Random();

/// HEIC 파일을 나타내는 데이터 모델 클래스입니다.
class HeicFile {
  final String id;
  final String fileName;
  final String originalMimeType;
  final double originalSizeKB; // 파일 크기 시뮬레이션 (KB)

  // UI 상태 관리를 위해 추가된 필드
  ConversionResult? conversionResult;

  HeicFile({
    required this.id,
    required this.fileName,
    required this.originalSizeKB,
    this.originalMimeType = 'image/heic',
    this.conversionResult,
  });

  // 파일 이름을 기반으로 초기화하는 팩토리 생성자
  factory HeicFile.fromFileName(String fileName) {
    return HeicFile(
      id: HeicConversionService.generateUuid(),
      fileName: fileName,
      originalSizeKB: 2000 + (_random.nextDouble() * 5000), // 2MB ~ 7MB
    );
  }

  // 상태 업데이트를 위한 복사 메소드
  HeicFile copyWith({ConversionResult? conversionResult}) {
    return HeicFile(
      id: id,
      fileName: fileName,
      originalMimeType: originalMimeType,
      originalSizeKB: originalSizeKB,
      conversionResult: conversionResult ?? this.conversionResult,
    );
  }
}

/// 파일 변환 작업의 결과를 담는 클래스입니다.
class ConversionResult {
  final String status; // 'Pending', 'Converting', 'Converted', 'Failed'
  final String? newFileName;
  final double? convertedSizeKB; // 변환된 파일 크기 (KB)
  final String? error;

  ConversionResult({
    required this.status,
    this.newFileName,
    this.convertedSizeKB,
    this.error,
  });

  ConversionResult.pending()
    : status = 'Pending',
      newFileName = null,
      convertedSizeKB = null,
      error = null;

  ConversionResult.converting()
    : status = 'Converting',
      newFileName = null,
      convertedSizeKB = null,
      error = null;

  ConversionResult.success(this.newFileName, this.convertedSizeKB)
    : status = 'Converted',
      error = null;

  ConversionResult.failure(this.error)
    : status = 'Failed',
      newFileName = null,
      convertedSizeKB = null;
}

/// 파일 목록을 관리하고 HEIC 변환을 시뮬레이션하는 서비스 클래스입니다.
class HeicConversionService {
  /// 특정 HEIC 파일에 대한 변환 과정을 시뮬레이션합니다.
  Future<ConversionResult> simulateConversion(HeicFile file) async {
    // 1초 ~ 3초 사이의 지연 시간 시뮬레이션
    final delay = Duration(milliseconds: 1000 + _random.nextInt(2000));
    await Future.delayed(delay);

    // 90%의 성공률 시뮬레이션
    if (_random.nextDouble() > 0.1) {
      // 파일 확장자를 .jpg로 변경합니다. (크기는 HEIC 크기의 약 110%로 시뮬레이션)
      final newFileName = file.fileName.replaceAll(
        RegExp(r'\.heic$', caseSensitive: false),
        '.jpg',
      );
      final newSize =
          file.originalSizeKB * (1.05 + (_random.nextDouble() * 0.1));
      return ConversionResult.success(newFileName, newSize);
    } else {
      const error = '파일 헤더 손상 또는 메모리 부족으로 변환에 실패했습니다.';
      return ConversionResult.failure(error);
    }
  }

  /// 간단한 6자리 UUID를 생성합니다.
  static String generateUuid() {
    return _random.nextInt(999999).toString().padLeft(6, '0');
  }
}

// -----------------------------------------------------------------------------
// [2] 파일 목록 화면 (ImageListView)
// -----------------------------------------------------------------------------

/// 파일 목록을 표시하고 변환을 제어하는 메인 위젯
class ImageListView extends StatefulWidget {
  final List<String> uploadedFileNames;
  const ImageListView({super.key, required this.uploadedFileNames});

  @override
  State<ImageListView> createState() => _ImageListViewState();
}

class _ImageListViewState extends State<ImageListView> {
  final HeicConversionService _service = HeicConversionService();
  List<HeicFile> _files = [];
  bool _isConverting = false;

  @override
  void initState() {
    super.initState();
    _initializeFiles(widget.uploadedFileNames);
  }

  /// 초기 파일 목록 설정
  void _initializeFiles(List<String> fileNames) {
    setState(() {
      _files = fileNames
          .map((name) => HeicFile.fromFileName(name))
          .map(
            (file) =>
                file.copyWith(conversionResult: ConversionResult.pending()),
          )
          .toList();
    });
  }

  /// 개별 파일 변환 시작 및 상태 업데이트
  Future<void> _startConversion(String fileId) async {
    final fileIndex = _files.indexWhere((f) => f.id == fileId);
    if (fileIndex == -1 ||
        _files[fileIndex].conversionResult?.status == 'Converting' ||
        _files[fileIndex].conversionResult?.status == 'Converted')
      return;

    // 1. 상태를 'Converting'으로 변경
    setState(() {
      _files[fileIndex] = _files[fileIndex].copyWith(
        conversionResult: ConversionResult.converting(),
      );
    });

    try {
      // 2. 변환 시뮬레이션 실행
      final result = await _service.simulateConversion(_files[fileIndex]);

      // 3. 최종 결과로 상태 업데이트
      setState(() {
        _files[fileIndex] = _files[fileIndex].copyWith(
          conversionResult: result,
        );
      });
    } catch (e) {
      // 4. 오류 발생 시 상태 업데이트
      setState(() {
        _files[fileIndex] = _files[fileIndex].copyWith(
          conversionResult: ConversionResult.failure('예상치 못한 오류 발생'),
        );
      });
    }
  }

  /// 모든 변환 작업을 일괄 시작
  Future<void> _startAllConversions() async {
    // 이미 변환 중인 경우 중복 실행 방지
    if (_isConverting) return;

    setState(() {
      _isConverting = true;
    });

    final pendingFiles = _files
        .where(
          (f) =>
              f.conversionResult?.status == 'Pending' ||
              f.conversionResult?.status == 'Failed',
        )
        .toList();

    // 변환 작업을 병렬로 실행
    await Future.wait(pendingFiles.map((file) => _startConversion(file.id)));

    setState(() {
      _isConverting = false;
    });

    _checkAndNavigateToSummary();
  }

  /// 파일 제거
  void _removeFile(String fileId) {
    setState(() {
      _files.removeWhere((file) => file.id == fileId);
    });
    _checkAndNavigateToSummary();
  }

  /// 변환이 모두 완료되었는지 확인하고 요약 화면으로 이동
  void _checkAndNavigateToSummary() {
    final hasPendingOrConverting = _files.any(
      (f) =>
          f.conversionResult?.status == 'Pending' ||
          f.conversionResult?.status == 'Converting',
    );

    // 변환 완료 상태이고, 최소한 하나의 성공 파일이 있을 때 이동
    if (!_isConverting &&
        !hasPendingOrConverting &&
        _files.any((f) => f.conversionResult?.status == 'Converted')) {
      Navigator.of(context)
          .push(
            MaterialPageRoute(
              builder: (context) => DownloadSummaryScreen(files: _files),
            ),
          )
          .then((_) {
            // 요약 화면에서 돌아왔을 때, 상태를 초기화하거나 새로고침할 수 있음
          });
    }
  }

  @override
  Widget build(BuildContext context) {
    final pendingOrFailedCount = _files
        .where(
          (f) =>
              f.conversionResult?.status == 'Pending' ||
              f.conversionResult?.status == 'Failed',
        )
        .length;
    final totalFiles = _files.length;
    final allDone =
        !_isConverting && pendingOrFailedCount == 0 && totalFiles > 0;

    return Scaffold(
      appBar: AppBar(
        title: Text(
          'HEIC 파일 일괄 변환 (총 $totalFiles개)',
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.indigo,
        foregroundColor: Colors.white,
        elevation: 0,
      ),
      body: Column(
        children: [
          _buildSummaryCard(),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
            child: Text(
              '변환할 파일 목록:',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
          ),
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.only(
                left: 16.0,
                right: 16.0,
                bottom: 80,
              ),
              itemCount: _files.length,
              itemBuilder: (context, index) {
                final file = _files[index];
                return _FileListItem(
                  file: file,
                  onConvert: _startConversion,
                  onRemove: _removeFile,
                );
              },
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: allDone
            ? () => _checkAndNavigateToSummary()
            : (pendingOrFailedCount > 0 ? _startAllConversions : null),
        label: Text(
          allDone
              ? '결과 확인 (${_files.where((f) => f.conversionResult?.status == 'Converted').length}개 완료)'
              : (_isConverting
                    ? '변환 진행 중...'
                    : '모두 변환 시작 ($pendingOrFailedCount개 대기)'),
        ),
        icon: allDone
            ? const Icon(Icons.download)
            : (_isConverting
                  ? const CircularProgressIndicator(color: Colors.white)
                  : const Icon(Icons.flash_on)),
        backgroundColor: allDone
            ? Colors.teal
            : (_isConverting ? Colors.indigo.shade300 : Colors.indigo),
        foregroundColor: Colors.white,
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
    );
  }

  Widget _buildSummaryCard() {
    final convertedCount = _files
        .where((f) => f.conversionResult?.status == 'Converted')
        .length;
    final failedCount = _files
        .where((f) => f.conversionResult?.status == 'Failed')
        .length;
    final pendingCount = _files.length - convertedCount - failedCount;

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      margin: const EdgeInsets.fromLTRB(16, 16, 16, 8),
      decoration: BoxDecoration(
        color: Colors.indigo.shade50,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 4),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _buildStatusChip(convertedCount, '✅ 완료', Colors.green),
          _buildStatusChip(pendingCount, '⏳ 대기/진행', Colors.orange),
          _buildStatusChip(failedCount, '❌ 실패', Colors.red),
        ],
      ),
    );
  }

  Widget _buildStatusChip(int count, String label, Color color) {
    return Column(
      children: [
        Text(
          '$count',
          style: TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.bold,
            color: color.shade800,
          ),
        ),
        const SizedBox(height: 4),
        Text(label, style: TextStyle(fontSize: 14, color: color.shade600)),
      ],
      mainAxisSize: MainAxisSize.min,
    );
  }
}

/// 개별 파일 항목을 위한 위젯
class _FileListItem extends StatelessWidget {
  final HeicFile file;
  final Function(String) onConvert;
  final Function(String) onRemove;

  const _FileListItem({
    required this.file,
    required this.onConvert,
    required this.onRemove,
  });

  String _formatSize(double? kb) {
    if (kb == null) return 'N/A';
    if (kb < 1024) return '${kb.toStringAsFixed(1)} KB';
    return '${(kb / 1024).toStringAsFixed(2)} MB';
  }

  @override
  Widget build(BuildContext context) {
    final status = file.conversionResult?.status ?? 'Pending';
    final result = file.conversionResult;
    final isConverting = status == 'Converting';
    final isConverted = status == 'Converted';

    Color statusColor;
    IconData statusIcon;
    String statusText;

    switch (status) {
      case 'Converted':
        statusColor = Colors.green;
        statusIcon = Icons.check_circle;
        statusText = '변환 완료 (${_formatSize(result!.convertedSizeKB)})';
        break;
      case 'Failed':
        statusColor = Colors.red;
        statusIcon = Icons.error;
        statusText = '변환 실패: ${result!.error!}';
        break;
      case 'Converting':
        statusColor = Colors.indigo;
        statusIcon = Icons.autorenew;
        statusText = '변환 중...';
        break;
      case 'Pending':
      default:
        statusColor = Colors.grey;
        statusIcon = Icons.file_present;
        statusText = '대기 중 (${_formatSize(file.originalSizeKB)})';
    }

    return Card(
      margin: const EdgeInsets.only(bottom: 8.0),
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: ListTile(
        leading: isConverting
            ? CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation<Color>(
                  Colors.indigo.shade400,
                ),
              )
            : Icon(statusIcon, color: statusColor, size: 30),
        title: Text(
          file.fileName,
          style: const TextStyle(fontWeight: FontWeight.w600),
          overflow: TextOverflow.ellipsis,
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'ID: ${file.id}',
              style: const TextStyle(fontSize: 12, color: Colors.grey),
            ),
            const SizedBox(height: 4),
            Text(
              statusText,
              style: TextStyle(
                fontSize: 13,
                color: statusColor.shade700,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (!isConverting && !isConverted)
              ElevatedButton(
                onPressed: () => onConvert(file.id),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.indigo,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 8,
                  ),
                ),
                child: const Text('변환', style: TextStyle(fontSize: 14)),
              ),
            IconButton(
              icon: Icon(
                Icons.delete,
                color: isConverted ? Colors.red.shade200 : Colors.grey,
              ),
              onPressed: isConverting ? null : () => onRemove(file.id),
              tooltip: '제거',
            ),
          ],
        ),
      ),
    );
  }
}

// -----------------------------------------------------------------------------
// [3] 다운로드 요약 화면 (DownloadSummaryScreen)
// -----------------------------------------------------------------------------

class DownloadSummaryScreen extends StatefulWidget {
  final List<HeicFile> files;

  const DownloadSummaryScreen({super.key, required this.files});

  @override
  State<DownloadSummaryScreen> createState() => _DownloadSummaryScreenState();
}

class _DownloadSummaryScreenState extends State<DownloadSummaryScreen> {
  bool _isDownloading = false;
  double _downloadProgress = 0.0;
  String _downloadStatus = '다운로드 준비 완료';

  List<HeicFile> get _convertedFiles => widget.files
      .where((f) => f.conversionResult?.status == 'Converted')
      .toList();

  double get _totalSizeKB {
    return _convertedFiles.fold(
      0.0,
      (sum, file) => sum + (file.conversionResult?.convertedSizeKB ?? 0.0),
    );
  }

  String _formatTotalSize(double kb) {
    if (kb < 1024) return '${kb.toStringAsFixed(1)} KB';
    return '${(kb / 1024).toStringAsFixed(2)} MB';
  }

  Future<void> _simulateDownload() async {
    if (_isDownloading) return;

    setState(() {
      _isDownloading = true;
      _downloadProgress = 0.0;
      _downloadStatus = '파일 압축 및 다운로드 중...';
    });

    // 다운로드 시뮬레이션
    const totalSteps = 100;
    const duration = Duration(milliseconds: 20); // 총 2초

    for (int i = 0; i <= totalSteps; i++) {
      await Future.delayed(duration);
      setState(() {
        _downloadProgress = i / totalSteps;
      });
      if (i == 50) {
        setState(() {
          _downloadStatus = '보안 검사 통과 및 전송 중...';
        });
      }
    }

    setState(() {
      _isDownloading = false;
      _downloadStatus = '다운로드 완료! (파일: converted_images.zip)';
    });

    // 완료 알림
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('다운로드 완료! ${_convertedFiles.length}개 파일이 저장되었습니다.'),
        backgroundColor: Colors.teal,
      ),
    );
  }

  @override
  Widget build(BuildContext) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          '변환 결과 요약',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.teal,
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildInfoCard(
              Icons.check_circle_outline,
              '변환 성공',
              '총 ${_convertedFiles.length}개의 파일이 JPG 형식으로 변환되었습니다.',
              Colors.green,
            ),
            const SizedBox(height: 16),
            _buildInfoCard(
              Icons.save,
              '총 파일 크기',
              _formatTotalSize(_totalSizeKB),
              Colors.blue,
            ),
            const SizedBox(height: 24),
            _buildDownloadArea(),
            const SizedBox(height: 24),
            _buildConvertedFileList(),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoCard(
    IconData icon,
    String title,
    String subtitle,
    Color color,
  ) {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: ListTile(
        contentPadding: const EdgeInsets.all(16),
        leading: Icon(icon, size: 40, color: color.shade700),
        title: Text(
          title,
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            color: color.shade800,
          ),
        ),
        subtitle: Text(subtitle, style: const TextStyle(fontSize: 14)),
      ),
    );
  }

  Widget _buildDownloadArea() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          '다운로드 진행',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: Colors.teal.shade700,
          ),
        ),
        const Divider(),
        const SizedBox(height: 10),

        LinearProgressIndicator(
          value: _downloadProgress,
          backgroundColor: Colors.grey.shade300,
          valueColor: AlwaysStoppedAnimation<Color>(Colors.teal),
        ),
        const SizedBox(height: 8),
        Text(
          _downloadStatus,
          style: TextStyle(
            color: _isDownloading ? Colors.indigo : Colors.black87,
          ),
        ),
        const SizedBox(height: 20),
        Center(
          child: ElevatedButton.icon(
            onPressed: _isDownloading ? null : _simulateDownload,
            icon: const Icon(Icons.archive),
            label: Text(_isDownloading ? '다운로드 중...' : '모두 다운로드 (.zip)'),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.teal,
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 15),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
              textStyle: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildConvertedFileList() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          '변환된 파일 목록',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: Colors.teal.shade700,
          ),
        ),
        const Divider(),
        ..._convertedFiles
            .map(
              (file) => Padding(
                padding: const EdgeInsets.only(bottom: 8.0),
                child: Row(
                  children: [
                    const Icon(Icons.image, color: Colors.grey),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        file.conversionResult!.newFileName!,
                        style: const TextStyle(fontSize: 15),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    Text(
                      _formatTotalSize(file.conversionResult!.convertedSizeKB!),
                      style: const TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        color: Colors.black54,
                      ),
                    ),
                  ],
                ),
              ),
            )
            .toList(),
      ],
    );
  }
}

// -----------------------------------------------------------------------------
// [4] Flutter 애플리케이션 진입점
// -----------------------------------------------------------------------------

void main() {
  // 이전 요청(28개)과 현재 요청(8개)에서 업로드된 파일을 통합하여 시뮬레이션 목록을 업데이트합니다. (총 36개)
  final List<String> simulatedFiles = List.generate(
    36,
    (index) => 'DSC_${(1001 + index).toString().padLeft(4, '0')}.heic',
  );

  runApp(HeicConverterApp(uploadedFileNames: simulatedFiles));
}

class HeicConverterApp extends StatelessWidget {
  final List<String> uploadedFileNames;
  const HeicConverterApp({super.key, required this.uploadedFileNames});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'HEIC Converter Demo',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.indigo,
        visualDensity: VisualDensity.adaptivePlatformDensity,
        fontFamily: 'Roboto',
        useMaterial3: true,
      ),
      home: ImageListView(uploadedFileNames: uploadedFileNames),
    );
  }
}
