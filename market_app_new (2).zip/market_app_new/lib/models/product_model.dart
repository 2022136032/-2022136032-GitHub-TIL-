import 'package:cloud_firestore/cloud_firestore.dart';

// 중고거래 상품 게시글의 데이터 모델
class ProductModel {
  final String id; // Firestore Document ID (생성 후 업데이트)
  final String sellerUid; // 판매자 UID
  final String title;
  final String content;
  final int price; // 가격 (원 단위)
  final List<String> imageUrls; // 상품 이미지 URL 목록
  final String category;
  final String town; // 거래 희망 동네
  final String status; // '판매중', '예약중', '판매완료'
  final int chatCount;
  final int likeCount;
  final DateTime postedAt; // 게시 시각

  ProductModel({
    this.id = '',
    required this.sellerUid,
    required this.title,
    required this.content,
    required this.price,
    this.imageUrls = const [],
    required this.category,
    required this.town,
    this.status = '판매중',
    this.chatCount = 0,
    this.likeCount = 0,
    required this.postedAt,
  });

  // 1. JSON (Map)으로 변환
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'sellerUid': sellerUid,
      'title': title,
      'content': content,
      'price': price,
      'imageUrls': imageUrls,
      'category': category,
      'town': town,
      'status': status,
      'chatCount': chatCount,
      'likeCount': likeCount,
      'postedAt': Timestamp.fromDate(postedAt), // Firestore Timestamp으로 변환
    };
  }

  // 2. Firestore DocumentSnapshot에서 ProductModel 생성
  factory ProductModel.fromSnapshot(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return ProductModel(
      id: doc.id, // Document ID를 모델의 ID로 사용
      sellerUid: data['sellerUid'] ?? '',
      title: data['title'] ?? '제목 없음',
      content: data['content'] ?? '',
      price: data['price'] ?? 0,
      imageUrls: List<String>.from(data['imageUrls'] ?? []),
      category: data['category'] ?? '기타',
      town: data['town'] ?? '알 수 없음',
      status: data['status'] ?? '판매중',
      chatCount: data['chatCount'] ?? 0,
      likeCount: data['likeCount'] ?? 0,
      // Firestore Timestamp을 DateTime으로 변환
      postedAt: (data['postedAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
    );
  }
}
