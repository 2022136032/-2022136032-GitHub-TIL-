// lib/home_controll.dart
import 'models.dart';

// 홈 화면의 상태와 비즈니스 로직을 관리하는 클래스입니다.
// 실제 Flutter 환경에서는 'Provider'나 'GetX'와 같은 상태 관리 툴을 사용합니다.
class HomeController {
  // 임시 상품 목록 데이터
  final List<Product> _productList = [
    Product(id: 1, name: '사과', price: 2500.0, stockQuantity: 100),
    Product(id: 2, name: '바나나', price: 3000.0, stockQuantity: 50),
    Product(id: 3, name: '오렌지', price: 5000.0, stockQuantity: 75),
    Product(id: 4, name: '딸기', price: 12000.0, stockQuantity: 20),
  ];

  // UI에서 접근할 수 있도록 상품 목록을 반환합니다.
  List<Product> get products => _productList;

  // 특정 상품의 재고를 변경하는 메서드 (간단한 예시 로직)
  void updateStock(int productId, int change) {
    try {
      final product = _productList.firstWhere((p) => p.id == productId);
      // 재고 업데이트
      product.stockQuantity += change;
      print('${product.name} 재고 업데이트됨: ${product.stockQuantity}');
    } catch (e) {
      print('오류: ID $productId 를 가진 상품을 찾을 수 없습니다.');
    }
  }

  // 총 등록된 상품의 개수를 반환합니다.
  int get totalProductCount => _productList.length;
}
