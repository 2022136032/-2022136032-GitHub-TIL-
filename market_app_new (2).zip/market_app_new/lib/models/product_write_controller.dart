// controllers/product_write_controller.dart
import '../models/product.dart';
import '../repositories/product_repository.dart';

/// 상품 등록 페이지의 비즈니스 로직을 처리하는 컨트롤러입니다.
class ProductWriteController {
  final ProductRepository _repository;

  ProductWriteController(this._repository);

  /// 상품 등록을 처리하고 결과를 반환합니다.
  Future<void> registerProduct(
    String appId,
    String userId,
    Map<String, dynamic> productData,
    Function(String, bool) onStatusUpdate,
  ) async {
    onStatusUpdate('상품 등록 중...', true);

    if (userId.isEmpty || appId.isEmpty) {
      onStatusUpdate('인증 정보(App ID 또는 User ID)가 누락되었습니다.', false);
      return;
    }

    try {
      // 1. 입력 데이터 유효성 검증
      final name = productData['name'] as String?;
      final price = productData['price'] as int?;
      final stockQuantity = productData['stockQuantity'] as int?;
      final category = productData['category'] as String?;
      final description = productData['description'] as String?;

      if (name == null ||
          name.isEmpty ||
          price == null ||
          price <= 0 ||
          stockQuantity == null ||
          stockQuantity < 0 ||
          category == null ||
          category.isEmpty ||
          description == null ||
          description.isEmpty) {
        onStatusUpdate(
          '모든 필수 항목을 입력하고 가격을 1원 이상, 재고 수량을 0개 이상으로 설정하세요.',
          false,
        );
        return;
      }

      // 2. Product 모델 생성
      final newProduct = Product(
        name: name,
        price: price,
        stockQuantity: stockQuantity,
        category: category,
        description: description,
        imageUrl: productData['imageUrl'] as String?,
        userId: userId,
      );

      // 3. Repository를 통해 저장
      final productId = await _repository.saveProduct(
        appId,
        userId,
        newProduct,
      );

      onStatusUpdate('✅ 상품이 성공적으로 등록되었습니다! (ID: $productId)', true);
    } catch (e) {
      onStatusUpdate('❌ 상품 등록 실패: ${e.toString()}', false);
    }
  }
}
