import 'package:get/get.dart';
import 'package:get/get.dart';

class MainController extends GetxController {
  final RxInt selectedIndex = 0.obs;

  void changeIndex(int index) {
    selectedIndex.value = index;
  }
}

// 메인 화면(MainScreen)의 Bottom Navigation Bar 상태를 관리하는 컨트롤러
class MainController extends GetxController {
  // 현재 선택된 탭의 인덱스 (0: 홈, 1: 동네생활, 2: 내 근처, 3: 채팅, 4: 나의 당근)
  final RxInt selectedIndex = 0.obs;

  // 탭 변경 함수
  void changeIndex(int index) {
    if (index == selectedIndex.value) return; // 같은 탭을 다시 누르면 무시

    selectedIndex.value = index;
    print("▶️ MainController: 탭 변경 -> $index");
  }

  // 특정 인덱스로 이동
  void jumpTo(int index) {
    changeIndex(index);
  }
}
