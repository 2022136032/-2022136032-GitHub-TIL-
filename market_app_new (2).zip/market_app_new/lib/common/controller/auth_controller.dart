import 'package:get/get.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:karrot_app_clone/models/user_model.dart';
import 'package:karrot_app_clone/services/firestore_service.dart';

// 인증 상태를 관리하고, 로그인/로그아웃/회원가입 로직을 담당하는 컨트롤러
class AuthController extends GetxController {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirestoreService _firestoreService = Get.find<FirestoreService>();

  // 1. Rx Status: 사용자의 인증 상태 (null: 로딩 중, true: 로그인됨, false: 로그아웃됨)
  final Rx<bool?> isAuthenticated = Rx<bool?>(null);

  // 2. Rx User: 현재 로그인된 사용자 정보 모델
  final Rx<UserModel?> currentUser = Rx<UserModel?>(null);

  // 현재 사용자 UID를 쉽게 접근하기 위한 Getter
  String? get currentUserId => _auth.currentUser?.uid;

  // Canvas 환경에서 제공되는 전역 변수
  // ignore: prefer_typing_uninitialized_variables
  var __initial_auth_token;

  @override
  void onInit() {
    super.onInit();
    
    // 2. 인증 상태 변화 리스너 설정
    _auth.authStateChanges().listen((User? user) async {
      if (user == null) {
        // 로그아웃 상태
        isAuthenticated.value = false;
        currentUser.value = null;
        print("👤 AuthController: 로그아웃 상태. isAuthenticated = false");
      } else {
        // 로그인 상태: Firestore에서 추가 사용자 정보를 로드합니다.
        final userModel = await _firestoreService.getUser(user.uid);
        if (userModel != null) {
          currentUser.value = userModel;
          isAuthenticated.value = true;
          print("👤 AuthController: 로그인 성공. 사용자 UID: ${user.uid}");
        } else {
          // Firebase Auth에는 로그인되었으나, Firestore에 정보가 없는 경우 (최초 로그인/회원가입 직후)
          // 여기서는 간소화를 위해 새로운 UserModel을 생성하여 Firestore에 저장합니다.
          final newUser = UserModel(
            uid: user.uid,
            nickname: '익명${user.uid.substring(0, 4)}',
            town: '당근동',
            temperature: 36.5,
            profileImageUrl: 'https://placehold.co/150x150/ffa500/ffffff?text=U', // 기본 이미지
          );
          await _firestoreService.addUser(newUser);
          currentUser.value = newUser;
          isAuthenticated.value = true;
          print("👤 AuthController: Firestore에 사용자 정보 저장 및 로그인 완료");
        }
      }
    });

    // 1. 앱 시작 시 Canvas 초기 인증 토큰 처리
    _handleInitialAuth();
  }
  
  // Canvas 환경에서 제공하는 초기 인증 토큰으로 로그인 시도
  Future<void> _handleInitialAuth() async {
    try {
      if (typeof __initial_auth_token != 'undefined' && __initial_auth_token != null) {
        await _auth.signInWithCustomToken(__initial_auth_token);
        print("🔑 AuthController: 초기 커스텀 토큰으로 로그인 시도");
      } else {
        // 토큰이 없으면 익명 로그인 시도 (모든 앱에 필요)
        await _auth.signInAnonymously();
        print("🔑 AuthController: 초기 익명 로그인 시도");
      }
    } catch (e) {
      print("❌ AuthController: 초기 인증 실패: $e");
      isAuthenticated.value = false;
    }
  }

  // 로그아웃 함수
  Future<void> signOut() async {
    try {
      await _auth.signOut();
      print("🚪 AuthController: 로그아웃 성공");
    } catch (e) {
      Get.snackbar('오류', '로그아웃 중 오류가 발생했습니다: $e', snackPosition: SnackPosition.BOTTOM);
      print("❌ AuthController: 로그아웃 오류: $e");
    }
  }

  // 이메일/비밀번호 로그인 (예시)
  // Future<void> signInWithEmail(String email, String password) async { ... }
}