// 이 파일은 FlutterFire CLI를 통해 생성되어야 합니다.
// 실제 앱에서는 YOUR_API_KEY와 YOUR_APP_ID를 실제 값으로 대체해야 합니다.

import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;

/// 플랫폼별 Firebase 설정을 포함하는 클래스 (플레이스홀더)
class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      return web;
    }
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return ios;
      case TargetPlatform.macOS:
      case TargetPlatform.windows:
      case TargetPlatform.linux:
        throw UnsupportedError(
          'Platform $defaultTargetPlatform is not yet supported by this package.',
        );
      default:
        throw UnsupportedError(
          'DefaultFirebaseOptions are not supported for this platform.',
        );
    }
  }

  static const FirebaseOptions web = FirebaseOptions(
    apiKey: 'YOUR_WEB_API_KEY', // 실제 웹 API 키로 대체해야 함
    appId: '1:1234567890:web:abcdef0123456789',
    messagingSenderId: '1234567890',
    projectId: 'karrot-clone-project',
    authDomain: 'karrot-clone-project.firebaseapp.com',
    storageBucket: 'karrot-clone-project.appspot.com',
  );

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'YOUR_ANDROID_API_KEY', // 실제 안드로이드 API 키로 대체해야 함
    appId: '1:1234567890:android:abcdef0123456789',
    messagingSenderId: '1234567890',
    projectId: 'karrot-clone-project',
    storageBucket: 'karrot-clone-project.appspot.com',
  );

  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: 'YOUR_IOS_API_KEY', // 실제 iOS API 키로 대체해야 함
    appId: '1:1234567890:ios:abcdef0123456789',
    messagingSenderId: '1234567890',
    projectId: 'karrot-clone-project',
    storageBucket: 'karrot-clone-project.appspot.com',
    iosClientId: 'YOUR_IOS_CLIENT_ID',
    iosBundleId: 'com.example.karrotCloneProject',
  );
}
