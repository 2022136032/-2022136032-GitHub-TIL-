import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:karrot_app_clone/app_theme.dart';
import 'package:karrot_app_clone/widgets/app_font.dart';
import 'package:karrot_app_clone/widgets/circle_image.dart';

// 메인 화면의 '채팅' 탭
class ChatPage extends StatelessWidget {
  const ChatPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const AppFontDark(
          '채팅',
          fontSize: 22,
          fontWeight: FontWeight.bold,
        ),
      ),
      body: ListView.separated(
        itemCount: 15, // 더미 채팅 목록
        separatorBuilder: (context, index) =>
            Divider(color: Colors.grey.shade800, height: 1, thickness: 1),
        itemBuilder: (context, index) {
          // 더미 데이터 생성
          final name = '사용자 ${index + 1}';
          final lastMessage = index % 3 == 0 ? '네고 가능할까요?' : '안녕하세요.';
          final unreadCount = index % 5;
          final time = '3시간 전';

          return ListTile(
            onTap: () {
              // 채팅방 상세 페이지로 이동
              Get.toNamed('/chat/room/$index');
            },
            // 왼쪽 프로필 이미지
            leading: CircleImage(
              imageUrl:
                  'https://placehold.co/100x100/333/FFF?text=U${index + 1}',
              size: 55,
            ),

            // 중앙 제목 및 메시지
            title: AppFontDark(name, fontWeight: FontWeight.bold),
            subtitle: AppFontDark(
              lastMessage,
              color: Colors.grey,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),

            // 오른쪽 시간 및 읽지 않은 메시지 수
            trailing: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                AppFontDark(time, fontSize: 12, color: Colors.grey),
                const SizedBox(height: 4),
                if (unreadCount > 0)
                  Container(
                    padding: const EdgeInsets.all(4),
                    decoration: const BoxDecoration(
                      color: AppTheme.primaryKarrotColor,
                      shape: BoxShape.circle,
                    ),
                    child: AppFontDark(
                      unreadCount.toString(),
                      fontSize: 12,
                      color: Colors.white,
                    ),
                  )
                else
                  const SizedBox(height: 16), // 높이 맞추기
              ],
            ),
          );
        },
      ),
    );
  }
}
