import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:karrot_app_clone/common/controller/auth_controller.dart';
import 'package:karrot_app_clone/widgets/app_font.dart';
import 'package:karrot_app_clone/widgets/btn.dart';

// 임시 데이터 모델
class Item {
  final String title;
  final String location;
  final int price;
  final int chatCount;
  final int likeCount;

  Item({
    required this.title,
    required this.location,
    required this.price,
    required this.chatCount,
    required this.likeCount,
  });
}

// 홈 탭 화면
class HomePage extends StatelessWidget {
  const HomePage({super.key});

  // 임시 판매 목록 데이터
  final List<Item> items = const [
    // 5개의 임시 아이템
    Item(
      title: '사용감 거의 없는 에어프라이어',
      location: '역삼동',
      price: 50000,
      chatCount: 2,
      likeCount: 5,
    ),
    Item(
      title: '가죽 소파 (1인용)',
      location: '선릉역 근처',
      price: 150000,
      chatCount: 1,
      likeCount: 8,
    ),
    Item(
      title: '아이맥 2020년형 (급처)',
      location: '서초동',
      price: 900000,
      chatCount: 4,
      likeCount: 12,
    ),
    Item(
      title: '캠핑용 테이블',
      location: '잠실',
      price: 30000,
      chatCount: 0,
      likeCount: 3,
    ),
    Item(
      title: '새것같은 인형',
      location: '강남역',
      price: 5000,
      chatCount: 7,
      likeCount: 20,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    // Scaffold: 상단 앱바와 목록을 표시
    return Scaffold(
      // AppBar: 동네 이름, 검색, 알림 아이콘
      appBar: AppBar(
        title: const Row(
          children: [
            AppFontDark('역삼동', fontWeight: FontWeight.bold, fontSize: 18),
            Icon(Icons.keyboard_arrow_down, color: Colors.white, size: 24),
          ],
        ),
        actions: const [
          Icon(Icons.search, color: Colors.white, size: 28),
          SizedBox(width: 15),
          Icon(Icons.notifications_none, color: Colors.white, size: 28),
          SizedBox(width: 15),
        ],
      ),

      // ListView.builder: 아이템 목록을 생성
      body: ListView.builder(
        itemCount: items.length,
        itemBuilder: (context, index) {
          final item = items[index];
          return _buildItemCard(item, context); // 아이템 카드 위젯 호출
        },
      ),

      // FloatingActionButton: 글쓰기 버튼
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          // 글쓰기 페이지로 이동 로직 (임시)
          Get.snackbar('알림', '글쓰기 버튼 클릭됨');
        },
        backgroundColor: const Color(0xFFFF7E36),
        foregroundColor: Colors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(30.0),
        ),
        child: const Icon(Icons.add),
      ),
    );
  }

  // 개별 아이템 카드 위젯
  Widget _buildItemCard(Item item, BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 15.0, vertical: 10.0),
      child: Column(
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // 이미지 Placeholder
              Container(
                width: 100,
                height: 100,
                decoration: BoxDecoration(
                  color: Colors.white10,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Icon(Icons.image, color: Colors.white54, size: 50),
              ),
              const SizedBox(width: 15),

              // 상품 정보
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    AppFontDark(
                      item.title,
                      fontWeight: FontWeight.w500,
                      fontSize: 16,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 5),
                    AppFontDark(
                      item.location,
                      color: Colors.grey,
                      fontSize: 13,
                    ),
                    const SizedBox(height: 5),
                    AppFontDark(
                      '${item.price.toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (Match m) => '${m[1]},')}원',
                      fontWeight: FontWeight.bold,
                      fontSize: 15,
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          // 아이템 하단 정보 (채팅/관심)
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              if (item.chatCount > 0) ...[
                const Icon(
                  Icons.chat_bubble_outline,
                  color: Colors.grey,
                  size: 18,
                ),
                const SizedBox(width: 5),
                AppFontDark(
                  item.chatCount.toString(),
                  color: Colors.grey,
                  fontSize: 13,
                ),
                const SizedBox(width: 10),
              ],
              if (item.likeCount > 0) ...[
                const Icon(Icons.favorite_border, color: Colors.grey, size: 18),
                const SizedBox(width: 5),
                AppFontDark(
                  item.likeCount.toString(),
                  color: Colors.grey,
                  fontSize: 13,
                ),
              ],
            ],
          ),
          const Divider(color: Colors.white10, height: 20, thickness: 1), // 구분선
        ],
      ),
    );
  }
}
import 'package:flutter/material.dart';
import 'package:karrot_app_clone/widgets/app_font.dart';

// 중고거래 홈 페이지
class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // AppBar: 지역 설정 및 아이콘
      appBar: AppBar(
        // 지역 이름
        title: const Row(
          children: [
            AppFontDark('역삼동', fontWeight: FontWeight.bold, fontSize: 18),
            Icon(Icons.keyboard_arrow_down, color: Colors.white, size: 24),
          ],
        ),
        actions: const [
          // 검색
          IconButton(
            icon: Icon(Icons.search, color: Colors.white),
            onPressed: null,
          ),
          // 카테고리
          IconButton(
            icon: Icon(Icons.list, color: Colors.white),
            onPressed: null,
          ),
          // 알림
          IconButton(
            icon: Icon(Icons.notifications_none, color: Colors.white),
            onPressed: null,
          ),
        ],
      ),
      
      // 임시 콘텐츠
      body: Center(
        child: AppFontDark('중고거래 글 목록이 표시될 공간입니다.', color: Colors.grey),
      ),
    );
  }
}
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:karrot_app_clone/app_theme.dart';
import 'package:karrot_app_clone/common/controller/auth_controller.dart';
import 'package:karrot_app_clone/pages/home/widgets/product_list_item.dart';
import 'package:karrot_app_clone/services/firestore_service.dart';
import 'package:karrot_app_clone/widgets/app_font.dart';
import 'package:karrot_app_clone/models/product_model.dart';

// 메인 화면의 '홈' 탭 (중고거래 목록)
class HomePage extends GetView<AuthController> {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    // AuthController에서 현재 사용자 정보를 가져와 현재 지역을 결정합니다.
    final currentRegion = controller.user.value?.currentRegion ?? '동네 설정 필요';
    final firestoreService = Get.find<FirestoreService>();

    return Scaffold(
      appBar: AppBar(
        // 현재 지역 이름을 드롭다운 형태로 표시
        title: GestureDetector(
          onTap: () {
            // 지역 설정 변경 다이얼로그 띄우기 등의 로직
            Get.snackbar('지역 설정', '지역 설정 변경 페이지로 이동합니다.');
          },
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              AppFontDark(
                currentRegion, 
                fontSize: 20, 
                fontWeight: FontWeight.bold,
              ),
              const Icon(Icons.keyboard_arrow_down, size: 24, color: AppTheme.darkForegroundColor),
            ],
          ),
        ),
        // 우측 상단 아이콘들
        actions: [
          IconButton(
            icon: const Icon(Icons.search, color: AppTheme.darkForegroundColor),
            onPressed: () => Get.snackbar('검색', '검색 페이지로 이동합니다.'),
          ),
          IconButton(
            icon: const Icon(Icons.menu, color: AppTheme.darkForegroundColor),
            onPressed: () => Get.snackbar('카테고리', '카테고리 선택 페이지로 이동합니다.'),
          ),
          IconButton(
            icon: const Icon(Icons.notifications_none, color: AppTheme.darkForegroundColor),
            onPressed: () => Get.snackbar('알림', '알림 페이지로 이동합니다.'),
          ),
        ],
      ),
      
      body: StreamBuilder<List<ProductModel>>(
        // Firestore Service를 통해 상품 목록 스트림을 가져옵니다.
        stream: firestoreService.getProductsStream(currentRegion),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator(color: AppTheme.primaryKarrotColor));
          }
          
          if (snapshot.hasError) {
            print("❌ 상품 목록 로딩 오류: ${snapshot.error}");
            return Center(child: AppFontDark('데이터 로딩 오류: ${snapshot.error}', color: Colors.red));
          }

          final products = snapshot.data ?? [];
          
          if (products.isEmpty) {
            return Center(child: AppFontDark('$currentRegion에 등록된 상품이 없습니다.', color: Colors.grey));
          }

          // 상품 목록 표시
          return ListView.separated(
            itemCount: products.length,
            separatorBuilder: (context, index) => Divider(
              color: Colors.grey.shade800, 
              height: 1, 
              thickness: 1
            ),
            itemBuilder: (context, index) {
              final product = products[index];
              return ProductListItem(product: product);
            },
          );
        },
      ),
      
      // 상품 등록 Floating Action Button
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          // 상품 등록 페이지로 이동
          Get.toNamed('/write'); // AppRoutes.WRITE_POST
        },
        backgroundColor: AppTheme.primaryKarrotColor,
        child: const Icon(Icons.add, color: Colors.white, size: 30),
      ),
    );
  }
}
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:karrot_app_clone/app_theme.dart';
import 'package:karrot_app_clone/common/controller/auth_controller.dart';
import 'package:karrot_app_clone/pages/home/widgets/product_list_item.dart';
import 'package:karrot_app_clone/services/firestore_service.dart';
import 'package:karrot_app_clone/widgets/app_font.dart';
import 'package:karrot_app_clone/models/product_model.dart';

// 메인 화면의 '홈' 탭 (중고거래 목록)
class HomePage extends GetView<AuthController> {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    // AuthController에서 현재 사용자 정보를 가져와 현재 지역을 결정합니다.
    final currentRegion = controller.user.value?.currentRegion ?? '동네 설정 필요';
    final firestoreService = Get.find<FirestoreService>();

    return Scaffold(
      appBar: AppBar(
        // 현재 지역 이름을 드롭다운 형태로 표시
        title: GestureDetector(
          onTap: () {
            // 지역 설정 변경 다이얼로그 띄우기 등의 로직
            Get.snackbar('지역 설정', '지역 설정 변경 페이지로 이동합니다.');
          },
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              AppFontDark(
                currentRegion, 
                fontSize: 20, 
                fontWeight: FontWeight.bold,
              ),
              const Icon(Icons.keyboard_arrow_down, size: 24, color: AppTheme.darkForegroundColor),
            ],
          ),
        ),
        // 우측 상단 아이콘들
        actions: [
          IconButton(
            icon: const Icon(Icons.search, color: AppTheme.darkForegroundColor),
            onPressed: () => Get.snackbar('검색', '검색 페이지로 이동합니다.'),
          ),
          IconButton(
            icon: const Icon(Icons.menu, color: AppTheme.darkForegroundColor),
            onPressed: () => Get.snackbar('카테고리', '카테고리 선택 페이지로 이동합니다.'),
          ),
          IconButton(
            icon: const Icon(Icons.notifications_none, color: AppTheme.darkForegroundColor),
            onPressed: () => Get.snackbar('알림', '알림 페이지로 이동합니다.'),
          ),
        ],
      ),
      
      body: StreamBuilder<List<ProductModel>>(
        // Firestore Service를 통해 상품 목록 스트림을 가져옵니다.
        stream: firestoreService.getProductsStream(currentRegion),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator(color: AppTheme.primaryKarrotColor));
          }
          
          if (snapshot.hasError) {
            print("❌ 상품 목록 로딩 오류: ${snapshot.error}");
            return Center(child: AppFontDark('데이터 로딩 오류: ${snapshot.error}', color: Colors.red));
          }

          final products = snapshot.data ?? [];
          
          if (products.isEmpty) {
            return Center(child: AppFontDark('$currentRegion에 등록된 상품이 없습니다.', color: Colors.grey));
          }

          // 상품 목록 표시
          return ListView.separated(
            itemCount: products.length,
            separatorBuilder: (context, index) => Divider(
              color: Colors.grey.shade800, 
              height: 1, 
              thickness: 1
            ),
            itemBuilder: (context, index) {
              final product = products[index];
              return ProductListItem(product: product);
            },
          );
        },
      ),
      
      // 상품 등록 Floating Action Button
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          // 상품 등록 페이지로 이동
          Get.toNamed('/write'); // AppRoutes.WRITE_POST
        },
        backgroundColor: AppTheme.primaryKarrotColor,
        child: const Icon(Icons.add, color: Colors.white, size: 30),
      ),
    );
  }
}