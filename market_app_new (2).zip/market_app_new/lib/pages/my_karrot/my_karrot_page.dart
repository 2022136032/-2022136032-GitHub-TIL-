import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:karrot_app_clone/common/controller/auth_controller.dart';
import 'package:karrot_app_clone/widgets/app_font.dart';

// 나의 당근 페이지
class MyKarrotPage extends GetView<AuthController> {
  const MyKarrotPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const AppFontDark('나의 당근', fontWeight: FontWeight.bold),
        actions: const [
          IconButton(
            icon: Icon(Icons.settings_outlined, color: Colors.white),
            onPressed: null,
          ),
        ],
      ),
      
      // 임시 콘텐츠 및 로그아웃 버튼
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Obx(() => AppFontDark('사용자 ID: ${controller.user.value?.uid ?? '로그인 필요'}', color: Colors.grey)),
            const SizedBox(height: 20),
            TextButton(
              onPressed: () {
                // Firebase 로그아웃 처리
                Get.find<AuthController>().user.value = null; // 임시 로그아웃 처리
                // 실제로는 FirebaseAuth.instance.signOut()을 호출해야 합니다.
                Get.offAllNamed('/'); // 스플래시로 돌아가 인증 상태 재확인
                Get.snackbar('알림', '로그아웃 되었습니다.', backgroundColor: const Color(0xFFFF7E36), colorText: Colors.white);
              },
              child: const AppFontDark('로그아웃 (임시)', color: Colors.redAccent),
            ),
          ],
        ),
      ),
    );
  }
}import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:karrot_app_clone/common/controller/auth_controller.dart';
import 'package:karrot_app_clone/widgets/app_font.dart';

// 나의 당근 페이지
class MyKarrotPage extends GetView<AuthController> {
  const MyKarrotPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const AppFontDark('나의 당근', fontWeight: FontWeight.bold),
        actions: const [
          IconButton(
            icon: Icon(Icons.settings_outlined, color: Colors.white),
            onPressed: null,
          ),
        ],
      ),
      
      // 임시 콘텐츠 및 로그아웃 버튼
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Obx(() => AppFontDark('사용자 ID: ${controller.user.value?.uid ?? '로그인 필요'}', color: Colors.grey)),
            const SizedBox(height: 20),
            TextButton(
              onPressed: () {
                // Firebase 로그아웃 처리
                Get.find<AuthController>().user.value = null; // 임시 로그아웃 처리
                // 실제로는 FirebaseAuth.instance.signOut()을 호출해야 합니다.
                Get.offAllNamed('/'); // 스플래시로 돌아가 인증 상태 재확인
                Get.snackbar('알림', '로그아웃 되었습니다.', backgroundColor: const Color(0xFFFF7E36), colorText: Colors.white);
              },
              child: const AppFontDark('로그아웃 (임시)', color: Colors.redAccent),
            ),
          ],
        ),
      ),
    );
  }
}import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:karrot_app_clone/common/controller/auth_controller.dart';
import 'package:karrot_app_clone/widgets/app_font.dart';

// 나의 당근 페이지
class MyKarrotPage extends GetView<AuthController> {
  const MyKarrotPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const AppFontDark('나의 당근', fontWeight: FontWeight.bold),
        actions: const [
          IconButton(
            icon: Icon(Icons.settings_outlined, color: Colors.white),
            onPressed: null,
          ),
        ],
      ),
      
      // 임시 콘텐츠 및 로그아웃 버튼
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Obx(() => AppFontDark('사용자 ID: ${controller.user.value?.uid ?? '로그인 필요'}', color: Colors.grey)),
            const SizedBox(height: 20),
            TextButton(
              onPressed: () {
                // Firebase 로그아웃 처리
                Get.find<AuthController>().user.value = null; // 임시 로그아웃 처리
                // 실제로는 FirebaseAuth.instance.signOut()을 호출해야 합니다.
                Get.offAllNamed('/'); // 스플래시로 돌아가 인증 상태 재확인
                Get.snackbar('알림', '로그아웃 되었습니다.', backgroundColor: const Color(0xFFFF7E36), colorText: Colors.white);
              },
              child: const AppFontDark('로그아웃 (임시)', color: Colors.redAccent),
            ),
          ],
        ),
      ),
    );
  }
}