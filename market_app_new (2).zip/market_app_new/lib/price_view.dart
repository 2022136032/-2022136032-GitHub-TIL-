// lib/price_view.dart
import 'package:flutter/material.dart';
import 'home_controll.dart';
import 'models.dart';

// 가격 정보를 보여주는 화면 (View)입니다.
class PriceView extends StatefulWidget {
  const PriceView({super.key});

  @override
  State<PriceView> createState() => _PriceViewState();
}

class _PriceViewState extends State<PriceView> {
  // 컨트롤러 인스턴스 생성
  final HomeController controller = HomeController();

  // 재고 변경 후 화면을 갱신하는 함수
  void _decreaseStock(Product product) {
    setState(() {
      if (product.stockQuantity > 0) {
        // 컨트롤러의 로직을 호출하여 데이터 변경
        controller.updateStock(product.id, -1);
      } else {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('${product.name}의 재고가 부족합니다.')));
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          '상품 목록 및 재고 관리',
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: Colors.teal,
        centerTitle: true,
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Text(
              '총 상품 수: ${controller.totalProductCount}개 (상품을 탭하면 재고가 1 감소합니다)',
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
          ),
          Expanded(
            // 컨트롤러에서 상품 목록 데이터를 가져와 표시
            child: ListView.builder(
              itemCount: controller.products.length,
              itemBuilder: (context, index) {
                final Product product = controller.products[index];
                return Card(
                  elevation: 4,
                  margin: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 6,
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: ListTile(
                    leading: CircleAvatar(
                      backgroundColor: Colors.teal.shade400,
                      child: Text(
                        '${product.id}',
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    title: Text(
                      product.name,
                      style: const TextStyle(
                        fontWeight: FontWeight.w600,
                        fontSize: 16,
                      ),
                    ),
                    subtitle: Text(
                      '가격: ${product.price.toStringAsFixed(0)}원',
                      style: TextStyle(color: Colors.grey[600]),
                    ),
                    trailing: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        const Text(
                          '재고',
                          style: TextStyle(fontSize: 12, color: Colors.black54),
                        ),
                        Text(
                          '${product.stockQuantity}개',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 18,
                            color: product.stockQuantity > 20
                                ? Colors.green
                                : Colors.red,
                          ),
                        ),
                      ],
                    ),
                    onTap: () => _decreaseStock(product), // 탭 시 재고 감소 함수 호출
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
