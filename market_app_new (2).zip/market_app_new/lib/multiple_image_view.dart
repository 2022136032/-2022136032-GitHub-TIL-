// multiple_image_view.dart

import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';

// -----------------------------------------------------------------------------
// [1] 데이터 모델 및 서비스 (heic_converter.dart에서 통합)
// -----------------------------------------------------------------------------

/// 간단한 UUID 생성을 위한 Random 인스턴스입니다.
final Random _random = Random();

/// HEIC 파일을 나타내는 데이터 모델 클래스입니다.
class HeicFile {
  final String id;
  final String fileName;
  final String originalMimeType;
  // UI 상태 관리를 위해 추가된 필드
  ConversionResult? conversionResult;

  HeicFile({
    required this.id,
    required this.fileName,
    this.originalMimeType = 'image/heic',
    this.conversionResult,
  });

  // 파일 이름을 기반으로 초기화하는 팩토리 생성자
  factory HeicFile.fromFileName(String fileName) {
    return HeicFile(
      id: HeicConversionService.generateUuid(),
      fileName: fileName,
    );
  }

  // 상태 업데이트를 위한 복사 메소드
  HeicFile copyWith({ConversionResult? conversionResult}) {
    return HeicFile(
      id: id,
      fileName: fileName,
      originalMimeType: originalMimeType,
      conversionResult: conversionResult ?? this.conversionResult,
    );
  }
}

/// 파일 변환 작업의 결과를 담는 클래스입니다.
class ConversionResult {
  final String status; // 'Pending', 'Converting', 'Converted', 'Failed'
  final String? newFileName;
  final String? error;

  ConversionResult({required this.status, this.newFileName, this.error});

  ConversionResult.pending()
    : status = 'Pending',
      newFileName = null,
      error = null;

  ConversionResult.converting()
    : status = 'Converting',
      newFileName = null,
      error = null;

  ConversionResult.success(this.newFileName)
    : status = 'Converted',
      error = null;

  ConversionResult.failure(this.error) : status = 'Failed', newFileName = null;
}

/// 파일 목록을 관리하고 HEIC 변환을 시뮬레이션하는 서비스 클래스입니다.
class HeicConversionService {
  /// 특정 HEIC 파일에 대한 변환 과정을 시뮬레이션합니다.
  Future<ConversionResult> simulateConversion(HeicFile file) async {
    // 1초 ~ 3초 사이의 지연 시간 시뮬레이션
    final delay = Duration(milliseconds: 1000 + _random.nextInt(2000));
    await Future.delayed(delay);

    // 90%의 성공률 시뮬레이션
    if (_random.nextDouble() > 0.1) {
      // 파일 확장자를 .jpg로 변경합니다.
      final newFileName = file.fileName.replaceAll(
        RegExp(r'\.heic$', caseSensitive: false),
        '.jpg',
      );
      return ConversionResult.success(newFileName);
    } else {
      const error = '파일 헤더 손상으로 변환에 실패했습니다.';
      return ConversionResult.failure(error);
    }
  }

  /// 간단한 6자리 UUID를 생성합니다.
  static String generateUuid() {
    return _random.nextInt(999999).toString().padLeft(6, '0');
  }
}

// -----------------------------------------------------------------------------
// [2] Flutter UI 컴포넌트
// -----------------------------------------------------------------------------

/// 파일 목록을 표시하고 변환을 제어하는 메인 위젯
class ImageListView extends StatefulWidget {
  const ImageListView({super.key});

  @override
  State<ImageListView> createState() => _ImageListViewState();
}

class _ImageListViewState extends State<ImageListView> {
  final HeicConversionService _service = HeicConversionService();
  List<HeicFile> _files = [];
  bool _isConverting = false;

  @override
  void initState() {
    super.initState();
    // 사용자로부터 업로드된 파일 목록 시뮬레이션
    _initializeFiles([
      'photo_01.heic',
      'vacation_02.heic',
      'portrait_03.heic',
      'backup_04.heic',
      'test_05.heic',
      'raw_06.heic',
      'archive_07.heic',
      'temp_08.heic',
    ]);
  }

  /// 초기 파일 목록 설정
  void _initializeFiles(List<String> fileNames) {
    setState(() {
      _files = fileNames
          .map((name) => HeicFile.fromFileName(name))
          .map(
            (file) =>
                file.copyWith(conversionResult: ConversionResult.pending()),
          )
          .toList();
    });
  }

  /// 개별 파일 변환 시작 및 상태 업데이트
  Future<void> _startConversion(String fileId) async {
    final fileIndex = _files.indexWhere((f) => f.id == fileId);
    if (fileIndex == -1 ||
        _files[fileIndex].conversionResult?.status == 'Converting')
      return;

    // 1. 상태를 'Converting'으로 변경
    setState(() {
      _files[fileIndex] = _files[fileIndex].copyWith(
        conversionResult: ConversionResult.converting(),
      );
    });

    try {
      // 2. 변환 시뮬레이션 실행
      final result = await _service.simulateConversion(_files[fileIndex]);

      // 3. 최종 결과로 상태 업데이트
      setState(() {
        _files[fileIndex] = _files[fileIndex].copyWith(
          conversionResult: result,
        );
      });
    } catch (e) {
      // 4. 오류 발생 시 상태 업데이트
      setState(() {
        _files[fileIndex] = _files[fileIndex].copyWith(
          conversionResult: ConversionResult.failure('예상치 못한 오류 발생'),
        );
      });
    }
  }

  /// 모든 변환 작업을 일괄 시작
  Future<void> _startAllConversions() async {
    setState(() {
      _isConverting = true;
    });

    final pendingFiles = _files
        .where(
          (f) =>
              f.conversionResult?.status == 'Pending' ||
              f.conversionResult?.status == 'Failed',
        )
        .toList();

    // 변환 작업을 병렬로 실행
    await Future.wait(pendingFiles.map((file) => _startConversion(file.id)));

    setState(() {
      _isConverting = false;
    });
  }

  /// 파일 제거
  void _removeFile(String fileId) {
    setState(() {
      _files.removeWhere((file) => file.id == fileId);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'HEIC 파일 일괄 변환 (시뮬레이션)',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.indigo,
        foregroundColor: Colors.white,
      ),
      body: Column(
        children: [
          _buildSummaryCard(),
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(16.0),
              itemCount: _files.length,
              itemBuilder: (context, index) {
                final file = _files[index];
                return _FileListItem(
                  file: file,
                  onConvert: _startConversion,
                  onRemove: _removeFile,
                );
              },
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _isConverting ? null : _startAllConversions,
        label: Text(
          _isConverting
              ? '변환 진행 중...'
              : '모두 변환 시작 (${_files.where((f) => f.conversionResult?.status == 'Pending' || f.conversionResult?.status == 'Failed').length})',
        ),
        icon: _isConverting
            ? const CircularProgressIndicator(color: Colors.white)
            : const Icon(Icons.flash_on),
        backgroundColor: _isConverting ? Colors.indigo.shade300 : Colors.indigo,
        foregroundColor: Colors.white,
      ),
    );
  }

  Widget _buildSummaryCard() {
    final convertedCount = _files
        .where((f) => f.conversionResult?.status == 'Converted')
        .length;
    final failedCount = _files
        .where((f) => f.conversionResult?.status == 'Failed')
        .length;
    final pendingCount = _files.length - convertedCount - failedCount;

    return Container(
      padding: const EdgeInsets.all(16),
      margin: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.indigo.shade50,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.indigo.shade200),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _buildStatusChip(convertedCount, '완료', Colors.green),
          _buildStatusChip(pendingCount, '대기', Colors.orange),
          _buildStatusChip(failedCount, '실패', Colors.red),
        ],
      ),
    );
  }

  Widget _buildStatusChip(int count, String label, Color color) {
    return Column(
      children: [
        Text(
          '$count',
          style: TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.bold,
            color: color.shade800,
          ),
        ),
        const SizedBox(height: 4),
        Text(label, style: TextStyle(fontSize: 14, color: color.shade600)),
      ],
    );
  }
}

/// 개별 파일 항목을 위한 위젯
class _FileListItem extends StatelessWidget {
  final HeicFile file;
  final Function(String) onConvert;
  final Function(String) onRemove;

  const _FileListItem({
    required this.file,
    required this.onConvert,
    required this.onRemove,
  });

  @override
  Widget build(BuildContext context) {
    final status = file.conversionResult?.status ?? 'Pending';
    final result = file.conversionResult;

    Color statusColor;
    IconData statusIcon;
    String statusText;
    bool isConverting = false;

    switch (status) {
      case 'Converted':
        statusColor = Colors.green;
        statusIcon = Icons.check_circle;
        statusText = '변환 완료: ${result!.newFileName!}';
        break;
      case 'Failed':
        statusColor = Colors.red;
        statusIcon = Icons.error;
        statusText = '변환 실패: ${result!.error!}';
        break;
      case 'Converting':
        statusColor = Colors.indigo;
        statusIcon = Icons.autorenew;
        statusText = '변환 중...';
        isConverting = true;
        break;
      case 'Pending':
      default:
        statusColor = Colors.grey;
        statusIcon = Icons.file_present;
        statusText = '변환 대기 중';
    }

    return Card(
      margin: const EdgeInsets.only(bottom: 8.0),
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: ListTile(
        leading: Icon(statusIcon, color: statusColor, size: 30),
        title: Text(
          file.fileName,
          style: const TextStyle(fontWeight: FontWeight.w600),
          overflow: TextOverflow.ellipsis,
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'ID: ${file.id} | 유형: ${file.originalMimeType.toUpperCase()}',
              style: const TextStyle(fontSize: 12),
            ),
            const SizedBox(height: 4),
            Text(
              statusText,
              style: TextStyle(fontSize: 13, color: statusColor.shade700),
            ),
          ],
        ),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (!isConverting && status != 'Converted')
              ElevatedButton(
                onPressed: () => onConvert(file.id),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.indigo,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 8,
                  ),
                ),
                child: const Text('변환', style: TextStyle(fontSize: 14)),
              ),
            const SizedBox(width: 8),
            IconButton(
              icon: const Icon(Icons.delete, color: Colors.grey),
              onPressed: () => onRemove(file.id),
              tooltip: '제거',
            ),
          ],
        ),
      ),
    );
  }
}

// -----------------------------------------------------------------------------
// [3] Flutter 애플리케이션 진입점
// -----------------------------------------------------------------------------

void main() {
  runApp(const HeicConverterApp());
}

class HeicConverterApp extends StatelessWidget {
  const HeicConverterApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'HEIC Converter Demo',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.indigo,
        visualDensity: VisualDensity.adaptivePlatformDensity,
        fontFamily: 'Roboto',
      ),
      home: const ImageListView(), // 요청하신 UI 위젯
    );
  }
}
