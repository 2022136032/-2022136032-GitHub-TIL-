package com.example.market_app_new

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
