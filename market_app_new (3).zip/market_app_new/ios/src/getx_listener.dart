import 'package:flutter/material.dart';
import 'package:get/get.dart';

// GetX의 Rx 스트림을 수신하고, 초기화 호출을 처리하는 커스텀 위젯
// <T>는 Rx 타입의 제네릭 타입을 나타냅니다.
class GetxListener<T> extends StatefulWidget {
  // 관찰할 Rx 타입 스트림
  final Rx<T> stream;
  // 스트림 값 변경 시 호출할 콜백 함수
  final Function(T value) listen;
  // 위젯 내부에 표시될 자식 위젯
  final Widget child;
  // 위젯이 처음 생성될 때 한 번 호출될 초기화 함수
  final VoidCallback? initCall;

  const GetxListener({
    super.key,
    this.initCall,
    required this.stream,
    required this.listen,
    required this.child,
  });

  @override
  State<GetxListener<T>> createState() => _GetxListenerState<T>();
}

class _GetxListenerState<T> extends State<GetxListener<T>> {
  late final Disposable _disposable;

  @override
  void initState() {
    super.initState();

    // 1. initCall이 있다면 한 번 호출
    if (widget.initCall != null) {
      widget.initCall!();
    }

    // 2. stream을 구독하고, 값이 변경될 때마다 listen 콜백 함수 호출
    _disposable = widget.stream.listen((value) {
      // 위젯이 mounted 된 상태에서만 listen 함수 호출
      if (mounted) {
        widget.listen(value);
      }
    });
  }

  @override
  void dispose() {
    // 3. 위젯이 제거될 때 스트림 구독을 해제
    _disposable.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return widget.child;
  }
}
