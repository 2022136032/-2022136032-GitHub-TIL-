import 'package:flutter/material.dart';
import 'package:get/get.dart';

// 임포트 경로 확인
import 'common/components/getx_listener.dart';
import 'common/controller/data_load_controller.dart';
import 'common/controller/splash_controller.dart';
import 'common/controller/step_type.dart';
import 'common/controller/auth_controller.dart'; // AuthController 추가

// 스플래시 페이지
class SplashPage extends GetView<SplashController> {
  const SplashPage({super.key});

  // SplashController의 loadStep 상태가 변경될 때 호출되는 로직
  void _listenStepTypeChange(StepType value) {
    if (value == StepType.dataload) {
      // 데이터 로드 단계: DataLoadController의 loadData 호출
      Get.find<DataLoadController>().loadData();
    } else if (value == StepType.authCheck) {
      // 인증 체크 단계: 익명 로그인 시도
      Get.find<AuthController>().signInAnonymously();
    } else if (value == StepType.startApp) {
      // 앱 시작 단계: MainScreen으로 이동
      Get.offNamed('/main');
    }
  }

  // DataLoadController의 isDataLoad 상태가 변경될 때 호출되는 로직
  void _listenDataLoadComplete(bool isLoaded) {
    if (isLoaded) {
      // 데이터 로드가 완료되면 다음 단계인 authCheck로 전환
      Get.find<SplashController>().changeStep(StepType.authCheck);
    }
  }

  // AuthController의 isAuthLoading 상태가 변경될 때 호출되는 로직
  void _listenAuthLoading(bool isLoading) {
    // 인증 로딩이 완료(false)되면 (사용자 상태가 확인되면)
    if (!isLoading) {
      // 앱 시작 단계로 전환
      Get.find<SplashController>().changeStep(StepType.startApp);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF212123),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // 1. SplashController의 loadStep을 수신하는 GetxListener
            GetxListener<StepType>(
              stream: controller.loadStep,
              initCall: () {
                // 위젯 생성 후 초기 단계인 dataload를 실행
                _listenStepTypeChange(controller.loadStep.value);
              },
              listen: _listenStepTypeChange,
              child: Obx(
                () => Text(
                  '${controller.loadStep.value.name} 중입니다.',
                  style: const TextStyle(color: Colors.white, fontSize: 18),
                ),
              ),
            ),

            const SizedBox(height: 20),

            // 2. DataLoadController의 isDataLoad를 수신하는 GetxListener
            GetxListener<bool>(
              stream: Get.find<DataLoadController>().isDataLoad,
              listen: _listenDataLoadComplete,
              child: const SizedBox.shrink(),
            ),

            // 3. AuthController의 isAuthLoading을 수신하는 GetxListener
            GetxListener<bool>(
              stream: Get.find<AuthController>().isAuthLoading,
              listen: _listenAuthLoading,
              child: const SizedBox.shrink(),
            ),
          ],
        ),
      ),
      // 테스트를 위한 FloatingActionButton (옵션)
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          // 강제로 앱 시작 단계로 전환하여 테스트
          controller.changeStep(StepType.startApp);
        },
        child: const Icon(Icons.skip_next),
      ),
    );
  }
}
