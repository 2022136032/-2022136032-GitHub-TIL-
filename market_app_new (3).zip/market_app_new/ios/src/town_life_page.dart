import 'package:flutter/material.dart';
import 'package:karrot_app_clone/widgets/app_font.dart';

// 동네생활 페이지
class TownLifePage extends StatelessWidget {
  const TownLifePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const AppFontDark('동네생활', fontWeight: FontWeight.bold),
        actions: const [
          IconButton(
            icon: Icon(Icons.search, color: Colors.white),
            onPressed: null,
          ),
          IconButton(
            icon: Icon(Icons.person_outline, color: Colors.white),
            onPressed: null,
          ),
        ],
      ),

      // 임시 콘텐츠
      body: Center(
        child: AppFontDark('동네생활 게시글 목록이 표시될 공간입니다.', color: Colors.grey),
      ),
    );
  }
}
