// GetX 패키지를 사용하여 홈 화면의 상품 목록 및 검색 상태를 관리하는 컨트롤러입니다.
import 'package:get/get.dart';

// 상품 데이터를 위한 간단한 모델 클래스입니다.
class Product {
  final int id;
  final String name;
  final String category;
  final double price;

  Product({
    required this.id,
    required this.name,
    required this.category,
    required this.price,
  });
}

// 홈 화면의 상태 및 로직을 관리하는 컨트롤러 클래스입니다.
class ProductHomeController extends GetxController {
  // 전체 상품 목록 (필터링되지 않은 원본 데이터)
  final List<Product> _allProducts = [
    Product(id: 1, name: '프리미엄 텀블러', category: '주방용품', price: 25000.0),
    Product(id: 2, name: '초경량 블루투스 이어폰', category: '전자제품', price: 89000.0),
    Product(id: 3, name: '유기농 채소 박스', category: '식품', price: 35000.0),
    Product(id: 4, name: '편안한 슬리퍼 5종 세트', category: '생활용품', price: 18000.0),
    Product(id: 5, name: '4K 모니터 27인치', category: '전자제품', price: 450000.0),
    Product(id: 6, name: '스마트 체중계', category: '전자제품', price: 49000.0),
  ];

  // 현재 화면에 표시되는 상품 목록 (검색 결과에 따라 변경됨)
  // GetX의 RxList를 사용하여 상태 변화를 UI에 자동으로 반영합니다.
  final RxList<Product> displayedProducts = <Product>[].obs;

  // 현재 검색어를 저장하는 반응형 변수입니다.
  final RxString currentSearchQuery = ''.obs;

  // 컨트롤러가 초기화될 때 호출됩니다.
  @override
  void onInit() {
    super.onInit();
    // 초기에는 전체 상품 목록을 표시합니다.
    displayedProducts.assignAll(_allProducts);
  }

  // 검색 쿼리를 업데이트하고 상품 목록을 필터링하는 메서드입니다.
  void filterProducts(String query) {
    // 1. 검색어 상태 업데이트
    currentSearchQuery.value = query.trim();

    // 검색어가 비어있거나 공백만 있는 경우
    if (query.isEmpty) {
      displayedProducts.assignAll(_allProducts);
      return;
    }

    // 2. 상품 목록 필터링
    final lowerCaseQuery = query.toLowerCase();

    // 상품 이름이나 카테고리에 검색어가 포함된 상품만 필터링합니다.
    final filteredList = _allProducts.where((product) {
      return product.name.toLowerCase().contains(lowerCaseQuery) ||
          product.category.toLowerCase().contains(lowerCaseQuery);
    }).toList();

    // 3. 표시되는 상품 목록 업데이트 (UI 자동 갱신)
    displayedProducts.assignAll(filteredList);
  }

  // 예시: 특정 카테고리로 필터링하는 옵션 메서드
  void filterByCategory(String category) {
    currentSearchQuery.value = '카테고리: $category';

    if (category == '전체') {
      displayedProducts.assignAll(_allProducts);
      return;
    }

    final filteredList = _allProducts.where((product) {
      return product.category == category;
    }).toList();

    displayedProducts.assignAll(filteredList);
  }

  // 검색 결과를 초기화하는 메서드입니다.
  void clearSearch() {
    currentSearchQuery.value = '';
    displayedProducts.assignAll(_allProducts);
  }
}

// =======================================================================
// 컨트롤러 사용 예시
// =======================================================================
void main() {
  // GetX 환경 설정 (테스트를 위해 수동으로 인스턴스 생성)
  final controller = ProductHomeController();
  controller.onInit(); // onInit 수동 호출

  print('--- 1. 초기 전체 상품 목록 (6개) ---');
  print('검색어: ${controller.currentSearchQuery.value}');
  controller.displayedProducts.forEach(
    (p) => print('${p.name} (${p.category})'),
  );

  // 검색 테스트: '블루' 검색
  controller.filterProducts('블루');
  print('\n--- 2. "블루" 검색 결과 (1개) ---');
  print('검색어: ${controller.currentSearchQuery.value}');
  controller.displayedProducts.forEach(
    (p) => print('${p.name} (${p.category})'),
  );

  // 카테고리 필터링 테스트: '전자제품'
  controller.filterByCategory('전자제품');
  print('\n--- 3. "전자제품" 카테고리 필터링 결과 (3개) ---');
  print('검색어: ${controller.currentSearchQuery.value}');
  controller.displayedProducts.forEach(
    (p) => print('${p.name} (${p.category})'),
  );

  // 검색 초기화
  controller.clearSearch();
  print('\n--- 4. 검색 초기화 후 (6개) ---');
  print('검색어: ${controller.currentSearchQuery.value}');
  controller.displayedProducts.forEach(
    (p) => print('${p.name} (${p.category})'),
  );
}
