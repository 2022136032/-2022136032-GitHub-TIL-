// 직원 정보를 관리하는 클래스 계층 구조를 정의하는 Dart 파일입니다.

// =======================================================================
// 1. Employee (직원) 클래스: 모든 직원의 기본 정보를 담는 추상 클래스
// =======================================================================
abstract class Employee {
  // 직원의 고유 ID (final로 불변 설정)
  final int id;
  // 직원 이름 (final로 불변 설정)
  final String name;
  // 직원 부서
  String department;

  // 생성자: 상속받는 클래스에서 호출되어 공통 필드를 초기화합니다.
  Employee({required this.id, required this.name, required this.department});

  // 추상 메서드: 급여를 계산하는 기능. 하위 클래스에서 반드시 구현해야 합니다.
  double calculateSalary();

  // 일반 메서드: 직원 기본 정보를 출력합니다.
  void displayInfo() {
    print('-------------------------------------');
    print('ID: $id');
    print('이름: $name');
    print('부서: $department');
  }
}

// =======================================================================
// 2. FullTimeEmployee (정규직 직원) 클래스: Employee 클래스 상속
// =======================================================================
class FullTimeEmployee extends Employee {
  // 연봉 (월급 계산을 위해 필요)
  final double annualSalary;
  // 보너스 비율 (예: 0.10은 10%)
  final double bonusRate;

  // 생성자: 부모 클래스의 생성자(super)를 호출하여 공통 필드를 초기화합니다.
  FullTimeEmployee({
    required super.id,
    required super.name,
    required super.department,
    required this.annualSalary,
    this.bonusRate = 0.0, // 기본 보너스율은 0%
  });

  // 추상 메서드 구현: 월급 계산 로직
  // 연봉을 12개월로 나누어 월급을 계산합니다.
  @override
  double calculateSalary() {
    // 보너스는 연말에 지급한다고 가정하고, 월급은 연봉/12로 계산
    return annualSalary / 12;
  }

  // 정보 출력 메서드 오버라이딩 (재정의)
  @override
  void displayInfo() {
    super.displayInfo(); // 부모 클래스의 기본 정보 출력 호출
    print('직군: 정규직');
    print('연봉: ${annualSalary.toStringAsFixed(0)}원');
    print('월 예상 급여: ${calculateSalary().toStringAsFixed(0)}원');
    print('보너스율: ${(bonusRate * 100).toStringAsFixed(0)}%');
    print('-------------------------------------');
  }
}

// =======================================================================
// 3. PartTimeEmployee (시간제 직원) 클래스: Employee 클래스 상속
// =======================================================================
class PartTimeEmployee extends Employee {
  // 시간당 시급
  final double hourlyRate;
  // 월 총 근무 시간
  int hoursWorkedMonthly;

  // 생성자
  PartTimeEmployee({
    required super.id,
    required super.name,
    required super.department,
    required this.hourlyRate,
    this.hoursWorkedMonthly = 0, // 기본 근무 시간은 0
  });

  // 추상 메서드 구현: 월급 계산 로직
  // 시급 * 월 근무 시간으로 계산합니다.
  @override
  double calculateSalary() {
    return hourlyRate * hoursWorkedMonthly;
  }

  // 정보 출력 메서드 오버라이딩 (재정의)
  @override
  void displayInfo() {
    super.displayInfo(); // 부모 클래스의 기본 정보 출력 호출
    print('직군: 시간제');
    print('시급: ${hourlyRate.toStringAsFixed(0)}원');
    print('월 근무 시간: ${hoursWorkedMonthly}시간');
    print('월 예상 급여: ${calculateSalary().toStringAsFixed(0)}원');
    print('-------------------------------------');
  }
}

// =======================================================================
// 예제 실행을 위한 main 함수
// =======================================================================
void main() {
  // 정규직 직원 객체 생성
  var fullTimer = FullTimeEmployee(
    id: 1001,
    name: '김개발',
    department: '소프트웨어 개발팀',
    annualSalary: 72000000.0,
    bonusRate: 0.15,
  );

  // 시간제 직원 객체 생성
  var partTimer = PartTimeEmployee(
    id: 2002,
    name: '박디자인',
    department: '디자인팀',
    hourlyRate: 15000.0,
    hoursWorkedMonthly: 80,
  );

  // 직원 정보 출력
  print('--- 개별 직원 정보 출력 ---');
  fullTimer.displayInfo();
  partTimer.displayInfo();

  // 다형성을 활용하여 직원 목록 관리 (List<Employee>)
  List<Employee> employeeList = [
    fullTimer,
    partTimer,
    FullTimeEmployee(
      id: 1003,
      name: '최영업',
      department: '영업팀',
      annualSalary: 60000000.0,
    ),
  ];

  print('\n--- 전체 직원 급여 일괄 계산 ---');
  double totalPayroll = 0;

  // 모든 직원에게 동일한 메서드(calculateSalary)를 호출할 수 있습니다 (다형성).
  for (var emp in employeeList) {
    double monthlyPay = emp.calculateSalary();
    print(
      '${emp.name} (${emp.department})의 월급: ${monthlyPay.toStringAsFixed(0)}원',
    );
    totalPayroll += monthlyPay;
  }

  print('\n[Image of a graph showing payroll distribution]');

  print('전체 직원 월 총 급여 합계: ${totalPayroll.toStringAsFixed(0)}원');
}
