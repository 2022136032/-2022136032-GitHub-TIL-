import 'package:get/get.dart';
import 'package:karrot_app_clone/common/controller/auth_controller.dart';

// AuthPage에서 사용되는 컨트롤러들을 바인딩
class AuthBinding extends Bindings {
  @override
  void dependencies() {
    // AuthController는 AppBinding에서 영구적으로 생성될 수 있지만,
    // 여기서는 AuthPage에 진입할 때만 필요하도록 설정 (필요에 따라 변경 가능)
    // 그러나 인증 상태는 앱 전역에서 필요하므로 AppBinding에서 이미 Put되어 있을 가능성이 높습니다.
    // 따라서 Get.find()로 인스턴스를 가져옵니다.
    // 만약 AppBinding에 없다면 아래와 같이 Get.lazyPut()으로 생성합니다.
    if (!Get.isRegistered<AuthController>()) {
      Get.lazyPut<AuthController>(() => AuthController());
    }
  }
}
