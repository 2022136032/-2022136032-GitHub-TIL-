// Dart 언어를 사용하여 간단한 온라인 샵의 데이터 모델을 정의하는 파일입니다.

// 1. Product (상품) 클래스
class Product {
  // 상품의 고유 ID (식별자)
  final int id;
  // 상품 이름
  final String name;
  // 상품 가격
  final double price;
  // 상품 재고 수량
  int stockQuantity;

  // 생성자: 필수 매개변수를 사용하여 객체를 초기화합니다.
  Product({
    required this.id,
    required this.name,
    required this.price,
    this.stockQuantity = 0, // 기본값으로 0 설정
  });

  // 상품 정보를 콘솔에 출력하는 메서드
  void displayProductInfo() {
    print('--- 상품 정보 ---');
    print('ID: $id');
    print('이름: $name');
    print('가격: ${price.toStringAsFixed(2)}원'); // 소수점 둘째 자리까지 표시
    print('재고: $stockQuantity개');
  }
}

// 2. Customer (고객) 클래스
class Customer {
  // 고객의 고유 ID
  final String customerId;
  // 고객 이름
  final String name;
  // 고객 주소 (선택 사항)
  String? address;

  // 생성자
  Customer({required this.customerId, required this.name, this.address});

  // 고객 정보를 콘솔에 출력하는 메서드
  void displayCustomerInfo() {
    print('--- 고객 정보 ---');
    print('고객 ID: $customerId');
    print('이름: $name');
    print('주소: ${address ?? '주소 정보 없음'}'); // null일 경우 대체 텍스트 표시
  }
}

// 3. Order (주문) 클래스
class Order {
  // 주문의 고유 ID
  final String orderId;
  // 주문 날짜
  final DateTime orderDate;
  // 주문한 상품 객체
  final Product product;
  // 주문한 고객 객체
  final Customer customer;
  // 주문 수량
  final int quantity;

  // 생성자
  Order({
    required this.orderId,
    required this.orderDate,
    required this.product,
    required this.customer,
    required this.quantity,
  });

  // 총 주문 금액을 계산하는 게터(Getter)
  double get totalAmount {
    return product.price * quantity;
  }

  // 주문 상세 정보를 콘솔에 출력하는 메서드
  void displayOrderDetails() {
    print('\n==============================');
    print('         주문 상세 정보         ');
    print('==============================');
    print('주문 번호: $orderId');
    print('주문 날짜: ${orderDate.toLocal()}');
    print('------------------------------');

    // 고객 정보 출력
    customer.displayCustomerInfo();
    print('------------------------------');

    // 주문 상품 정보 출력
    print('--- 주문 상품 ---');
    print('상품명: ${product.name}');
    print('단가: ${product.price.toStringAsFixed(2)}원');
    print('수량: $quantity개');
    print('------------------------------');
    print('총 결제 금액: ${totalAmount.toStringAsFixed(2)}원');
    print('==============================\n');
  }
}

// 예제 실행을 위한 main 함수 (선택 사항, 모델 테스트용)
void main() {
  // 1. 상품 객체 생성
  var laptop = Product(
    id: 101,
    name: '최신형 노트북',
    price: 1500000.0,
    stockQuantity: 50,
  );
  var mouse = Product(
    id: 202,
    name: '무선 마우스',
    price: 25000.0,
    stockQuantity: 100,
  );

  // 2. 고객 객체 생성
  var user1 = Customer(customerId: 'CUST-001', name: '김철수', address: '서울시 강남구');
  var user2 = Customer(customerId: 'CUST-002', name: '이영희');

  // 3. 주문 객체 생성 (노트북 1개 주문)
  var order1 = Order(
    orderId: 'ORD-2024-0001',
    orderDate: DateTime.now(),
    product: laptop,
    customer: user1,
    quantity: 1,
  );

  // 4. 주문 객체 생성 (마우스 3개 주문)
  var order2 = Order(
    orderId: 'ORD-2024-0002',
    orderDate: DateTime(2024, 12, 10, 15, 30), // 특정 날짜 지정
    product: mouse,
    customer: user2,
    quantity: 3,
  );

  // 생성된 객체 정보 출력
  order1.displayOrderDetails();
  order2.displayOrderDetails();

  // 상품 재고 정보 확인
  laptop.displayProductInfo();
}
