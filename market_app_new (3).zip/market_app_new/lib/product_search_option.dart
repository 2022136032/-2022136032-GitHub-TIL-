import 'package:market_app_new/market_enum.dart';

class ProductSearchOption extends Equatable {
  QueryDocumentSnapshot? lastItem;
  List<ProductStatusType>? status;
  String? ownerId;

  ProductSearchOption({
    this.lastItem,
    this.status
    this.ownerId,
  });

  @ovrride
  List<Object?> get props => [
    lastItem,
    status,
    ownerId,
  ];
}
