import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloned_market/models/product.dart';
import 'package:cloned_market/repositories/product_repository.dart';

class ProductWriteController extends GetxController {
  final ProductRepository _repository = ProductRepository();

  // 텍스트 필드 컨트롤러들
  final titleController = TextEditingController();
  final priceController = TextEditingController();
  final stockController = TextEditingController(); // 재고 수량
  final descriptionController = TextEditingController();

  // 상태 변수들
  final RxString selectedCategory = ''.obs;
  final RxBool isLoading = false.obs;
  final RxList<String> selectedImages = <String>[].obs; // 이미지 경로(임시)

  // 카테고리 목록
  final List<String> categories = ['디지털기기', '생활가전', '가구/인테리어', '의류', '기타'];

  // 카테고리 선택 함수
  void setCategory(String category) {
    selectedCategory.value = category;
  }

  // 상품 등록 실행 함수
  Future<void> uploadProduct() async {
    // 1. 유효성 검사
    if (titleController.text.isEmpty ||
        priceController.text.isEmpty ||
        selectedCategory.value.isEmpty ||
        descriptionController.text.isEmpty) {
      Get.snackbar(
        '알림',
        '모든 필드를 입력해주세요.',
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.redAccent,
        colorText: Colors.white,
      );
      return;
    }

    isLoading.value = true;

    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) {
        Get.snackbar('오류', '로그인이 필요합니다.');
        return;
      }

      // 2. 모델 생성
      final newProduct = Product(
        title: titleController.text,
        price: int.parse(priceController.text),
        stockQuantity: int.parse(
          stockController.text.isEmpty ? '1' : stockController.text,
        ),
        category: selectedCategory.value,
        description: descriptionController.text,
        imageUrls: [], // 실제 이미지 업로드 로직은 별도 구현 필요 (여기선 빈 리스트)
        sellerId: user.uid,
        createdAt: DateTime.now(),
      );

      // 3. 레포지토리 호출
      await _repository.addProduct(newProduct);

      // 4. 성공 처리
      Get.back(); // 페이지 닫기
      Get.snackbar(
        '성공',
        '상품이 등록되었습니다!',
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.green,
        colorText: Colors.white,
      );
    } catch (e) {
      Get.snackbar('오류', '등록 중 문제가 발생했습니다: $e');
    } finally {
      isLoading.value = false;
    }
  }

  @override
  void onClose() {
    titleController.dispose();
    priceController.dispose();
    stockController.dispose();
    descriptionController.dispose();
    super.onClose();
  }
}
