import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:cloned_market/controllers/product_write_controller.dart'; // 경로 확인

class ProductWritePage extends StatelessWidget {
  const ProductWritePage({super.key});

  @override
  Widget build(BuildContext context) {
    // 컨트롤러 주입 (화면이 생성될 때 같이 생성)
    final controller = Get.put(ProductWriteController());

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          '중고거래 글쓰기',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        actions: [
          Obx(
            () => TextButton(
              onPressed: controller.isLoading.value
                  ? null
                  : controller.uploadProduct,
              child: controller.isLoading.value
                  ? const SizedBox(
                      width: 16,
                      height: 16,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Text(
                      '완료',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Colors.orange,
                      ),
                    ),
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // 1. 이미지 추가 버튼 (목업)
            Container(
              width: 80,
              height: 80,
              decoration: BoxDecoration(
                border: Border.all(color: Colors.grey.shade300),
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.camera_alt, color: Colors.grey),
                  Text(
                    '0/10',
                    style: TextStyle(color: Colors.grey, fontSize: 12),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // 2. 제목 입력
            TextField(
              controller: controller.titleController,
              decoration: const InputDecoration(
                hintText: '글 제목',
                border: InputBorder.none, // 밑줄 제거
              ),
              style: const TextStyle(fontSize: 18),
            ),
            const Divider(),

            // 3. 카테고리 선택
            ListTile(
              contentPadding: EdgeInsets.zero,
              title: Obx(
                () => Text(
                  controller.selectedCategory.value.isEmpty
                      ? '카테고리 선택'
                      : controller.selectedCategory.value,
                  style: TextStyle(
                    color: controller.selectedCategory.value.isEmpty
                        ? Colors.black
                        : Colors.black87,
                    fontWeight: controller.selectedCategory.value.isEmpty
                        ? FontWeight.normal
                        : FontWeight.bold,
                  ),
                ),
              ),
              trailing: const Icon(Icons.chevron_right),
              onTap: () {
                // 카테고리 선택 바텀시트
                Get.bottomSheet(
                  Container(
                    color: Colors.white,
                    child: ListView(
                      shrinkWrap: true,
                      children: controller.categories
                          .map(
                            (cat) => ListTile(
                              title: Text(cat),
                              onTap: () {
                                controller.setCategory(cat);
                                Get.back();
                              },
                            ),
                          )
                          .toList(),
                    ),
                  ),
                );
              },
            ),
            const Divider(),

            // 4. 가격 입력
            TextField(
              controller: controller.priceController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                hintText: '가격 (₩)',
                prefixText: '₩ ',
                border: InputBorder.none,
              ),
            ),
            const Divider(),

            // 5. 재고 수량 입력 (요청하신 추가 필드)
            TextField(
              controller: controller.stockController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                hintText: '수량 (선택사항, 기본 1개)',
                border: InputBorder.none,
              ),
            ),
            const Divider(),

            // 6. 상세 설명 입력
            TextField(
              controller: controller.descriptionController,
              maxLines: 10,
              decoration: const InputDecoration(
                hintText: '게시글 내용을 작성해주세요.\n(가품 및 판매 금지 품목은 게시가 제한될 수 있어요.)',
                border: InputBorder.none,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
