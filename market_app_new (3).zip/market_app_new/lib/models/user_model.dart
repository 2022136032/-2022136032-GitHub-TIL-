import 'package:cloud_firestore/cloud_firestore.dart';

// 당근마켓 클론 앱의 사용자 프로필 데이터 모델
class UserModel {
  final String uid; // Firebase User ID
  final String nickname;
  final String town; // 사용자 설정 동네
  final double temperature; // 매너 온도
  final String profileImageUrl;

  UserModel({
    required this.uid,
    required this.nickname,
    required this.town,
    required this.temperature,
    required this.profileImageUrl,
  });

  // 1. JSON (Map)으로 변환
  Map<String, dynamic> toMap() {
    return {
      'uid': uid,
      'nickname': nickname,
      'town': town,
      'temperature': temperature,
      'profileImageUrl': profileImageUrl,
      'updatedAt': FieldValue.serverTimestamp(), // 마지막 업데이트 시간
    };
  }

  // 2. Firestore DocumentSnapshot에서 UserModel 생성
  factory UserModel.fromSnapshot(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return UserModel(
      uid: data['uid'] ?? '',
      nickname: data['nickname'] ?? '익명',
      town: data['town'] ?? '설정 안됨',
      // Firestore에서 double이 아닌 int로 저장될 수 있으므로 toDouble() 사용
      temperature: (data['temperature'] as num?)?.toDouble() ?? 36.5,
      profileImageUrl: data['profileImageUrl'] ?? '',
    );
  }

  // 3. Map에서 UserModel 생성
  factory UserModel.fromMap(Map<String, dynamic> map) {
    return UserModel(
      uid: map['uid'] ?? '',
      nickname: map['nickname'] ?? '익명',
      town: map['town'] ?? '설정 안됨',
      temperature: (map['temperature'] as num?)?.toDouble() ?? 36.5,
      profileImageUrl: map['profileImageUrl'] ?? '',
    );
  }
}
