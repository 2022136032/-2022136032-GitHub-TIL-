// models/product.dart
/// 상품 정보를 나타내는 데이터 모델 클래스입니다.
class Product {
  // Firestore 문서 ID. 상품이 생성된 후 부여됩니다.
  final String? productId;

  final String name;
  final int price; // 가격 (필수)
  final int stockQuantity; // 재고 수량 (필수)
  final String category;
  final String description;
  final String? imageUrl; // 대표 이미지 URL (옵션)

  // 시스템 관련 필드
  final String? userId; // 등록한 사용자 ID
  final String? createdAt; // 등록 시간
  final String? updatedAt; // 최종 수정 시간

  Product({
    this.productId,
    required this.name,
    required this.price,
    required this.stockQuantity,
    required this.category,
    required this.description,
    this.imageUrl,
    this.userId,
    this.createdAt,
    this.updatedAt,
  });

  /// Firestore 저장을 위해 Map<String, dynamic> 형태로 변환하는 메서드입니다.
  Map<String, dynamic> toJson() {
    return {
      // productId는 Firestore 문서 ID로 사용되므로, Map에는 포함하지 않거나 null로 처리합니다.
      'name': name,
      'price': price,
      'stockQuantity': stockQuantity,
      'category': category,
      'description': description,
      'imageUrl': imageUrl,
      'userId': userId,
      'createdAt': createdAt ?? DateTime.now().toIso8601String(),
      'updatedAt': DateTime.now().toIso8601String(), // 업데이트 시간은 항상 현재 시간으로 설정
    };
  }

  /// Firestore에서 읽어온 Map<String, dynamic>을 Product 객체로 변환하는 팩토리 메서드입니다.
  factory Product.fromJson(Map<String, dynamic> json, String? id) {
    return Product(
      productId: id,
      name: json['name'] as String,
      price: json['price'] as int,
      stockQuantity: json['stockQuantity'] as int,
      category: json['category'] as String,
      description: json['description'] as String,
      imageUrl: json['imageUrl'] as String?,
      userId: json['userId'] as String?,
      createdAt: json['createdAt'] as String?,
      updatedAt: json['updatedAt'] as String?,
    );
  }
}
