// repositories/product_repository.dart
import '../models/product.dart';
import 'dart:async';

/// Firebase Firestore와 관련된 데이터베이스 상호작용을 처리합니다.
class ProductRepository {
  ProductRepository();

  /// 새로운 상품 데이터를 Firestore에 저장합니다. (모의 함수)
  Future<String> saveProduct(
    String appId,
    String userId,
    Product product,
  ) async {
    final collectionPath = 'artifacts/$appId/users/$userId/products';

    // **Canvas 환경을 위한 모의(Mock) 데이터 저장 및 지연 로직**
    await Future.delayed(Duration(milliseconds: 800)); // 네트워크 지연 모방

    // 모의 등록 ID 생성
    final mockProductId = 'prod_${DateTime.now().millisecondsSinceEpoch}';
    print(
      '[Repository Mock] 상품 데이터 저장 완료: Path=$collectionPath, ID=$mockProductId',
    );
    return mockProductId;
  }
}
