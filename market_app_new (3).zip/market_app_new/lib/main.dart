import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:market_app_new/cloud_firebase_stroge_repository.dart';
import 'package:market_app_new/cloud_firestore/cloud_firestore.dart';
import 'package:market_app_new/common_layout.dart';
import 'package:market_app_new/models/product_repository.dart';
import '../ios/src/data_load_controller.dart';
import 'firebase_options.dart'; // Firebase 초기화 옵션 파일

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  try {
    // Firebase는 MainScreen 진입 전 초기화되어야 합니다.
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );
    print("✅ Firebase 초기화 성공!");
  } catch (e) {
    print("❌ Firebase 초기화 실패: $e");
    // 초기화 실패 시 앱을 계속 진행하거나 종료하는 로직 추가
  }

  runApp(const KarrotApp());
}

// 앱의 최상위 위젯: GetMaterialApp 사용
class KarrotApp extends StatelessWidget {
  const KarrotApp({super.key});

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      debugShowCheckedModeBanner: false,
      title: '당근마켓 클론',
      initialRoute: '/',

      // 앱 전체에서 사용할 컨트롤러를 미리 바인딩
      initialBinding: BindingsBuilder(() {
        Get.put(SplashController());
        Get.put(DataLoadController());
        Get.put(AuthController()); // AuthController 바인딩
      }),

      theme: ThemeData(
        // 당근마켓 주황색 계열의 시드 컬러
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFFFE7E36)),
        useMaterial3: true,
        // AppBar 테마 설정
        appBarTheme: const AppBarTheme(
          elevation: 0,
          color: Color(0xFF212123),
          titleTextStyle: TextStyle(color: Colors.white),
        ),
        // Scafflod 배경색도 0xFF212123으로 설정 (SplashPage와 통일)
        scaffoldBackgroundColor: const Color(0xFF212123),
        // 기본 폰트 NotoSans로 설정
        textTheme: GoogleFonts.notoSansTextTheme(
          Theme.of(context).textTheme,
        ).apply(bodyColor: Colors.white, displayColor: Colors.white),
      ),

      // GetX의 라우팅 설정
      getPages: [
        GetPage(
          name: '/',
          page: () => const SplashPage(),
        ), // 앱 시작 시 최초 화면 (스플래시)
        GetPage(name: '/main', page: () => const MainScreen()), // 메인 탭 화면
      ],
    );
  }
}

// 메인 화면 (임시)
class MainScreen extends StatelessWidget {
  const MainScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('메인 화면', style: TextStyle(color: Colors.white)),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text('앱 메인 화면입니다.', style: TextStyle(color: Colors.white)),
            const SizedBox(height: 20),
            // 현재 로그인된 UID 표시
            Obx(
              () => Text(
                'User UID: ${Get.find<AuthController>().user.value?.uid ?? '로그아웃 상태'}',
                style: const TextStyle(color: Colors.white70),
              ),
            ),
          ],
        ),
      ),
    );
  }
}


// [Firebase 초기화] main 함수
void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  try {
    await Firebase.initializeApp(
      // firebase_options.dart 파일은 가정합니다.
      // options: DefaultFirebaseOptions.currentPlatform, 
    );
    print("✅ Firebase 초기화 성공!");
  } catch (e) {
    print("❌ Firebase 초기화 실패: $e");
  }

  runApp(const KarrotApp());
}

// 앱의 최상위 위젯: GetMaterialApp 사용
class KarrotApp extends StatelessWidget {
  const KarrotApp({super.key});

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      debugShowCheckedModeBanner: false,
      title: '당근마켓 클론',
      initialRoute: '/',
      
      // 앱 전체에서 사용할 컨트롤러를 미리 바인딩
      initialBinding: BindingsBuilder(() {
        Get.put(SplashController());
        Get.put(DataLoadController());
        Get.put(AuthController());
        Get.put(MainController()); // MainController 바인딩
      }),
      
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFFFE7E36)), 
        useMaterial3: true,
        appBarTheme: const AppBarTheme(
          elevation: 0,
          color: Color(0xFF212123),
          titleTextStyle: TextStyle(color: Colors.white),
        ),
        scaffoldBackgroundColor: const Color(0xFF212123),
        textTheme: GoogleFonts.notoSansTextTheme(Theme.of(context).textTheme).apply(
          bodyColor: Colors.white,
          displayColor: Colors.white,
        ),
      ),
      
      // GetX의 라우팅 설정
      getPages: [
        GetPage(name: '/', page: () => const SplashPage()),
        GetPage(name: '/main', page: () => const MainScreen()), 
        // /write 라우트와 WriteController 바인딩 추가
        GetPage(
          name: '/write', 
          page: () => const WritePage(),
          binding: BindingsBuilder(() => Get.lazyPut(() => WriteController())),
        ),
      ],
    );
  }
}
void main() async {
  // Flutter 엔진 바인딩 초기화
  WidgetsFlutterBinding.ensureInitialized();
  
  // Firebase 초기화
  try {
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );
  } catch (e) {
    // Firebase 초기화 오류 발생 시 디버그 콘솔에 출력
    print("❌ Firebase 초기화 오류: $e");
  }

  // 앱 실행
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      title: 'Karrot Clone App',
      // GetMaterialApp 사용: GetX 라우팅, 상태 관리, 의존성 주입을 활용합니다.
      
      // 다크 모드 테마 적용
      theme: AppTheme.darkTheme,
      
      // 초기 바인딩: 앱 전역에서 사용할 서비스 및 컨트롤러 초기화
      initialBinding: AppBinding(),
      
      // 스플래시 화면을 초기 화면으로 설정
      initialRoute: AppRoutes.SPLASH,
      
      // 앱의 모든 라우트 정의
      getPages: AppPages.routes,
      
      // 디버그 배너 숨기기
      debugShowCheckedModeBanner: false,
      
      // 로딩 중 표시할 페이지 (혹은 초기화 전에 보여줄 위젯)
      home: const SplashPage(),
    );
  }

var __firebase_config;

void main() async {
  // Flutter 위젯 바인딩 초기화
  WidgetsFlutterBinding.ensureInitialized();

  // Firebase 초기화 로직
  // Canvas 환경에서 제공되는 __firebase_config를 사용합니다.
  try {
    // __firebase_config가 문자열 형태로 주어지므로 JSON으로 파싱합니다.
    final firebaseConfig = (typeof __firebase_config != 'undefined' && __firebase_config != null) 
      ? jsonDecode(__firebase_config) 
      : null;

    if (firebaseConfig != null) {
      await Firebase.initializeApp(
        options: FirebaseOptions(
          apiKey: firebaseConfig['apiKey'] ?? '',
          appId: firebaseConfig['appId'] ?? '',
          messagingSenderId: firebaseConfig['messagingSenderId'] ?? '',
          projectId: firebaseConfig['projectId'] ?? '',
          storageBucket: firebaseConfig['storageBucket'] ?? '',
        ),
      );
      print("✅ Firebase 초기화 성공");
    } else {
      print("⚠️ Firebase 설정 정보가 제공되지 않았습니다. Firebase 기능을 사용할 수 없습니다.");
      // Firebase 없이 앱을 실행하도록 진행합니다.
    }
  } catch (e) {
    print("❌ Firebase 초기화 중 오류 발생: $e");
    // 오류가 발생해도 앱은 계속 실행됩니다.
  }

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      title: 'Karrot Clone (당근마켓)',
      debugShowCheckedModeBanner: false, // 디버그 배너 숨기기

      // 테마 설정 (다크 모드 기준)
      theme: AppTheme.darkTheme,
      
      // 초기 바인딩 설정
      initialBinding: InitialBinding(),

      // 라우팅 설정
      initialRoute: AppRoutes.SPLASH, // 앱 시작 시 Splash 화면으로 이동
      getPages: AppPages.pages, // GetX 라우트 정의 목록
    );
  }
}

// Firebase 설정을 위한 전역 변수 (Canvas 환경에서 제공됨)
// 실제 환경에서는 환경 변수나 별도 파일을 사용해야 합니다.
// ignore: prefer_typing_uninitialized_variables
var __firebase_config;

void main() async {
  // Flutter 위젯 바인딩 초기화
  WidgetsFlutterBinding.ensureInitialized();

  // Firebase 초기화 로직
  // Canvas 환경에서 제공되는 __firebase_config를 사용합니다.
  try {
    // __firebase_config가 문자열 형태로 주어지므로 JSON으로 파싱합니다.
    final firebaseConfig = (typeof __firebase_config != 'undefined' && __firebase_config != null) 
      ? jsonDecode(__firebase_config) 
      : null;

    if (firebaseConfig != null) {
      await Firebase.initializeApp(
        options: FirebaseOptions(
          apiKey: firebaseConfig['apiKey'] ?? '',
          appId: firebaseConfig['appId'] ?? '',
          messagingSenderId: firebaseConfig['messagingSenderId'] ?? '',
          projectId: firebaseConfig['projectId'] ?? '',
          storageBucket: firebaseConfig['storageBucket'] ?? '',
        ),
      );
      print("✅ Firebase 초기화 성공");
    } else {
      print("⚠️ Firebase 설정 정보가 제공되지 않았습니다. Firebase 기능을 사용할 수 없습니다.");
      // Firebase 없이 앱을 실행하도록 진행합니다.
    }
  } catch (e) {
    print("❌ Firebase 초기화 중 오류 발생: $e");
    // 오류가 발생해도 앱은 계속 실행됩니다.
  }

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      title: 'Karrot Clone (당근마켓)',
      debugShowCheckedModeBanner: false, // 디버그 배너 숨기기

      // 테마 설정 (다크 모드 기준)
      theme: AppTheme.darkTheme,
      
      // 초기 바인딩 설정
      initialBinding: InitialBinding(),

      // 라우팅 설정
      initialRoute: AppRoutes.SPLASH, // 앱 시작 시 Splash 화면으로 이동
      getPages: AppPages.pages, // GetX 라우트 정의 목록
    );
  }
}
import 'dart:io';
import 'heic_converter.dart';

// Dart 프로그램의 진입점
void main() async {
  // 1. 서비스 초기화
  final converter = HeicConversionService();

  // 2. 업로드된 파일 시뮬레이션 목록
  final uploadedFileNames = [
    'image-3eeb119b.heic',
    'image-94a22b56.heic',
    'image-2700e818.heic',
    'image-92fa7d8d.heic',
    'image-c44e3d0c.heic',
  ];

  converter.initializeFiles(uploadedFileNames);

  print('\n--- 파일 목록 ---');
  for (var file in converter.files) {
    print('ID: ${file.id}, 파일명: ${file.fileName}');
  }
  print('-----------------\n');

  // 3. 파일 제거 시뮬레이션
  if (converter.files.isNotEmpty) {
    final fileToRemove = converter.files[0];
    converter.removeFile(fileToRemove.id);
    print('${fileToRemove.fileName} 파일 제거 완료. 남은 파일: ${converter.files.length}개');
  }

  // 4. 남아 있는 파일의 변환 시뮬레이션
  print('\n--- 변환 시뮬레이션 시작 ---\n');
  final remainingFiles = converter.files;
  
  if (remainingFiles.isEmpty) {
    print('변환할 파일이 남아있지 않습니다.');
    return;
  }

  for (var file in remainingFiles) {
    final result = await converter.simulateConversion(file);
    
    if (result.status == 'Converted') {
      print('✅ 성공: ${file.fileName} -> ${result.newFileName}');
    } else {
      print('❌ 실패: ${file.fileName} - ${result.error}');
    }
  }

  print('\n--- 변환 시뮬레이션 완료 ---');
}

// Canvas 환경에서 제공되는 전역 변수 모방 (실제로는 환경에서 주입됨)
const String _initialAppId = 'default-product-app-id';
const String _initialFirebaseConfig = '{}'; 
const String _initialAuthToken = 'mock-custom-auth-token';

/// 콘솔에 상태 메시지를 출력하는 View 역할 모방 함수
void displayStatus(String message, bool isSuccess) {
  final status = isSuccess ? '[성공]' : '[실패]';
  print('\n--------------------------------');
  print('$status $message');
  print('--------------------------------\n');
}

/// Firebase 및 Auth 초기화를 시뮬레이션하는 함수
Future<String> initializeFirebaseAndAuthenticate() async {
  print('[Init] Firebase 설정 로드 중...');
  // 모의 사용자 ID 반환 (실제 인증이 성공했을 때 반환되는 ID)
  final String mockUserId = 'user-uid-1234567890';
  print('[Auth Mock] 사용자 인증 완료. 모의 UID: $mockUserId, App ID: $_initialAppId');
  return mockUserId;
}


void main() async {
  print('--- Dart 상품 등록 데모 시작 ---');

  String userId;
  try {
    // 1. Firebase 및 Auth 초기화 및 사용자 ID 획득
    userId = await initializeFirebaseAndAuthenticate();
    
  } catch (e) {
    print('애플리케이션 초기화 실패: $e');
    return;
  }

  // 2. Repository와 Controller 초기화
  final repository = ProductRepository(); 
  final controller = ProductWriteController(repository);

  // 3. View (사용자 입력 모방 및 컨트롤러 호출)

  // (A) 성공적인 상품 등록 시도
  print('\n[A] 성공적인 상품 등록 시도');
  final successData = {
    'name': '최신형 스마트워치 X1',
    'price': 150000,
    'stockQuantity': 50, // 재고 필드
    'category': 'electronics',
    'description': '심박수, 수면 추적 기능을 갖춘 최신형 스마트워치입니다.',
    'imageUrl': 'https://placehold.co/400x300/CCCCCC/333333?text=Product+Image',
  };
  await controller.registerProduct(_initialAppId, userId, successData, displayStatus);


  // (B) 필수 필드가 누락된 실패 시도
  print('\n[B] 필수 필드 누락 (가격 0) 실패 시도');
  final invalidData = {
    'name': '테스트 상품',
    'price': 0, 
    'stockQuantity': 10,
    'category': 'books',
    'description': '설명',
  };
  await controller.registerProduct(_initialAppId, userId, invalidData, displayStatus);

  print('\n--- Dart 상품 등록 데모 종료 ---');
}

initialBinding: BindingBuilder(() {
  var authenticationRepository =
  AuthenticationRepository (FirebaseAuth.instance);
  var user_repository = UserRepository(db);
  Get.put(authenticationRepository);
  Get.put(user_repository);
  Get.put(CommonLayoutController());
  Get.put(ProductRepository(db));
  Get.put(BottomNavController());
  Get.put(DataLoadController());
  Get.put(AuthenticationController(
    authenticationRepository,
    user_repository,
  ));
  Get.put(CloudFirebaseStrogeRepository(FirebaseStorage.instance));
}),