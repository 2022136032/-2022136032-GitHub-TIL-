import 'package:flutter/material.dart';
import 'package:market_app_new/trade_location_map.dart';

class MultifulImageView {} extends StatefulWidget {
  const MultifulImageView({super.key});

  @override
  State<MultifulImageView> createState() => _multifulImageViewState();

}

class _MultifulImageViewState extends State<MultifulImageView> {
  @override
  Widget build(BuildContext context) {
    return Container();
 
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const AppFont(
          fontWeight: FonWeight.bold,
          size: 18,
        ),
        actions: [
          GestureDetector(
            onTap: () {},
            child: const padding(
              padding: EdgeInsets.only(top: 20,0, right:25).
              child: AppFont(
                '완료',
                color: Color(0xffED7738),
                size: 16,
                fontWeight: FontWeight.bold,
              ))
            ),
          )
      ),
],
    body: Column(
      children: [
        Expended(
          child: GridView.builder(
            itemCount: 100,
            padding: EdgeInsets.zero,
            gridDelegate: const SilverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 3,
              crossAxisSpacting: 1,
              mainAxisSpacing: 1,
            ),
            itemBuilder: (BuildContext context, int index) {
              return Container(
                color: Colors.red,
              )
            },
          )
        )
      ],
    )
  }
  }
}

@override
void initState() {
  super.initState();
  loadMyPhoto();
}

void loadMyPhotos() async {
  var permissionState = await PhotoManger.requestPermissionExtend();
  if(permissionState == permissionState.limited ||
  permissionState == permissionState.authorized) {
    var albums = <AssetPathEntity>[];

    @override
    void initState() {
      super.initState();
      loadMyPhotos();
    }

    void loadMyPhotos() async {
      var permissionState = await PhotoManger.requestPermissionExtend();
      if (permissionState == permissionState.limited ||
      permissionState == permissionState.authorized) {
        albums = await PhotoManger.getAssetPathList(
          type: RequestType.image,
          filterOption: FilterOptionGroup(
            imageOption: const FilterOption(
              minWidth: 800,
              minHeight: 800,
            )),
            orders: [
              const OrderOption(type: OrderOptionType.createDate, asc: false)
            ],
        ),
      },
    };
  }
  _pagingPhoto();
}

var imageList = <AssetEntity>[];
int currentPage = 0;

Future<void> _padingPhotos() async {
  if (albums.isNotEmpty) {
    var photos =
    await albums.first.getAssetListPaged(page: currenPage, size:60);

    if (currenPage == 0) {
      imageList.clear();
    }

    setState(() {
      imageList = photos;
    });
  }
}

body: Column(
  children: [
    Expanded(
      child: GridView.builder(
        itemCount: imageList.length,
        padding: EdgeInsets.zero,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 3,
          crossAxisSpacing: 1,
          mainAxisSpacing: 1,
        ),
        itemBuilder: (BuildContext context, int index) {
          return _photoWidget(imageList[index]);
        },
      ),
    )
  ],
),
widget _photoWidget(AssetEntity asset) {
  return FutureBuilder<Uint8List?> (
    future: asset.thumbnailDataWithSize(const Thumbnailsize(200, 200)),
  builder: (_, snapshot) {
    if (snapshot.hasData) {
      return SizedBox(
        width: double.infinity,
        height: double.infinity,
        child: Image.memory(
          snapshot.datal,
          fit: BoxFit.cover,
        ),
      );
    } else (
      return Contanier();
    )
  },
  )
}

var selectedImages = <AssetEntity>[];

bool containValue(AssetEntity value) {
  return selectedImages.where((element) => element.id == value.id).isNotEmpty;
}

String returnIndexValue(AssetEntity value) {
  var find = selectedImages.asMap().entries.where((element) {
    return element.value.id == value.id;
  });
  if (find.isEmpty) return '';
  return (find.first.key + 1).toString();
}

Widget _photoWidget(AssetEntity asset) {
  return FutureBuilder(Unit8List?)
  future: asset.thumbnailDataWithSize(const ThimbnailSize(200,200)),
  builder: (_, snapshot) {
    if (snapshot.hasData) {
      return Stack(
        children: [
          SizedBox(
            width: double.infinity,
            height: double.infinity,
            child:  Image.memory(
              snapshot.datal,
              fit: BoxFit.cover,
            ),
          )
          Positioned(
            left: 0,
            bottom: 0,
            right: 0,
            top: 0,
            child: Stack(children: [
              Positioned(
                top: 0,
            right: 0,
            left: 0,
            bottom: 0,
            child: Container(
              color: Container(
                color: Container(
                  color: Colors.white
                  .withOpacity(containValue((asset))) ? 0.5 : 0),
                ),
              ),
              Positioned(
                top: 0,
                right: 0,
                child: GestureDetector(
                  ontap: () {},
                  behavior: HitTestBehavior.translucent,
                  child: Container(
                    margin: const EdgeInsets.all(10),
                    width: 25,
                    height: 25,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: containValue(asset)
                      ? Color(0xffED7738)
                      : Colors.white.withOpacity(0.5),
                      border: Border.all(color: Colors.white, width: 1),
                    ),
                    child: Center(
                      child: Text(
                        returnIndexValue(asset)
                        style: const TextStyle(color: Colors.white),
                      ),
                    )
                  ),
                ),
              )
            )
              )
            ],),
          ),
         ];
        } eles {
          return Container();
        } ,
    },
  };
}