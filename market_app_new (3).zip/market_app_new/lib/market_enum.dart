enum ProductStatusType {
  sake('sale', '판매중'),
  reservation('soldOut', '판매완료'),
  cancek('cancel', '취소'),

  const ProductStatusType(this.value, this.name);
  final String value;
  final String name;
}
