import 'package:cloud_firestore/cloud_firestore.dart';

class Product {
  final String? id; // 문서 ID
  final String title; // 상품명
  final int price; // 가격
  final int stockQuantity; // 재고 수량 (요청하신 추가 필드)
  final String category; // 카테고리
  final String description; // 상세 설명
  final List<String> imageUrls; // 이미지 목록
  final String sellerId; // 판매자 UID
  final DateTime createdAt; // 등록 시간

  Product({
    this.id,
    required this.title,
    required this.price,
    required this.stockQuantity,
    required this.category,
    required this.description,
    required this.imageUrls,
    required this.sellerId,
    required this.createdAt,
  });

  // Firestore에 저장하기 위해 Map으로 변환
  Map<String, dynamic> toMap() {
    return {
      'title': title,
      'price': price,
      'stockQuantity': stockQuantity,
      'category': category,
      'description': description,
      'imageUrls': imageUrls,
      'sellerId': sellerId,
      'createdAt': Timestamp.fromDate(createdAt), // Firestore Timestamp 변환
    };
  }

  // Firestore에서 가져온 데이터로 객체 생성
  factory Product.fromSnapshot(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return Product(
      id: doc.id,
      title: data['title'] ?? '',
      price: data['price'] ?? 0,
      stockQuantity: data['stockQuantity'] ?? 1,
      category: data['category'] ?? '기타',
      description: data['description'] ?? '',
      imageUrls: List<String>.from(data['imageUrls'] ?? []),
      sellerId: data['sellerId'] ?? '',
      createdAt: (data['createdAt'] as Timestamp).toDate(),
    );
  }
}
