import 'package:flutter/material.dart';

class CommonTextFild extends StatefulWidget {
  final String? hintText;
  final Color? hintColor;
  final Function(String)? onChange;
  const CommonTextField({
    super.key,
    this.hintText,
    this.hintColor,
    this.onChange,
  });

  @override
  State<CommonTextField> createState()=> CommonTextFieldState();
}

class CommonTextFieldState extends State<CommonTextField> {
  @override
  Widget build(BuildContext context) {
    return TextField(
      style: const TextStyle(color: Colors.white),
      decoration: InputDecoration(
        hintText: widget.hintText,
        hintStyle: TextStyle(color: widget.hintColor),
        focusedBorder: const UnderlineInputBorder(
          borderSide: BorderSide.none,
        ),
      ),
      onChanged: widget.onChange,
    );
  }
}
