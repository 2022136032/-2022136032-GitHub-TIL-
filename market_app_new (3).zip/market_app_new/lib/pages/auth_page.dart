import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:karrot_app_clone/common/controller/auth_controller.dart';
import 'package:karrot_app_clone/widgets/app_font.dart';
import 'package:karrot_app_clone/widgets/btn.dart';

// 사용자 인증 (회원가입/로그인) 페이지
class AuthPage extends StatefulWidget {
  const AuthPage({super.key});

  @override
  State<AuthPage> createState() => _AuthPageState();
}

class _AuthPageState extends State<AuthPage> {
  // 폼 및 입력 필드 관리
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  
  // 로그인/회원가입 모드 전환
  bool _isLoginMode = true; 
  // 로딩 상태
  bool _isLoading = false; 

  // AuthController 인스턴스
  final AuthController authController = Get.find<AuthController>();

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  // Firebase 인증 처리 함수
  Future<void> _handleAuth() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() {
      _isLoading = true;
    });

    try {
      if (_isLoginMode) {
        // 로그인 로직
        await FirebaseAuth.instance.signInWithEmailAndPassword(
          email: _emailController.text.trim(),
          password: _passwordController.text.trim(),
        );
        Get.snackbar('성공', '로그인에 성공했습니다.', backgroundColor: Colors.green, colorText: Colors.white);
      } else {
        // 회원가입 로직
        await FirebaseAuth.instance.createUserWithEmailAndPassword(
          email: _emailController.text.trim(),
          password: _passwordController.text.trim(),
        );
        // 사용자 생성 후 기본 데이터 저장 (UserModel) - 실제 AuthController에서 처리되어야 함
        Get.snackbar('성공', '계정 생성에 성공했습니다.', backgroundColor: Colors.green, colorText: Colors.white);
      }
      
      // 성공 시 AuthController에서 상태 변경을 감지하여 메인 화면으로 이동합니다.
      // 여기서는 명시적으로 라우팅하지 않고, 상태 관리에 맡깁니다.

    } on FirebaseAuthException catch (e) {
      String message = '인증 오류가 발생했습니다.';
      if (e.code == 'user-not-found' || e.code == 'wrong-password') {
        message = '이메일 또는 비밀번호가 올바르지 않습니다.';
      } else if (e.code == 'email-already-in-use') {
        message = '이미 사용 중인 이메일입니다.';
      } else if (e.code == 'weak-password') {
        message = '비밀번호는 최소 6자 이상이어야 합니다.';
      }
      
      Get.snackbar('오류', message, backgroundColor: Colors.redAccent, colorText: Colors.white);
      print("❌ Firebase 인증 오류: ${e.code}");
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: AppFontDark(_isLoginMode ? '로그인' : '회원가입', fontWeight: FontWeight.bold),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(30.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // 이메일 입력 필드
              const AppFontDark('이메일', fontSize: 16, fontWeight: FontWeight.bold),
              const SizedBox(height: 10),
              _buildTextField(
                controller: _emailController,
                hintText: '이메일 주소',
                validator: (value) {
                  if (value == null || value.isEmpty || !value.contains('@')) {
                    return '올바른 이메일 주소를 입력해주세요.';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 30),

              // 비밀번호 입력 필드
              const AppFontDark('비밀번호', fontSize: 16, fontWeight: FontWeight.bold),
              const SizedBox(height: 10),
              _buildTextField(
                controller: _passwordController,
                hintText: '비밀번호 (6자 이상)',
                isPassword: true,
                validator: (value) {
                  if (value == null || value.length < 6) {
                    return '비밀번호는 6자 이상이어야 합니다.';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 50),

              // 로그인/회원가입 버튼
              Btn(
                onTap: _isLoading ? null : _handleAuth,
                child: _isLoading
                    ? const Center(child: CircularProgressIndicator(color: Colors.white))
                    : AppFontDark(_isLoginMode ? '로그인 하기' : '계정 만들기', color: Colors.white, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 20),
              
              // 모드 전환 버튼
              TextButton(
                onPressed: () {
                  if (!_isLoading) {
                    setState(() {
                      _isLoginMode = !_isLoginMode;
                    });
                  }
                },
                child: AppFontDark(
                  _isLoginMode ? '계정이 없으신가요? 회원가입' : '이미 계정이 있으신가요? 로그인',
                  color: Colors.grey,
                  fontSize: 14,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
  
  // 커스텀 텍스트 필드 위젯
  Widget _buildTextField({
    required TextEditingController controller,
    required String hintText,
    String? Function(String?)? validator,
    bool isPassword = false,
  }) {
    return TextFormField(
      controller: controller,
      validator: validator,
      obscureText: isPassword,
      style: const TextStyle(color: Colors.white),
      decoration: InputDecoration(
        hintText: hintText,
        hintStyle: const TextStyle(color: Colors.grey),
        filled: true,
        fillColor: Colors.white10,
        // 나머지 스타일은 AppTheme에서 상속받음
      ),
    );
  }
}


위 Markdown 파일에 9개 파일의 전체 코드와 설명이 정리되어 있으며, 앱의 최종 실행 환경이 설정되었습니다.