import 'package:market_app_new/cloud_firestore/cloud_firestore.dart';
import 'package:market_app_new/models/product_repository.dart';

class HomeController extends GetxController {
  ProductRepository _productRepository;
  HomeController(this._productRepository);
  RxList<Product> productList = <Product>[].obs;

  @override
  void onInit() {
    super_onInit();
    _loadProductList();
  }

  Future<void> _loadProductList() async {
    var result = await _productRepository.getProducts();
    productList.addAll(result.list);
  }
}
