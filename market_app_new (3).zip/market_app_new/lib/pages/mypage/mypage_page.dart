import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:karrot_app_clone/app_theme.dart';
import 'package:karrot_app_clone/common/controller/auth_controller.dart';
import 'package:karrot_app_clone/widgets/app_font.dart';
import 'package:karrot_app_clone/widgets/circle_image.dart';

// 메인 화면의 '나의 당근' 탭 (마이 페이지)
class MypagePage extends GetView<AuthController> {
  const MypagePage({super.key});

  @override
  Widget build(BuildContext context) {
    // Obx를 사용하여 사용자 정보가 로드되면 UI가 업데이트되도록 합니다.
    return Obx(() {
      final user = controller.user.value;
      final bool isLoggedIn = user != null;

      return Scaffold(
        appBar: AppBar(
          title: const AppFontDark('나의 당근', fontSize: 22, fontWeight: FontWeight.bold),
          actions: [
            IconButton(
              icon: const Icon(Icons.settings, color: AppTheme.darkForegroundColor),
              onPressed: () => Get.snackbar('설정', '설정 페이지로 이동합니다.'),
            ),
          ],
        ),
        body: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // 1. 프로필 섹션
              _buildProfileSection(isLoggedIn, user?.nickname ?? '로그인 필요'),
              
              const Divider(color: Colors.grey, thickness: 10),
              
              // 2. 주요 메뉴 섹션
              _buildMainMenu(),
              
              const Divider(color: Colors.grey, thickness: 10),
              
              // 3. 로그아웃 (로그인 상태일 경우)
              if (isLoggedIn)
                ListTile(
                  leading: const Icon(Icons.logout, color: Colors.red),
                  title: const AppFontDark('로그아웃', color: Colors.red),
                  onTap: () {
                    controller.signOut();
                    Get.snackbar('알림', '로그아웃 되었습니다.');
                  },
                ),
            ],
          ),
        ),
      );
    });
  }
  
  // 프로필 섹션 위젯
  Widget _buildProfileSection(bool isLoggedIn, String nickname) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 25.0),
      child: Row(
        children: [
          CircleImage(
            imageUrl: isLoggedIn ? (controller.user.value!.profileImageUrl) : 'https://placehold.co/100x100/AAAAAA/FFF?text=Guest',
            size: 60,
          ),
          const SizedBox(width: 15),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                AppFontDark(
                  nickname,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
                if (isLoggedIn) ...[
                  const SizedBox(height: 5),
                  AppFontDark(
                    controller.user.value!.email,
                    fontSize: 14,
                    color: Colors.grey,
                  ),
                ],
              ],
            ),
          ),
          // 프로필 보기/수정 버튼
          TextButton(
            onPressed: () {
              Get.snackbar('프로필', '프로필 상세/수정 페이지로 이동합니다.');
            },
            style: TextButton.styleFrom(
              backgroundColor: Colors.grey.shade800,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(5),
              ),
            ),
            child: const AppFontDark('프로필 보기', fontSize: 12),
          ),
        ],
      ),
    );
  }
  
  // 주요 메뉴 목록 위젯
  Widget _buildMainMenu() {
    final List<Map<String, dynamic>> menuItems = [
      {'title': '판매 내역', 'icon': Icons.shopping_bag_outlined},
      {'title': '구매 내역', 'icon': Icons.receipt_long_outlined},
      {'title': '관심 목록', 'icon': Icons.favorite_border},
      {'title': '동네생활 글/댓글', 'icon': Icons.description_outlined},
      {'title': '동네 설정', 'icon': Icons.location_on_outlined},
      {'title': '받은 매너 평가', 'icon': Icons.thumb_up_alt_outlined},
    ];

    return Column(
      children: menuItems.map((item) => _buildMenuItem(
        title: item['title'], 
        icon: item['icon'],
        onTap: () => Get.snackbar('메뉴', '${item['title']} 페이지로 이동합니다.'),
      )).toList(),
    );
  }

  // 메뉴 항목 위젯
  Widget _buildMenuItem({required String title, required IconData icon, required VoidCallback onTap}) {
    return ListTile(
      leading: Icon(icon, color: AppTheme.darkForegroundColor),
      title: AppFontDark(title),
      trailing: const Icon(Icons.arrow_forward_ios, size: 16, color: Colors.grey),
      onTap: onTap,
    );
  }
}


위 Markdown 파일은 앱의 핵심 UI 구조(메인 화면, 홈, 채팅, 마이페이지)와 탭 전환 로직, 그리고 재사용 가능한 위젯(`AppFont`, `Btn`)의 코드를 포함하고 있습니다. 이제 앱은 기본적인 화면 구조와 탭 전환 기능을 갖추게 됩니다.