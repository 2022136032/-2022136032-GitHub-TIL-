import 'package:flutter/material.dart';

// 하단 내비게이션 바의 개별 아이콘 위젯
class NavItem extends StatelessWidget {
  final IconData icon;
  final bool isSelected;

  const NavItem({super.key, required this.icon, this.isSelected = false});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5.0),
      child: Icon(
        icon,
        size: 26,
        // 선택된 상태에 따라 색상 변경 (메인 스크린에서 처리되지만, 재사용성을 위해 여기에 구조를 정의)
        color: isSelected ? const Color(0xFFFF7E36) : Colors.grey,
      ),
    );
  }
}
