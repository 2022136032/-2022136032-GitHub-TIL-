import 'package:flutter/material.dart';
import 'package:karrot_app_clone/app_theme.dart';
import 'package:karrot_app_clone/widgets/app_font.dart';
import 'package:karrot_app_clone/widgets/btn.dart';

// 데이터가 없거나 에러가 발생했을 때 표시하는 빈 상태 화면 위젯
class EmptyState extends StatelessWidget {
  final String title;
  final String message;
  final IconData icon;
  final String? actionText; // 액션 버튼 텍스트 (선택 사항)
  final VoidCallback? onActionTap; // 액션 버튼 클릭 이벤트

  const EmptyState({
    super.key,
    required this.title,
    required this.message,
    this.icon = Icons.inbox_outlined,
    this.actionText,
    this.onActionTap,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(40.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          mainAxisSize: MainAxisSize.min, // 가능한 최소 공간만 사용
          children: [
            // 아이콘
            Icon(icon, size: 70, color: Colors.grey.shade600),
            const SizedBox(height: 20),

            // 제목
            AppFontDark(
              title,
              fontSize: 20,
              isBold: true,
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 10),

            // 메시지
            AppFontDark(
              message,
              fontSize: 14,
              color: Colors.grey.shade500,
              textAlign: TextAlign.center,
            ),

            // 액션 버튼
            if (actionText != null && onActionTap != null) ...[
              const SizedBox(height: 30),
              SizedBox(
                width: 200, // 버튼 너비 제한
                child: Btn(
                  onTap: onActionTap!,
                  backgroundColor: AppTheme.primaryKarrotColor,
                  child: AppFontDark(
                    actionText!,
                    isBold: true,
                    color: Colors.white,
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
