import 'package:flutter/material.dart';

// 앱 전체에서 사용되는 커스텀 버튼 위젯
class Btn extends StatelessWidget {
  final Widget child; // 버튼 안에 들어갈 위젯 (텍스트, 아이콘 등)
  final VoidCallback? onTap; // 탭 이벤트 핸들러
  final double? width;
  final double? height;
  final EdgeInsetsGeometry padding;
  final Color? backgroundColor;
  final double borderRadius;
  final BorderSide? borderSide;

  const Btn({
    super.key,
    required this.child,
    required this.onTap,
    this.width,
    this.height = 50.0, // 기본 높이 설정
    this.padding = const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
    this.backgroundColor,
    this.borderRadius = 8.0,
    this.borderSide,
  });

  @override
  Widget build(BuildContext context) {
    // 배경색이 지정되지 않은 경우, 테마의 primaryColor를 사용합니다.
    final Color defaultColor = Theme.of(context).primaryColor;

    // 버튼이 비활성화되었는지 확인
    final bool isDisabled = onTap == null;

    return Material(
      color: isDisabled
          ? Colors
                .grey
                .shade700 // 비활성화 시 어두운 회색
          : backgroundColor ?? defaultColor, // 활성화 시 지정 색상 또는 기본 색상
      borderRadius: BorderRadius.circular(borderRadius),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(borderRadius),
        child: Container(
          width: width,
          height: height,
          padding: padding,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(borderRadius),
            border: borderSide != null
                ? Border.fromBorderSide(borderSide!)
                : null,
          ),
          alignment: Alignment.center,
          child: child,
        ),
      ),
    );
  }
}
