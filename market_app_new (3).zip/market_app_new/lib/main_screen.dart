import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:karrot_app_clone/app_theme.dart';
import 'package:karrot_app_clone/common/controller/main_controller.dart';
import 'package:karrot_app_clone/pages/chat/chat_page.dart';
import 'package:karrot_app_clone/pages/home/home_page.dart';
import 'package:karrot_app_clone/pages/near/near_page.dart';
import 'package:karrot_app_clone/pages/mykarrot/my_karrot_page.dart';
import 'package:karrot_app_clone/pages/townlife/town_life_page.dart';

// 메인 화면 (Bottom Navigation Bar를 포함하는 탭 컨테이너)
class MainScreen extends GetView<MainController> {
  const MainScreen({super.key});

  // Bottom Navigation Bar에 표시될 탭 화면 목록
  final List<Widget> _pages = const [
    HomePage(), // 홈 - 중고거래
    TownLifePage(), // 동네생활
    NearPage(), // 내 근처
    ChatPage(), // 채팅
    MyKarrotPage(), // 나의 당근
  ];

  @override
  Widget build(BuildContext context) {
    // MainController의 selectedIndex를 관찰하여 탭 상태를 실시간 업데이트합니다.
    return Obx(
      () => Scaffold(
        // 현재 선택된 인덱스의 페이지를 보여줍니다.
        body: IndexedStack(
          index: controller.selectedIndex.value,
          children: _pages,
        ),

        // 하단 네비게이션 바
        bottomNavigationBar: BottomNavigationBar(
          backgroundColor: AppTheme.darkBackgroundColor, // 다크 모드 배경색
          type: BottomNavigationBarType.fixed, // 탭이 4개 이상일 때 색상 변경 방지
          selectedItemColor: AppTheme.primaryKarrotColor, // 선택된 아이템 색상
          unselectedItemColor: Colors.grey.shade600, // 선택되지 않은 아이템 색상

          currentIndex: controller.selectedIndex.value,
          onTap: controller.changeIndex, // 탭 선택 시 컨트롤러의 함수 호출

          items: const <BottomNavigationBarItem>[
            BottomNavigationBarItem(
              icon: Icon(Icons.home_outlined),
              activeIcon: Icon(Icons.home),
              label: '홈',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.list_alt),
              activeIcon: Icon(Icons.list_alt),
              label: '동네생활',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.pin_drop_outlined),
              activeIcon: Icon(Icons.pin_drop),
              label: '내 근처',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.chat_bubble_outline),
              activeIcon: Icon(Icons.chat_bubble),
              label: '채팅',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.person_outline),
              activeIcon: Icon(Icons.person),
              label: '나의 당근',
            ),
          ],
        ),
      ),
    );
  }
}

// 다음 파일들을 위해 임시 더미 페이지를 정의합니다. (실제 구현은 이전 파일에 있었거나 추후 진행될 예정)
class HomePage extends StatelessWidget {
  const HomePage({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('홈')),
      body: const Center(child: Text('홈 화면 (중고거래)')),
    );
  }
}

class ChatPage extends StatelessWidget {
  const ChatPage({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('채팅')),
      body: const Center(child: Text('채팅 화면')),
    );
  }
}

class MyKarrotPage extends StatelessWidget {
  const MyKarrotPage({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('나의 당근')),
      body: const Center(child: Text('나의 당근 화면')),
    );
  }
}
