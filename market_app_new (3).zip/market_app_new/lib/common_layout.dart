import 'package:bamtol_market_app/src/common/components/loading.dart';
import 'package:bamtol_market_app/src/common/controlles/common_layout_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class CommonLayout extends GetView<CommonLayoutController> {}
